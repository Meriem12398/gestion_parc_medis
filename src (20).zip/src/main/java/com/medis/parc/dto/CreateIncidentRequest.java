package com.medis.parc.dto;

public class CreateIncidentRequest {

    private Integer idmission;
    private String typeIncident;
    private String description;

    public Integer getIdmission() {
        return idmission;
    }

    public void setIdmission(Integer idmission) {
        this.idmission = idmission;
    }

    public String getTypeIncident() {
        return typeIncident;
    }

    public void setTypeIncident(String typeIncident) {
        this.typeIncident = typeIncident;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }
}