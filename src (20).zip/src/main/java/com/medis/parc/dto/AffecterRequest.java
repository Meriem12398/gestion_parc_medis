package com.medis.parc.dto;

import java.time.LocalDateTime;

public class AffecterRequest {
    private Integer idvehicule;
    private Integer chauffeurMatricule;
    private LocalDateTime dateDebut;

    public Integer getIdvehicule() { return idvehicule; }
    public void setIdvehicule(Integer idvehicule) { this.idvehicule = idvehicule; }

    public Integer getChauffeurMatricule() { return chauffeurMatricule; }
    public void setChauffeurMatricule(Integer chauffeurMatricule) { this.chauffeurMatricule = chauffeurMatricule; }

    public LocalDateTime getDateDebut() { return dateDebut; }
    public void setDateDebut(LocalDateTime dateDebut) { this.dateDebut = dateDebut; }
}