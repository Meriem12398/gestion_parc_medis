package com.medis.parc.dto;

import jakarta.validation.constraints.*;

public record UtilisateurDto(

        Integer matricule,

        @NotBlank(message = "Nom obligatoire")
        @Pattern(regexp = "^[A-Za-zÀ-ÿ' -]{2,30}$",
                message = "Nom invalide (2-30 lettres)")
        String nom,

        @NotBlank(message = "Prénom obligatoire")
        @Pattern(regexp = "^[A-Za-zÀ-ÿ' -]{2,30}$",
                message = "Prénom invalide (2-30 lettres)")
        String prenom,

        @NotBlank(message = "Email obligatoire")
        @Email(message = "Email invalide")
        String email,

        @Pattern(regexp = "^[0-9]{8}$",
                message = "Téléphone doit contenir 8 chiffres")
        String telephone,

        String departement,

        String typePermis,

        Integer disponibilite,

        @NotBlank(message = "Rôle obligatoire")
        String role,

        @NotBlank(message = "Mot de passe obligatoire")
        @Size(min = 5, message = "Mot de passe minimum 5 caractères")
        String motDePasse
) {}