package com.medis.parc.dto;

import java.time.LocalDateTime;
import java.util.List;

public class MissionDetailsDto {

    private Integer idmission;
    private LocalDateTime dateDebut;
    private LocalDateTime dateFin;
    private String statutMission;

    private Integer idvehicule;
    private String immatriculationVehicule;

    private Integer chauffeurMatricule;
    private String chauffeurNom;
    private String chauffeurPrenom;

    private List<DemandeMiniDto> demandes;

    public Integer getIdmission() {
        return idmission;
    }

    public void setIdmission(Integer idmission) {
        this.idmission = idmission;
    }

    public LocalDateTime getDateDebut() {
        return dateDebut;
    }

    public void setDateDebut(LocalDateTime dateDebut) {
        this.dateDebut = dateDebut;
    }

    public LocalDateTime getDateFin() {
        return dateFin;
    }

    public void setDateFin(LocalDateTime dateFin) {
        this.dateFin = dateFin;
    }

    public String getStatutMission() {
        return statutMission;
    }

    public void setStatutMission(String statutMission) {
        this.statutMission = statutMission;
    }

    public Integer getIdvehicule() {
        return idvehicule;
    }

    public void setIdvehicule(Integer idvehicule) {
        this.idvehicule = idvehicule;
    }

    public String getImmatriculationVehicule() {
        return immatriculationVehicule;
    }

    public void setImmatriculationVehicule(String immatriculationVehicule) {
        this.immatriculationVehicule = immatriculationVehicule;
    }

    public Integer getChauffeurMatricule() {
        return chauffeurMatricule;
    }

    public void setChauffeurMatricule(Integer chauffeurMatricule) {
        this.chauffeurMatricule = chauffeurMatricule;
    }

    public String getChauffeurNom() {
        return chauffeurNom;
    }

    public void setChauffeurNom(String chauffeurNom) {
        this.chauffeurNom = chauffeurNom;
    }

    public String getChauffeurPrenom() {
        return chauffeurPrenom;
    }

    public void setChauffeurPrenom(String chauffeurPrenom) {
        this.chauffeurPrenom = chauffeurPrenom;
    }

    public List<DemandeMiniDto> getDemandes() {
        return demandes;
    }

    public void setDemandes(List<DemandeMiniDto> demandes) {
        this.demandes = demandes;
    }
}