package com.medis.parc.dto;


import lombok.Getter;
import lombok.Setter;

@Getter @Setter
public class  CreateChauffeurRequest {
  private String nom;
  private String prenom;
  private String email;
  private String telephone;
  private String departement;
  private String typePermis;
  private Integer disponibilite; // 1/0
  private String role; // "CHAUFFEUR"


  private String motDePasse;
}
