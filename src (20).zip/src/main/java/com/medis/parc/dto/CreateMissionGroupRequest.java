package com.medis.parc.dto;

import java.time.LocalDateTime;
import java.util.List;

public class CreateMissionGroupRequest {

    private Integer vehiculeId;
    private Integer chauffeurMatricule;
    private LocalDateTime dateDebut;
    private List<Integer> demandeIds;

    public Integer getVehiculeId() { return vehiculeId; }
    public void setVehiculeId(Integer vehiculeId) { this.vehiculeId = vehiculeId; }

    public Integer getChauffeurMatricule() { return chauffeurMatricule; }
    public void setChauffeurMatricule(Integer chauffeurMatricule) { this.chauffeurMatricule = chauffeurMatricule; }

    public LocalDateTime getDateDebut() { return dateDebut; }
    public void setDateDebut(LocalDateTime dateDebut) { this.dateDebut = dateDebut; }

    public List<Integer> getDemandeIds() { return demandeIds; }
    public void setDemandeIds(List<Integer> demandeIds) { this.demandeIds = demandeIds; }
}