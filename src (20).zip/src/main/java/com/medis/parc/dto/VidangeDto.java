package com.medis.parc.dto;

import java.math.BigDecimal;
import java.time.LocalDate;

public record VidangeDto(
        Integer idvidange,
        Integer vehiculeId,
        String immatriculationVehicule,
        String marqueVehicule,
        String modeleVehicule,
        LocalDate dateVidange,
        Integer kilometrageVidange,
        String typeHuile,
        BigDecimal cout,
        String remarque,
        LocalDate prochaineDate,
        Integer prochainKilometrage,
        String statut
) {}