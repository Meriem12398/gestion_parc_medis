package com.medis.parc.dto;

import java.math.BigDecimal;

public class CreateInterventionRequest {

    private String typeIntervention;
    private String description;
    private BigDecimal cout;
    private Integer idincident;

    public String getTypeIntervention() {
        return typeIntervention;
    }

    public void setTypeIntervention(String typeIntervention) {
        this.typeIntervention = typeIntervention;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public BigDecimal getCout() {
        return cout;
    }

    public void setCout(BigDecimal cout) {
        this.cout = cout;
    }

    public Integer getIdincident() {
        return idincident;
    }

    public void setIdincident(Integer idincident) {
        this.idincident = idincident;
    }
}