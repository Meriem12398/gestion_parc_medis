package com.medis.parc.dto;

import java.time.LocalDateTime;

public class DemandeDto {

    private Integer iddemande;
    private String typeDemande;
    private LocalDateTime dateCreation;
    private LocalDateTime dateSouhaite;
    private String statut;
    private String priorite;
    private String description;
    private Integer matricule;

    private String nomCreateur;
    private String prenomCreateur;
    private String departementCreateur;

    private String motifRefus;
    
    private Double scorePriorite;
    private String prioriteIa;

    public Double getScorePriorite() {
		return scorePriorite;
	}

	public void setScorePriorite(Double scorePriorite) {
		this.scorePriorite = scorePriorite;
	}

	public String getPrioriteIa() {
		return prioriteIa;
	}

	public void setPrioriteIa(String prioriteIa) {
		this.prioriteIa = prioriteIa;
	}

	public Integer getIddemande() {
        return iddemande;
    }

    public void setIddemande(Integer iddemande) {
        this.iddemande = iddemande;
    }

    public String getTypeDemande() {
        return typeDemande;
    }

    public void setTypeDemande(String typeDemande) {
        this.typeDemande = typeDemande;
    }

    public LocalDateTime getDateCreation() {
        return dateCreation;
    }

    public void setDateCreation(LocalDateTime dateCreation) {
        this.dateCreation = dateCreation;
    }

    public LocalDateTime getDateSouhaite() {
        return dateSouhaite;
    }

    public void setDateSouhaite(LocalDateTime dateSouhaite) {
        this.dateSouhaite = dateSouhaite;
    }

    public String getStatut() {
        return statut;
    }

    public void setStatut(String statut) {
        this.statut = statut;
    }

    public String getPriorite() {
        return priorite;
    }

    public void setPriorite(String priorite) {
        this.priorite = priorite;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Integer getMatricule() {
        return matricule;
    }

    public void setMatricule(Integer matricule) {
        this.matricule = matricule;
    }

    public String getNomCreateur() {
        return nomCreateur;
    }

    public void setNomCreateur(String nomCreateur) {
        this.nomCreateur = nomCreateur;
    }

    public String getPrenomCreateur() {
        return prenomCreateur;
    }

    public void setPrenomCreateur(String prenomCreateur) {
        this.prenomCreateur = prenomCreateur;
    }

    public String getDepartementCreateur() {
        return departementCreateur;
    }

    public void setDepartementCreateur(String departementCreateur) {
        this.departementCreateur = departementCreateur;
    }

    public String getMotifRefus() {
        return motifRefus;
    }

    public void setMotifRefus(String motifRefus) {
        this.motifRefus = motifRefus;
    }
}