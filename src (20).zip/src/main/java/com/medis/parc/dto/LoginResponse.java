package com.medis.parc.dto;

public class LoginResponse {
    private String token;
    private Integer matricule;
    private String nom;
    private String prenom;
    private String email;
    private String role;

    public LoginResponse(String token, Integer matricule, String nom, String prenom, String email, String role) {
        this.token = token;
        this.matricule = matricule;
        this.nom = nom;
        this.prenom = prenom;
        this.email = email;
        this.role = role;
    }

    public String getToken() { return token; }
    public Integer getMatricule() { return matricule; }
    public String getNom() { return nom; }
    public String getPrenom() { return prenom; }
    public String getEmail() { return email; }
    public String getRole() { return role; }
}