package com.medis.parc.dto;

public class DemandeMiniDto {

    private Integer iddemande;
    private String typeDemande;
    private String statut;
    private String priorite;
    private String description;
    private Double scorePriorite;
    private String prioriteIa;
    public Double getScorePriorite() {
		return scorePriorite;
	}

	public void setScorePriorite(Double scorePriorite) {
		this.scorePriorite = scorePriorite;
	}

	public String getPrioriteIa() {
		return prioriteIa;
	}

	public void setPrioriteIa(String prioriteIa) {
		this.prioriteIa = prioriteIa;
	}

	public Integer getIddemande() {
        return iddemande;
    }

    public void setIddemande(Integer iddemande) {
        this.iddemande = iddemande;
    }

    public String getTypeDemande() {
        return typeDemande;
    }

    public void setTypeDemande(String typeDemande) {
        this.typeDemande = typeDemande;
    }

    public String getStatut() {
        return statut;
    }

    public void setStatut(String statut) {
        this.statut = statut;
    }

    public String getPriorite() {
        return priorite;
    }

    public void setPriorite(String priorite) {
        this.priorite = priorite;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }
}