package com.medis.parc.dto;

import java.math.BigDecimal;
import java.time.LocalDateTime;

public class InterventionHistoriqueDto {

    private Integer idintervention;
    private LocalDateTime dateIntervention;
    private String typeIntervention;
    private String description;
    private BigDecimal cout;
    private Integer idincident;

    private Integer idmission;
    private Integer idvehicule;
    private String immatriculationVehicule;
    private String marqueVehicule;
    private String modeleVehicule;

    public Integer getIdintervention() {
        return idintervention;
    }

    public void setIdintervention(Integer idintervention) {
        this.idintervention = idintervention;
    }

    public LocalDateTime getDateIntervention() {
        return dateIntervention;
    }

    public void setDateIntervention(LocalDateTime dateIntervention) {
        this.dateIntervention = dateIntervention;
    }

    public String getTypeIntervention() {
        return typeIntervention;
    }

    public void setTypeIntervention(String typeIntervention) {
        this.typeIntervention = typeIntervention;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public BigDecimal getCout() {
        return cout;
    }

    public void setCout(BigDecimal cout) {
        this.cout = cout;
    }

    public Integer getIdincident() {
        return idincident;
    }

    public void setIdincident(Integer idincident) {
        this.idincident = idincident;
    }

    public Integer getIdmission() {
        return idmission;
    }

    public void setIdmission(Integer idmission) {
        this.idmission = idmission;
    }

    public Integer getIdvehicule() {
        return idvehicule;
    }

    public void setIdvehicule(Integer idvehicule) {
        this.idvehicule = idvehicule;
    }

    public String getImmatriculationVehicule() {
        return immatriculationVehicule;
    }

    public void setImmatriculationVehicule(String immatriculationVehicule) {
        this.immatriculationVehicule = immatriculationVehicule;
    }

    public String getMarqueVehicule() {
        return marqueVehicule;
    }

    public void setMarqueVehicule(String marqueVehicule) {
        this.marqueVehicule = marqueVehicule;
    }

    public String getModeleVehicule() {
        return modeleVehicule;
    }

    public void setModeleVehicule(String modeleVehicule) {
        this.modeleVehicule = modeleVehicule;
    }
}