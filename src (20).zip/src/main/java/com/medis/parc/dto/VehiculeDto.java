package com.medis.parc.dto;

import java.time.LocalDate;

public record VehiculeDto(
        Integer idvehicule,
        String immatriculation,
        String marque,
        String modele,
        Integer kilometrage,
        String etat,
        String typeCarburant,
        LocalDate dateAchat
) {}