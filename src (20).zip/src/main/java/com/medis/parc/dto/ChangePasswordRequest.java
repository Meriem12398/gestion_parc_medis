package com.medis.parc.dto;

public record ChangePasswordRequest(
        String email,
        String ancienMotDePasse,
        String nouveauMotDePasse
) {}