package com.medis.parc.dto;

public class AnnulerMissionRequest {

    private String motif;

    public String getMotif() {
        return motif;
    }

    public void setMotif(String motif) {
        this.motif = motif;
    }
}