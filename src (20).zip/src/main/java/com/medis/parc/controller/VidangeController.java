package com.medis.parc.controller;

import com.medis.parc.dto.VidangeDto;
import com.medis.parc.service.VidangeService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/vidanges")
@CrossOrigin(origins = "*")
public class VidangeController {

    private final VidangeService vidangeService;

    public VidangeController(VidangeService vidangeService) {
        this.vidangeService = vidangeService;
    }

    @GetMapping
    public List<VidangeDto> getAll() {
        return vidangeService.getAll();
    }

    @GetMapping("/vehicule/{vehiculeId}")
    public List<VidangeDto> getByVehicule(@PathVariable Integer vehiculeId) {
        return vidangeService.getByVehicule(vehiculeId);
    }

    @PostMapping
    public ResponseEntity<VidangeDto> create(@RequestBody VidangeDto dto) {
        return ResponseEntity.ok(vidangeService.create(dto));
    }

    @PutMapping("/{id}")
    public ResponseEntity<VidangeDto> update(@PathVariable Integer id, @RequestBody VidangeDto dto) {
        return ResponseEntity.ok(vidangeService.update(id, dto));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable Integer id) {
        vidangeService.delete(id);
        return ResponseEntity.noContent().build();
    }
}