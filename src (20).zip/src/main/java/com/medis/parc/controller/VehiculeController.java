package com.medis.parc.controller;

import com.medis.parc.dto.VehiculeDto;
import com.medis.parc.service.VehiculeService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/vehicules")
@CrossOrigin(origins = "*")
public class VehiculeController {

    private final VehiculeService vehiculeService;

    public VehiculeController(VehiculeService vehiculeService) {
        this.vehiculeService = vehiculeService;
    }

    @GetMapping
    public List<VehiculeDto> getAll() {
        return vehiculeService.getAll();
    }

    @PostMapping
    public ResponseEntity<VehiculeDto> create(@RequestBody VehiculeDto dto) {
        return ResponseEntity.ok(vehiculeService.create(dto));
    }

    @PutMapping("/{id}")
    public ResponseEntity<VehiculeDto> update(
            @PathVariable Integer id,
            @RequestBody VehiculeDto dto
    ) {
        return ResponseEntity.ok(vehiculeService.update(id, dto));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable Integer id) {
        vehiculeService.delete(id);
        return ResponseEntity.noContent().build();
    }
}