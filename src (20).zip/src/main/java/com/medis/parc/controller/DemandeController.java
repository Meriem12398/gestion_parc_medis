package com.medis.parc.controller;

import com.medis.parc.dto.AffecterRequest;
import com.medis.parc.dto.CreateDemandeRequest;
import com.medis.parc.dto.DemandeDto;
import com.medis.parc.dto.UpdateDemandeRequest;
import com.medis.parc.dto.UpdateStatutRequest;
import com.medis.parc.service.DemandeService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/demandes")
@CrossOrigin(origins = "*")
public class DemandeController {

    private final DemandeService demandeService;

    public DemandeController(DemandeService demandeService) {
        this.demandeService = demandeService;
    }

    @GetMapping
    public List<DemandeDto> getAll(
            @RequestParam(required = false) String statut,
            @RequestParam(required = false) String priorite
    ) {
        return demandeService.getAllFiltered(statut, priorite);
    }

    @GetMapping("/mes-demandes")
    public List<DemandeDto> getMesDemandes() {
        return demandeService.getMesDemandes();
    }

    @PostMapping
    public DemandeDto create(@RequestBody CreateDemandeRequest req) {
        return demandeService.createDemande(req);
    }

    @PutMapping("/{id}/demandeur")
    public DemandeDto updateDemandeByDemandeur(
            @PathVariable Integer id,
            @RequestBody UpdateDemandeRequest req
    ) {
        return demandeService.updateDemandeByDemandeur(id, req);
    }

    @DeleteMapping("/{id}/demandeur")
    public String deleteDemandeByDemandeur(@PathVariable Integer id) {
        demandeService.deleteDemandeByDemandeur(id);
        return "Demande supprimée avec succès";
    }

    @PutMapping("/{id}/statut")
    public void updateStatut(@PathVariable Integer id, @RequestBody UpdateStatutRequest req) {
        demandeService.updateStatut(id, req);
    }

    @PostMapping("/{id}/affecter")
    public void affecter(@PathVariable Integer id, @RequestBody AffecterRequest req) {
        demandeService.affecter(id, req);
    }
}