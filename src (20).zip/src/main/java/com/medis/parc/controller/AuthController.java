package com.medis.parc.controller;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.medis.parc.dto.ChangePasswordRequest;
import com.medis.parc.dto.LoginRequest;
import com.medis.parc.dto.LoginResponse;
import com.medis.parc.service.AuthService;

import com.medis.parc.dto.ForgotPasswordRequest;
import com.medis.parc.dto.ResetPasswordRequest;


@RestController
@RequestMapping("/api/auth")
@CrossOrigin(origins = "*")
public class AuthController {

    private final AuthService authService;

    public AuthController(AuthService authService) {
        this.authService = authService;
    }

    @PostMapping("/login")
    public ResponseEntity<LoginResponse> login(@RequestBody LoginRequest req) {
        return ResponseEntity.ok(authService.login(req));
    }

    @PutMapping("/change-password")
    public ResponseEntity<String> changePassword(@RequestBody ChangePasswordRequest req) {
        authService.changePassword(req);
        return ResponseEntity.ok("Mot de passe modifié avec succès");
    }
    @PostMapping("/forgot-password")
    public ResponseEntity<String> forgotPassword(@RequestBody ForgotPasswordRequest req) {
        authService.forgotPassword(req);
        return ResponseEntity.ok("Si un compte existe, un email a été envoyé.");
    }

    @PostMapping("/reset-password")
    public ResponseEntity<String> resetPassword(@RequestBody ResetPasswordRequest req) {
        authService.resetPassword(req);
        return ResponseEntity.ok("Mot de passe réinitialisé avec succès");
    }
    
}