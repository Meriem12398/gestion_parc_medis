package com.medis.parc.controller;

import com.medis.parc.dto.CreateInterventionRequest;
import com.medis.parc.dto.InterventionHistoriqueDto;
import com.medis.parc.entity.Intervention;
import com.medis.parc.service.InterventionService;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/interventions")
@CrossOrigin(origins = "*")
public class InterventionController {

    private final InterventionService interventionService;

    public InterventionController(InterventionService interventionService) {
        this.interventionService = interventionService;
    }

    @PostMapping
    public Intervention create(@RequestBody CreateInterventionRequest req) {
        return interventionService.createIntervention(req);
    }

    @GetMapping
    public List<Intervention> getAll() {
        return interventionService.getAllInterventions();
    }

    @GetMapping("/historique")
    public List<InterventionHistoriqueDto> getHistorique() {
        return interventionService.getAllInterventionsHistorique();
    }

    @GetMapping("/incident/{idincident}")
    public List<Intervention> getByIncident(@PathVariable Integer idincident) {
        return interventionService.getByIncident(idincident);
    }

    @GetMapping("/incident/{idincident}/exists")
    public Map<String, Boolean> hasIntervention(@PathVariable Integer idincident) {
        return Map.of("exists", interventionService.hasIntervention(idincident));
    }
}