package com.medis.parc.controller;

import com.medis.parc.dto.AnnulerMissionRequest;
import com.medis.parc.dto.CreateIncidentRequest;
import com.medis.parc.dto.CreateMissionGroupRequest;
import com.medis.parc.dto.MissionDetailsDto;
import com.medis.parc.dto.MissionDto;
import com.medis.parc.entity.Incident;
import com.medis.parc.entity.Mission;
import com.medis.parc.service.MissionService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/missions")
@CrossOrigin(origins = "*")
public class MissionController {

    private final MissionService missionService;

    public MissionController(MissionService missionService) {
        this.missionService = missionService;
    }

    @GetMapping
    public List<MissionDto> getAll() {
        return missionService.getAllMissionDtos();
    }

    @GetMapping("/chauffeur")
    public List<MissionDto> getMissionsDuChauffeur() {
        return missionService.getMissionsDuChauffeurConnecte();
    }

    @GetMapping("/{id}/details")
    public MissionDetailsDto getDetails(@PathVariable Integer id) {
        return missionService.getMissionDetails(id);
    }

    @PostMapping("/groupee")
    public Mission creerMissionGroupee(@RequestBody CreateMissionGroupRequest req) {
        return missionService.creerMissionGroupee(req);
    }

    @PutMapping("/{id}/terminer")
    public Mission terminer(@PathVariable Integer id) {
        return missionService.terminerMission(id);
    }

    @PutMapping("/{id}/annuler")
    public Mission annuler(@PathVariable Integer id, @RequestBody AnnulerMissionRequest req) {
        return missionService.annulerMission(id, req);
    }

    @PostMapping("/incidents")
    public Incident creerIncident(@RequestBody CreateIncidentRequest req) {
        return missionService.creerIncident(req);
    }
}