package com.medis.parc.controller;

import com.medis.parc.dto.ResetPasswordRequest;
import com.medis.parc.dto.UtilisateurDto;
import com.medis.parc.service.UtilisateurService;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/utilisateurs")
@CrossOrigin(origins = "*")
public class UtilisateurController {

    private final UtilisateurService utilisateurService;

    public UtilisateurController(UtilisateurService utilisateurService) {
        this.utilisateurService = utilisateurService;
    }

    @GetMapping
    @PreAuthorize("hasRole('RESPONSABLE')")
    public List<UtilisateurDto> getAll() {
        return utilisateurService.getAll();
    }

    @GetMapping("/chauffeurs")
    @PreAuthorize("hasRole('RESPONSABLE')")
    public List<UtilisateurDto> getChauffeurs() {
        return utilisateurService.getChauffeurs();
    }

    // ✅ NEW
    @GetMapping("/demandeurs")
    @PreAuthorize("hasRole('RESPONSABLE')")
    public List<UtilisateurDto> getDemandeurs() {
        return utilisateurService.getDemandeurs();
    }

    // ✅ ADD (CREATE USER)
    @PostMapping
    @PreAuthorize("hasRole('RESPONSABLE')")
    public ResponseEntity<UtilisateurDto> create(@Valid @RequestBody UtilisateurDto dto) {
        return ResponseEntity.ok(utilisateurService.create(dto));
    }

    // ✅ UPDATE (بدون @Valid)
    @PutMapping("/{matricule}")
    @PreAuthorize("hasRole('RESPONSABLE')")
    public ResponseEntity<UtilisateurDto> update(
            @PathVariable Integer matricule,
            @RequestBody UtilisateurDto dto
    ) {
        return ResponseEntity.ok(utilisateurService.update(matricule, dto));
    }

    // ✅ DELETE
    @DeleteMapping("/{matricule}")
    @PreAuthorize("hasRole('RESPONSABLE')")
    public ResponseEntity<Void> delete(@PathVariable Integer matricule) {
        utilisateurService.delete(matricule);
        return ResponseEntity.noContent().build();
    }
    @PutMapping("/{matricule}/reset-password")
    @PreAuthorize("hasRole('RESPONSABLE')")
    public ResponseEntity<String> resetPassword(
            @PathVariable Integer matricule,
            @RequestBody ResetPasswordRequest req
    ) {
        utilisateurService.resetPasswordByResponsable(matricule, req);
        return ResponseEntity.ok("Mot de passe réinitialisé avec succès");
    }
}