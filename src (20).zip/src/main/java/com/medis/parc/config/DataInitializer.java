package com.medis.parc.config;

import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.crypto.password.PasswordEncoder;

import com.medis.parc.entity.Utilisateur;
import com.medis.parc.repository.UtilisateurRepository;

@Configuration
public class DataInitializer {

    @Bean
    CommandLineRunner init(UtilisateurRepository repo, PasswordEncoder encoder) {
        return args -> {
            if (repo.findByEmail("admin@medis.tn").isEmpty()) {
                Utilisateur u = new Utilisateur();
                u.setNom("Admin");
                u.setPrenom("Medis");
                u.setEmail("admin@medis.tn");
                u.setMotdepasse(encoder.encode("admin123"));
                u.setRole("RESPONSABLE");
                repo.save(u);
            }
        };
    }
}