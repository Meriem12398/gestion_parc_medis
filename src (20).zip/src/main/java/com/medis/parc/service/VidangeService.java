package com.medis.parc.service;

import com.medis.parc.dto.VidangeDto;
import com.medis.parc.entity.Vehicule;
import com.medis.parc.entity.Vidange;
import com.medis.parc.repository.VehiculeRepository;
import com.medis.parc.repository.VidangeRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class VidangeService {

    private final VidangeRepository vidangeRepository;
    private final VehiculeRepository vehiculeRepository;

    public VidangeService(VidangeRepository vidangeRepository, VehiculeRepository vehiculeRepository) {
        this.vidangeRepository = vidangeRepository;
        this.vehiculeRepository = vehiculeRepository;
    }

    public List<VidangeDto> getAll() {
        return vidangeRepository.findAll()
                .stream()
                .map(this::toDto)
                .toList();
    }

    public List<VidangeDto> getByVehicule(Integer vehiculeId) {
        return vidangeRepository.findByVehicule_Idvehicule(vehiculeId)
                .stream()
                .map(this::toDto)
                .toList();
    }

    public VidangeDto create(VidangeDto dto) {
        if (dto.vehiculeId() == null) {
            throw new RuntimeException("Véhicule obligatoire");
        }

        if (dto.statut() == null || dto.statut().isBlank()) {
            throw new RuntimeException("Statut obligatoire");
        }

        Vehicule vehicule = vehiculeRepository.findById(dto.vehiculeId())
                .orElseThrow(() -> new RuntimeException("Véhicule introuvable"));

        Vidange v = new Vidange();
        v.setVehicule(vehicule);
        v.setDateVidange(dto.dateVidange());
        v.setKilometrageVidange(dto.kilometrageVidange());
        v.setTypeHuile(dto.typeHuile());
        v.setCout(dto.cout());
        v.setRemarque(dto.remarque());
        v.setProchaineDate(dto.prochaineDate());
        v.setProchainKilometrage(dto.prochainKilometrage());
        v.setStatut(dto.statut());

        vidangeRepository.save(v);

        return toDto(v);
    }

    public VidangeDto update(Integer id, VidangeDto dto) {
        Vidange v = vidangeRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Vidange introuvable"));

        if (dto.vehiculeId() != null) {
            Vehicule vehicule = vehiculeRepository.findById(dto.vehiculeId())
                    .orElseThrow(() -> new RuntimeException("Véhicule introuvable"));
            v.setVehicule(vehicule);
        }

        v.setDateVidange(dto.dateVidange());
        v.setKilometrageVidange(dto.kilometrageVidange());
        v.setTypeHuile(dto.typeHuile());
        v.setCout(dto.cout());
        v.setRemarque(dto.remarque());
        v.setProchaineDate(dto.prochaineDate());
        v.setProchainKilometrage(dto.prochainKilometrage());
        v.setStatut(dto.statut());

        vidangeRepository.save(v);

        return toDto(v);
    }

    public void delete(Integer id) {
        vidangeRepository.deleteById(id);
    }

    private VidangeDto toDto(Vidange v) {
        return new VidangeDto(
                v.getIdvidange(),
                v.getVehicule() != null ? v.getVehicule().getIdvehicule() : null,
                v.getVehicule() != null ? v.getVehicule().getImmatriculation() : null,
                v.getVehicule() != null ? v.getVehicule().getMarque() : null,
                v.getVehicule() != null ? v.getVehicule().getModele() : null,
                v.getDateVidange(),
                v.getKilometrageVidange(),
                v.getTypeHuile(),
                v.getCout(),
                v.getRemarque(),
                v.getProchaineDate(),
                v.getProchainKilometrage(),
                v.getStatut()
        );
    }
}