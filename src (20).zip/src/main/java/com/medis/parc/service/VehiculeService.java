package com.medis.parc.service;

import com.medis.parc.dto.VehiculeDto;
import com.medis.parc.entity.Vehicule;
import com.medis.parc.repository.VehiculeRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class VehiculeService {

    private final VehiculeRepository vehiculeRepository;

    public VehiculeService(VehiculeRepository vehiculeRepository) {
        this.vehiculeRepository = vehiculeRepository;
    }

    // GET ALL
    public List<VehiculeDto> getAll() {
        return vehiculeRepository.findAll()
                .stream()
                .map(v -> new VehiculeDto(
                        v.getIdvehicule(),
                        v.getImmatriculation(),
                        v.getMarque(),
                        v.getModele(),
                        v.getKilometrage(),
                        v.getEtat(),
                        v.getTypeCarburant(),
                        v.getDateAchat()
                ))
                .toList();
    }

    // CREATE
    public VehiculeDto create(VehiculeDto dto) {

        if (dto.immatriculation() == null || dto.immatriculation().isBlank()
                || dto.marque() == null || dto.marque().isBlank()
                || dto.modele() == null || dto.modele().isBlank()) {
            throw new RuntimeException("Immatriculation, Marque et Modèle obligatoires");
        }

        if (vehiculeRepository.existsByImmatriculation(dto.immatriculation())) {
            throw new RuntimeException("Immatriculation déjà existante");
        }

        Vehicule v = new Vehicule();
        v.setImmatriculation(dto.immatriculation());
        v.setMarque(dto.marque());
        v.setModele(dto.modele());
        v.setKilometrage(dto.kilometrage());
        v.setEtat(dto.etat());
        v.setTypeCarburant(dto.typeCarburant());
        v.setDateAchat(dto.dateAchat());

        vehiculeRepository.save(v);

        return new VehiculeDto(
                v.getIdvehicule(),
                v.getImmatriculation(),
                v.getMarque(),
                v.getModele(),
                v.getKilometrage(),
                v.getEtat(),
                v.getTypeCarburant(),
                v.getDateAchat()
        );
    }

    // UPDATE
    public VehiculeDto update(Integer id, VehiculeDto dto) {

        Vehicule v = vehiculeRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Véhicule introuvable"));

        v.setImmatriculation(dto.immatriculation());
        v.setMarque(dto.marque());
        v.setModele(dto.modele());
        v.setKilometrage(dto.kilometrage());
        v.setEtat(dto.etat());
        v.setTypeCarburant(dto.typeCarburant());
        v.setDateAchat(dto.dateAchat());

        vehiculeRepository.save(v);

        return new VehiculeDto(
                v.getIdvehicule(),
                v.getImmatriculation(),
                v.getMarque(),
                v.getModele(),
                v.getKilometrage(),
                v.getEtat(),
                v.getTypeCarburant(),
                v.getDateAchat()
        );
    }

    // DELETE
    public void delete(Integer id) {
        vehiculeRepository.deleteById(id);
    }
}