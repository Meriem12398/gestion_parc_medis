package com.medis.parc.service;

import com.medis.parc.dto.ResetPasswordRequest;
import com.medis.parc.dto.UtilisateurDto;
import com.medis.parc.entity.Utilisateur;
import com.medis.parc.repository.UtilisateurRepository;

import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class UtilisateurService {

    private final UtilisateurRepository utilisateurRepository;

    public UtilisateurService(UtilisateurRepository utilisateurRepository) {
        this.utilisateurRepository = utilisateurRepository;
    }

    public List<UtilisateurDto> getAll() {
        return utilisateurRepository.findAll().stream()
                .map(u -> new UtilisateurDto(
                        u.getMatricule(),
                        u.getNom(),
                        u.getPrenom(),
                        u.getEmail(),
                        u.getTelephone(),
                        u.getDepartement(),
                        u.getType_permis(),
                        u.getDisponibilite(),
                        u.getRole(),
                        null
                ))
                .toList();
    }

    public List<UtilisateurDto> getChauffeurs() {
        return utilisateurRepository.findByRole("CHAUFFEUR").stream()
                .map(u -> new UtilisateurDto(
                        u.getMatricule(),
                        u.getNom(),
                        u.getPrenom(),
                        u.getEmail(),
                        u.getTelephone(),
                        u.getDepartement(),
                        u.getType_permis(),
                        u.getDisponibilite(),
                        u.getRole(),
                        null
                ))
                .toList();
    }

    // ✅ NEW: DEMANDEURS
    public List<UtilisateurDto> getDemandeurs() {
        return utilisateurRepository.findByRole("DEMANDEUR").stream()
                .map(u -> new UtilisateurDto(
                        u.getMatricule(),
                        u.getNom(),
                        u.getPrenom(),
                        u.getEmail(),
                        u.getTelephone(),
                        u.getDepartement(),
                        u.getType_permis(),
                        u.getDisponibilite(),
                        u.getRole(),
                        null
                ))
                .toList();
    }

    //DELETE
    public void delete(Integer matricule) {
        utilisateurRepository.deleteById(matricule);
    }

    // ✅ UPDATE (FIXED)
    public UtilisateurDto update(Integer matricule, UtilisateurDto dto) {

        Utilisateur u = utilisateurRepository.findById(matricule)
                .orElseThrow(() -> new RuntimeException("Utilisateur introuvable"));

        // basic fields (only if provided)
        if (dto.nom() != null) u.setNom(dto.nom());
        if (dto.prenom() != null) u.setPrenom(dto.prenom());
        if (dto.email() != null) u.setEmail(dto.email());
        if (dto.telephone() != null) u.setTelephone(dto.telephone());
        if (dto.departement() != null) u.setDepartement(dto.departement());

        // role
        String role = (dto.role() == null || dto.role().isBlank())
                ? u.getRole()
                : dto.role().toUpperCase();
        u.setRole(role);

        // role-specific fields
        if ("CHAUFFEUR".equals(role)) {
            // type permis only if provided
            if (dto.typePermis() != null) {
                u.setType_permis(dto.typePermis());
            }
            // disponibilite only if provided
            if (dto.disponibilite() != null) {
                u.setDisponibilite(dto.disponibilite());
            }
            if (u.getDisponibilite() == null) u.setDisponibilite(1);

        } else { // DEMANDEUR
            u.setType_permis(null);
            u.setDisponibilite(1);
        }

        // motDePasse optional: only change if real value sent
        if (dto.motDePasse() != null && !dto.motDePasse().trim().isEmpty()) {
            u.setMotdepasse(new org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder()
                    .encode(dto.motDePasse()));
        }

        utilisateurRepository.save(u);

        return new UtilisateurDto(
                u.getMatricule(),
                u.getNom(),
                u.getPrenom(),
                u.getEmail(),
                u.getTelephone(),
                u.getDepartement(),
                u.getType_permis(),
                u.getDisponibilite(),
                u.getRole(),
                null
        );
    }

    // ✅ CREATE (ADD USER: CHAUFFEUR / DEMANDEUR)
    public UtilisateurDto create(UtilisateurDto dto) {

        if (dto.nom() == null || dto.nom().isBlank()
                || dto.prenom() == null || dto.prenom().isBlank()
                || dto.email() == null || dto.email().isBlank()) {
            throw new RuntimeException("Nom, Prénom et Email obligatoires");
        }

        if (dto.motDePasse() == null || dto.motDePasse().isBlank()) {
            throw new RuntimeException("Mot de passe obligatoire");
        }

        if (utilisateurRepository.existsByEmail(dto.email())) {
            throw new RuntimeException("Email déjà existant");
        }

        String role = (dto.role() == null || dto.role().isBlank())
                ? "CHAUFFEUR"
                : dto.role().toUpperCase();

        Utilisateur u = new Utilisateur();

        u.setNom(dto.nom().trim());
        u.setPrenom(dto.prenom().trim());
        u.setEmail(dto.email().trim());
        u.setTelephone(dto.telephone());
        u.setDepartement(dto.departement());
        u.setRole(role);

        if ("CHAUFFEUR".equals(role)) {

            if (dto.typePermis() == null || dto.typePermis().isBlank()) {
                throw new RuntimeException("Type permis obligatoire pour chauffeur");
            }

            u.setType_permis(dto.typePermis());
            u.setDisponibilite(dto.disponibilite() == null ? 1 : dto.disponibilite());

        } else { // DEMANDEUR
            u.setType_permis(null);
            u.setDisponibilite(1);
        }

        u.setMotdepasse(new org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder()
                .encode(dto.motDePasse()));

        utilisateurRepository.save(u);

        return new UtilisateurDto(
                u.getMatricule(),
                u.getNom(),
                u.getPrenom(),
                u.getEmail(),
                u.getTelephone(),
                u.getDepartement(),
                u.getType_permis(),
                u.getDisponibilite(),
                u.getRole(),
                null
        );
    }
    public void resetPasswordByResponsable(Integer matricule, ResetPasswordRequest req) {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        String email = authentication.getName();

        Utilisateur responsable = utilisateurRepository.findByEmail(email)
                .orElseThrow(() -> new RuntimeException("Responsable introuvable"));

        if (responsable.getRole() == null || !responsable.getRole().equalsIgnoreCase("RESPONSABLE")) {
            throw new RuntimeException("Accès refusé");
        }

        Utilisateur user = utilisateurRepository.findById(matricule)
                .orElseThrow(() -> new RuntimeException("Utilisateur introuvable"));

        if (req == null || req.getNewPassword() == null || req.getNewPassword().isBlank()) {
            throw new RuntimeException("Nouveau mot de passe obligatoire");
        }

        String newPassword = req.getNewPassword().trim();

        if (newPassword.length() < 6) {
            throw new RuntimeException("Le mot de passe doit contenir au moins 6 caractères");
        }

        // اختياري: المسؤول ما يبدلش password متاعو من هنا
        if (user.getMatricule().equals(responsable.getMatricule())) {
            throw new RuntimeException("Utilisez l'écran de changement de mot de passe pour votre propre compte");
        }

        // اختياري: نسمح فقط لـ chauffeur و demandeur
        if (!"CHAUFFEUR".equalsIgnoreCase(user.getRole()) &&
            !"DEMANDEUR".equalsIgnoreCase(user.getRole())) {
            throw new RuntimeException("Réinitialisation autorisée uniquement pour chauffeur ou demandeur");
        }

        user.setMotdepasse(new BCryptPasswordEncoder().encode(newPassword));
        utilisateurRepository.save(user);
    }
}