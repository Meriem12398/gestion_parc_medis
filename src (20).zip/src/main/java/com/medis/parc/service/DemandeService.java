package com.medis.parc.service;

import com.medis.parc.dto.AffecterRequest;
import com.medis.parc.dto.CreateDemandeRequest;
import com.medis.parc.dto.DemandeDto;
import com.medis.parc.dto.UpdateDemandeRequest;
import com.medis.parc.dto.UpdateStatutRequest;
import com.medis.parc.entity.Demande;
import com.medis.parc.entity.Mission;
import com.medis.parc.entity.Utilisateur;
import com.medis.parc.entity.Vehicule;
import com.medis.parc.repository.DemandeRepository;
import com.medis.parc.repository.MissionRepository;
import com.medis.parc.repository.UtilisateurRepository;
import com.medis.parc.repository.VehiculeRepository;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;

@Service
public class DemandeService {

    private final DemandeRepository demandeRepository;
    private final MissionRepository missionRepository;
    private final VehiculeRepository vehiculeRepository;
    private final UtilisateurRepository utilisateurRepository;

    public DemandeService(
            DemandeRepository demandeRepository,
            MissionRepository missionRepository,
            VehiculeRepository vehiculeRepository,
            UtilisateurRepository utilisateurRepository
    ) {
        this.demandeRepository = demandeRepository;
        this.missionRepository = missionRepository;
        this.vehiculeRepository = vehiculeRepository;
        this.utilisateurRepository = utilisateurRepository;
    }

    public List<DemandeDto> getAll() {
        return demandeRepository.findAllWithCreateur()
                .stream()
                .map(this::toDto)
                .toList();
    }

    public List<DemandeDto> getAllFiltered(String statut, String priorite) {
        return demandeRepository.findAllWithCreateurFiltered(statut, priorite)
                .stream()
                .map(this::toDto)
                .toList();
    }

    public List<DemandeDto> getMesDemandes() {
        Utilisateur currentUser = getCurrentUtilisateur();

        return demandeRepository.findByMatriculeWithCreateur(currentUser.getMatricule())
                .stream()
                .map(this::toDto)
                .toList();
    }

    public DemandeDto createDemande(CreateDemandeRequest req) {
        Utilisateur currentUser = getCurrentUtilisateur();

        if (req == null) {
            throw new RuntimeException("Requête invalide");
        }

        if (req.getTypeDemande() == null || req.getTypeDemande().isBlank()) {
            throw new RuntimeException("Type de demande obligatoire");
        }

        if (req.getPriorite() == null || req.getPriorite().isBlank()) {
            throw new RuntimeException("Priorité obligatoire");
        }

        if (req.getDescription() == null || req.getDescription().isBlank()) {
            throw new RuntimeException("Description obligatoire");
        }

        if (req.getDateSouhaite() == null) {
            throw new RuntimeException("Date souhaitée obligatoire");
        }

        double score = calculerScorePriorite(req);
        String prioriteIa = determinerPrioriteIa(score);

        Demande d = new Demande();
        d.setTypeDemande(req.getTypeDemande().trim().toUpperCase());
        d.setPriorite(req.getPriorite().trim().toUpperCase());
        d.setDescription(req.getDescription().trim());
        d.setDateCreation(LocalDateTime.now());
        d.setDateSouhaite(req.getDateSouhaite());
        d.setStatut("EN_ATTENTE");
        d.setMatricule(currentUser.getMatricule());

        d.setScorePriorite(score);
        d.setPrioriteIa(prioriteIa);

        Demande saved = demandeRepository.save(d);
        return toDto(saved);
    }

    public DemandeDto updateDemandeByDemandeur(Integer id, UpdateDemandeRequest req) {
        Utilisateur currentUser = getCurrentUtilisateur();

        Demande d = demandeRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Demande introuvable"));

        if (d.getMatricule() == null || !d.getMatricule().equals(currentUser.getMatricule())) {
            throw new RuntimeException("Vous ne pouvez modifier que vos propres demandes");
        }

        String statut = d.getStatut() == null ? "" : d.getStatut().trim().toUpperCase();
        if (!"EN_ATTENTE".equals(statut) && !"EN ATTENTE".equals(statut)) {
            throw new RuntimeException("Modification autorisée uniquement pour une demande en attente");
        }

        if (req == null) {
            throw new RuntimeException("Requête invalide");
        }

        if (req.getTypeDemande() == null || req.getTypeDemande().isBlank()) {
            throw new RuntimeException("Type de demande obligatoire");
        }

        if (req.getPriorite() == null || req.getPriorite().isBlank()) {
            throw new RuntimeException("Priorité obligatoire");
        }

        if (req.getDescription() == null || req.getDescription().isBlank()) {
            throw new RuntimeException("Description obligatoire");
        }

        if (req.getDateSouhaite() == null) {
            throw new RuntimeException("Date souhaitée obligatoire");
        }

        d.setTypeDemande(req.getTypeDemande().trim().toUpperCase());
        d.setPriorite(req.getPriorite().trim().toUpperCase());
        d.setDescription(req.getDescription().trim());
        d.setDateSouhaite(req.getDateSouhaite());

        // recalcul IA
        CreateDemandeRequest temp = new CreateDemandeRequest();
        temp.setTypeDemande(req.getTypeDemande());
        temp.setPriorite(req.getPriorite());
        temp.setDescription(req.getDescription());
        temp.setDateSouhaite(req.getDateSouhaite());

        double score = calculerScorePriorite(temp);
        String prioriteIa = determinerPrioriteIa(score);

        d.setScorePriorite(score);
        d.setPrioriteIa(prioriteIa);

        Demande saved = demandeRepository.save(d);
        return toDto(saved);
    }

    public void deleteDemandeByDemandeur(Integer id) {
        Utilisateur currentUser = getCurrentUtilisateur();

        Demande d = demandeRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Demande introuvable"));

        if (d.getMatricule() == null || !d.getMatricule().equals(currentUser.getMatricule())) {
            throw new RuntimeException("Vous ne pouvez supprimer que vos propres demandes");
        }

        String statut = d.getStatut() == null ? "" : d.getStatut().trim().toUpperCase();
        if (!"EN_ATTENTE".equals(statut) && !"EN ATTENTE".equals(statut)) {
            throw new RuntimeException("Suppression autorisée uniquement pour une demande en attente");
        }

        demandeRepository.delete(d);
    }

    public void updateStatut(Integer id, UpdateStatutRequest req) {
        Demande d = demandeRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Demande introuvable: " + id));

        if (req == null || req.getStatut() == null || req.getStatut().isBlank()) {
            throw new RuntimeException("Statut obligatoire");
        }

        String statut = req.getStatut().trim().toUpperCase();
        d.setStatut(statut);

        if ("REFUSEE".equals(statut) || "REFUSÉE".equals(statut)) {
            if (req.getMotif() == null || req.getMotif().isBlank()) {
                throw new RuntimeException("Le motif de refus est obligatoire");
            }
            d.setMotifRefus(req.getMotif().trim());
        } else {
            d.setMotifRefus(null);
        }

        demandeRepository.save(d);
    }

    public void affecter(Integer iddemande, AffecterRequest req) {
        Demande d = demandeRepository.findById(iddemande)
                .orElseThrow(() -> new RuntimeException("Demande introuvable: " + iddemande));

        if (req == null || req.getIdvehicule() == null) {
            throw new RuntimeException("idvehicule obligatoire");
        }

        missionRepository.findByIddemande(iddemande).ifPresent(m -> {
            throw new RuntimeException("Demande déjà affectée (Mission existe déjà)");
        });

        Vehicule v = vehiculeRepository.findById(req.getIdvehicule())
                .orElseThrow(() -> new RuntimeException("Vehicule introuvable: " + req.getIdvehicule()));

        LocalDateTime debut = (req.getDateDebut() != null) ? req.getDateDebut() : LocalDateTime.now();

        Mission mission = new Mission();
        mission.setIddemande(iddemande);
        mission.setIdvehicule(v.getIdvehicule());
        mission.setDateDebut(debut);
        mission.setStatutMission("EN_COURS");

        if (req.getChauffeurMatricule() != null) {
            mission.setChauffeurMatricule(req.getChauffeurMatricule());
        }

        missionRepository.save(mission);

        d.setStatut("AFFECTEE");
        demandeRepository.save(d);

        v.setEtat("Indisponible");
        vehiculeRepository.save(v);

        if (req.getChauffeurMatricule() != null) {
            utilisateurRepository.findById(req.getChauffeurMatricule()).ifPresent(ch -> {
                ch.setDisponibilite(0);
                utilisateurRepository.save(ch);
            });
        }
    }

    private Utilisateur getCurrentUtilisateur() {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        String email = authentication.getName();

        return utilisateurRepository.findByEmail(email)
                .orElseThrow(() -> new RuntimeException("Utilisateur connecté introuvable"));
    }

    private DemandeDto toDto(Demande d) {
        DemandeDto dto = new DemandeDto();
        dto.setIddemande(d.getIddemande());
        dto.setTypeDemande(d.getTypeDemande());
        dto.setDateCreation(d.getDateCreation());
        dto.setDateSouhaite(d.getDateSouhaite());
        dto.setStatut(d.getStatut());
        dto.setPriorite(d.getPriorite());
        dto.setDescription(d.getDescription());
        dto.setMatricule(d.getMatricule());
        dto.setMotifRefus(d.getMotifRefus());

        dto.setScorePriorite(d.getScorePriorite());
        dto.setPrioriteIa(d.getPrioriteIa());

        Utilisateur u = d.getCreateur();
        if (u == null && d.getMatricule() != null) {
            u = utilisateurRepository.findById(d.getMatricule()).orElse(null);
        }

        if (u != null) {
            dto.setNomCreateur(u.getNom());
            dto.setPrenomCreateur(u.getPrenom());
            dto.setDepartementCreateur(u.getDepartement());
        }

        return dto;
    }
    
    private double calculerScorePriorite(CreateDemandeRequest req) {
        double score = 0;

        String type = req.getTypeDemande() == null ? "" : req.getTypeDemande().trim().toUpperCase();
        String prioriteUser = req.getPriorite() == null ? "" : req.getPriorite().trim().toUpperCase();

        if ("MAINTENANCE".equals(type)) score += 20;
        if ("REPARATION".equals(type) || "RÉPARATION".equals(type)) score += 35;
        if ("CONTROLE".equals(type) || "CONTRÔLE".equals(type)) score += 15;
        if ("DEPLACEMENT".equals(type) || "DÉPLACEMENT".equals(type)) score += 25;

        if ("FAIBLE".equals(prioriteUser)) score += 10;
        if ("MOYENNE".equals(prioriteUser)) score += 25;
        if ("HAUTE".equals(prioriteUser)) score += 40;
        if ("URGENTE".equals(prioriteUser)) score += 50;

        if (req.getDateSouhaite() != null) {
            LocalDateTime now = LocalDateTime.now();
            if (req.getDateSouhaite().isBefore(now.plusDays(1))) {
                score += 25;
            } else if (req.getDateSouhaite().isBefore(now.plusDays(3))) {
                score += 15;
            } else {
                score += 5;
            }
        }

        return Math.min(score, 100);
    }

    private String determinerPrioriteIa(double score) {
        if (score >= 70) return "HAUTE";
        if (score >= 40) return "MOYENNE";
        return "FAIBLE";
    }
}