package com.medis.parc.service;

import com.medis.parc.entity.Incident;
import com.medis.parc.repository.IncidentRepository;
import com.medis.parc.repository.MissionRepository;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;

@Service
public class IncidentService {

    private final IncidentRepository incidentRepository;
    private final MissionRepository missionRepository;

    public IncidentService(IncidentRepository incidentRepository,
                           MissionRepository missionRepository) {
        this.incidentRepository = incidentRepository;
        this.missionRepository = missionRepository;
    }

    public Incident createIncident(Incident incident) {
        if (incident.getIdmission() == null) {
            throw new RuntimeException("Mission obligatoire");
        }

        missionRepository.findById(incident.getIdmission())
                .orElseThrow(() -> new RuntimeException("Mission introuvable"));

        if (incident.getTypeIncident() == null || incident.getTypeIncident().isBlank()) {
            throw new RuntimeException("Type incident obligatoire");
        }

        if (incident.getDescription() == null || incident.getDescription().isBlank()) {
            throw new RuntimeException("Description obligatoire");
        }

        incident.setDateIncident(LocalDateTime.now());

        return incidentRepository.save(incident);
    }

    public List<Incident> getAllIncidents() {
        return incidentRepository.findAllByOrderByIdincidentDesc();
    }
}