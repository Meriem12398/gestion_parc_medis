package com.medis.parc.service;

import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.medis.parc.dto.ChangePasswordRequest;
import com.medis.parc.dto.LoginRequest;
import com.medis.parc.dto.LoginResponse;
import com.medis.parc.entity.Utilisateur;
import com.medis.parc.repository.PasswordResetTokenRepository;
import com.medis.parc.repository.UtilisateurRepository;
import com.medis.parc.security.JwtService;


import com.medis.parc.dto.ForgotPasswordRequest;
import com.medis.parc.dto.ResetPasswordRequest;
import com.medis.parc.entity.PasswordResetToken;

import java.time.LocalDateTime;
import java.util.UUID;

@Service
public class AuthService {

    private final UtilisateurRepository repo;
    private final PasswordEncoder encoder;
    private final JwtService jwtService;

    private final PasswordResetTokenRepository tokenRepository;
    private final EmailService emailService;
    
    
    public AuthService(
            UtilisateurRepository repo,
            PasswordEncoder encoder,
            JwtService jwtService,
            PasswordResetTokenRepository tokenRepository,
            EmailService emailService
    ) {
        this.repo = repo;
        this.encoder = encoder;
        this.jwtService = jwtService;
        this.tokenRepository = tokenRepository;
        this.emailService = emailService;
    }

    public LoginResponse login(LoginRequest req) {
        Utilisateur u = repo.findByEmail(req.getEmail())
                .orElseThrow(() -> new RuntimeException("Email ou mot de passe incorrect"));

        if (!encoder.matches(req.getMotdepasse(), u.getMotdepasse())) {
            throw new RuntimeException("Email ou mot de passe incorrect");
        }

        String token = jwtService.generateToken(u.getEmail(), u.getRole());

        return new LoginResponse(
                token,
                u.getMatricule(),
                u.getNom(),
                u.getPrenom(),
                u.getEmail(),
                u.getRole()
        );
    }

    public void changePassword(ChangePasswordRequest req) {

        if (req.email() == null || req.email().isBlank()) {
            throw new RuntimeException("Email obligatoire");
        }

        if (req.ancienMotDePasse() == null || req.ancienMotDePasse().isBlank()) {
            throw new RuntimeException("Mot de passe actuel obligatoire");
        }

        if (req.nouveauMotDePasse() == null || req.nouveauMotDePasse().isBlank()) {
            throw new RuntimeException("Nouveau mot de passe obligatoire");
        }

        if (req.nouveauMotDePasse().trim().length() < 6) {
            throw new RuntimeException("Le nouveau mot de passe doit contenir au moins 6 caractères");
        }

        Utilisateur u = repo.findByEmail(req.email())
                .orElseThrow(() -> new RuntimeException("Utilisateur introuvable"));

        if (!encoder.matches(req.ancienMotDePasse(), u.getMotdepasse())) {
            throw new RuntimeException("Mot de passe actuel incorrect");
        }

        u.setMotdepasse(encoder.encode(req.nouveauMotDePasse()));
        repo.save(u);
    }
    
    public void forgotPassword(ForgotPasswordRequest req) {

        System.out.println("EMAIL: " + req.getEmail());

        if (req.getEmail() == null || req.getEmail().isBlank()) {
            throw new RuntimeException("Email obligatoire");
        }

        Utilisateur u = repo.findByEmail(req.getEmail())
                .orElseThrow(() -> new RuntimeException("EMAIL_NOT_FOUND"));

        System.out.println("USER FOUND: " + u.getEmail());

        String token = UUID.randomUUID().toString();
        System.out.println("TOKEN: " + token);

        PasswordResetToken resetToken = new PasswordResetToken();
        resetToken.setToken(token);
        resetToken.setUtilisateur(u);
        resetToken.setExpirationDate(LocalDateTime.now().plusMinutes(30));
        resetToken.setUsed(false);

        tokenRepository.save(resetToken);
        System.out.println("TOKEN SAVED");

        String resetLink = "http://localhost:4200/reset-password?token=" + token;
        System.out.println("RESET LINK: " + resetLink);

        try {
            emailService.sendMail(
                    u.getEmail(),
                    "Réinitialisation du mot de passe",
                    "Bonjour,\n\n"
                            + "Cliquez sur ce lien pour réinitialiser votre mot de passe :\n"
                            + resetLink
                            + "\n\nCe lien expire dans 30 minutes."
            );
            System.out.println("MAIL SENT OK");
        } catch (Exception e) {
            e.printStackTrace();
            throw new RuntimeException("MAIL_ERROR: " + e.getMessage());
        }

        System.out.println("END FORGOT PASSWORD");
    }
    
    public void resetPassword(ResetPasswordRequest req) {

        if (req.getToken() == null || req.getToken().isBlank()) {
            throw new RuntimeException("Token obligatoire");
        }

        if (req.getNewPassword() == null || req.getNewPassword().isBlank()) {
            throw new RuntimeException("Mot de passe obligatoire");
        }

        PasswordResetToken resetToken = tokenRepository.findByToken(req.getToken())
                .orElseThrow(() -> new RuntimeException("Token invalide"));

        if (resetToken.isUsed()) {
            throw new RuntimeException("Token déjà utilisé");
        }

        if (resetToken.getExpirationDate().isBefore(LocalDateTime.now())) {
            throw new RuntimeException("Token expiré");
        }

        Utilisateur u = resetToken.getUtilisateur();
        u.setMotdepasse(encoder.encode(req.getNewPassword()));

        repo.save(u);

        resetToken.setUsed(true);
        tokenRepository.save(resetToken);
    }
}