package com.medis.parc.service;

import com.medis.parc.dto.CreateInterventionRequest;
import com.medis.parc.dto.InterventionHistoriqueDto;
import com.medis.parc.entity.Incident;
import com.medis.parc.entity.Intervention;
import com.medis.parc.entity.Mission;
import com.medis.parc.entity.Vehicule;
import com.medis.parc.repository.IncidentRepository;
import com.medis.parc.repository.InterventionRepository;
import com.medis.parc.repository.MissionRepository;
import com.medis.parc.repository.VehiculeRepository;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@Service
public class InterventionService {

    private final InterventionRepository interventionRepository;
    private final IncidentRepository incidentRepository;
    private final MissionRepository missionRepository;
    private final VehiculeRepository vehiculeRepository;

    public InterventionService(InterventionRepository interventionRepository,
                               IncidentRepository incidentRepository,
                               MissionRepository missionRepository,
                               VehiculeRepository vehiculeRepository) {
        this.interventionRepository = interventionRepository;
        this.incidentRepository = incidentRepository;
        this.missionRepository = missionRepository;
        this.vehiculeRepository = vehiculeRepository;
    }

    public Intervention createIntervention(CreateInterventionRequest req) {

        if (req == null) {
            throw new RuntimeException("Requête invalide");
        }

        if (req.getIdincident() == null) {
            throw new RuntimeException("Incident obligatoire");
        }

        Incident incident = incidentRepository.findById(req.getIdincident())
                .orElseThrow(() -> new RuntimeException("Incident introuvable"));

        if (interventionRepository.existsByIdincident(incident.getIdincident())) {
            throw new RuntimeException("Une intervention existe déjà pour cet incident");
        }

        if (req.getTypeIntervention() == null || req.getTypeIntervention().isBlank()) {
            throw new RuntimeException("Type intervention obligatoire");
        }

        if (req.getDescription() == null || req.getDescription().isBlank()) {
            throw new RuntimeException("Description obligatoire");
        }

        Intervention intervention = new Intervention();
        intervention.setIdincident(incident.getIdincident());
        intervention.setTypeIntervention(req.getTypeIntervention().trim());
        intervention.setDescription(req.getDescription().trim());
        intervention.setCout(req.getCout());
        intervention.setDateIntervention(LocalDateTime.now());

        return interventionRepository.save(intervention);
    }

    public List<Intervention> getAllInterventions() {
        return interventionRepository.findAllByOrderByIdinterventionDesc();
    }

    public List<InterventionHistoriqueDto> getAllInterventionsHistorique() {
        List<Intervention> interventions = interventionRepository.findAllByOrderByIdinterventionDesc();
        List<InterventionHistoriqueDto> result = new ArrayList<>();

        for (Intervention i : interventions) {
            InterventionHistoriqueDto dto = new InterventionHistoriqueDto();
            dto.setIdintervention(i.getIdintervention());
            dto.setDateIntervention(i.getDateIntervention());
            dto.setTypeIntervention(i.getTypeIntervention());
            dto.setDescription(i.getDescription());
            dto.setCout(i.getCout());
            dto.setIdincident(i.getIdincident());

            if (i.getIdincident() != null) {
                incidentRepository.findById(i.getIdincident()).ifPresent(incident -> {
                    dto.setIdmission(incident.getIdmission());

                    if (incident.getIdmission() != null) {
                        missionRepository.findById(incident.getIdmission()).ifPresent(mission -> {
                            dto.setIdvehicule(mission.getIdvehicule());

                            if (mission.getIdvehicule() != null) {
                                vehiculeRepository.findById(mission.getIdvehicule()).ifPresent(v -> {
                                    dto.setImmatriculationVehicule(v.getImmatriculation());
                                    dto.setMarqueVehicule(v.getMarque());
                                    dto.setModeleVehicule(v.getModele());
                                });
                            }
                        });
                    }
                });
            }

            result.add(dto);
        }

        return result;
    }

    public List<Intervention> getByIncident(Integer idincident) {
        return interventionRepository.findByIdincidentOrderByIdinterventionDesc(idincident);
    }

    public boolean hasIntervention(Integer idincident) {
        return interventionRepository.existsByIdincident(idincident);
    }
}