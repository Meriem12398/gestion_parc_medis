package com.medis.parc.service;

import com.medis.parc.dto.AnnulerMissionRequest;
import com.medis.parc.dto.CreateIncidentRequest;
import com.medis.parc.dto.CreateMissionGroupRequest;
import com.medis.parc.dto.DemandeMiniDto;
import com.medis.parc.dto.MissionDetailsDto;
import com.medis.parc.dto.MissionDto;
import com.medis.parc.entity.Demande;
import com.medis.parc.entity.Incident;
import com.medis.parc.entity.Mission;
import com.medis.parc.entity.MissionDemande;
import com.medis.parc.entity.Utilisateur;
import com.medis.parc.entity.Vehicule;
import com.medis.parc.repository.DemandeRepository;
import com.medis.parc.repository.IncidentRepository;
import com.medis.parc.repository.MissionDemandeRepository;
import com.medis.parc.repository.MissionRepository;
import com.medis.parc.repository.UtilisateurRepository;
import com.medis.parc.repository.VehiculeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.time.format.DateTimeFormatter;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@Service
public class MissionService {

    @Autowired
    private MissionRepository missionRepository;

    @Autowired
    private DemandeRepository demandeRepository;

    @Autowired
    private VehiculeRepository vehiculeRepository;

    @Autowired
    private UtilisateurRepository utilisateurRepository;

    @Autowired
    private MissionDemandeRepository missionDemandeRepository;

    @Autowired
    private IncidentRepository incidentRepository;

    
    @Autowired
    private EmailService emailService;

    @Transactional
    public Mission creerMissionGroupee(CreateMissionGroupRequest req) {

        if (req.getDemandeIds() == null || req.getDemandeIds().isEmpty()) {
            throw new RuntimeException("Aucune demande sélectionnée");
        }

        if (req.getVehiculeId() == null) {
            throw new RuntimeException("Véhicule obligatoire");
        }

        if (req.getChauffeurMatricule() == null) {
            throw new RuntimeException("Chauffeur obligatoire");
        }

        if (req.getDateDebut() == null) {
            throw new RuntimeException("Date début obligatoire");
        }

        Vehicule vehicule = vehiculeRepository.findById(req.getVehiculeId())
                .orElseThrow(() -> new RuntimeException("Véhicule introuvable"));

        Utilisateur chauffeur = utilisateurRepository.findById(req.getChauffeurMatricule())
                .orElseThrow(() -> new RuntimeException("Chauffeur introuvable"));

        if (vehicule.getEtat() == null || !vehicule.getEtat().equalsIgnoreCase("Disponible")) {
            throw new RuntimeException("Véhicule non disponible");
        }

        if (chauffeur.getDisponibilite() == null || chauffeur.getDisponibilite() != 1) {
            throw new RuntimeException("Chauffeur non disponible");
        }

        List<Demande> demandes = demandeRepository.findAllById(req.getDemandeIds());

        if (demandes.size() != req.getDemandeIds().size()) {
            throw new RuntimeException("Certaines demandes n'existent pas");
        }

        for (Demande d : demandes) {
            String st = (d.getStatut() == null) ? "" : d.getStatut().trim().toUpperCase();
            if (!st.contains("VALID")) {
                throw new RuntimeException("Toutes les demandes doivent être VALIDEE");
            }
        }

        Mission mission = new Mission();
        mission.setIdvehicule(vehicule.getIdvehicule());
        mission.setChauffeurMatricule(chauffeur.getMatricule());
        mission.setDateDebut(req.getDateDebut());
        mission.setStatutMission("EN_COURS");
        mission.setIddemande(demandes.get(0).getIddemande());

        Mission saved = missionRepository.save(mission);

        for (Demande d : demandes) {
            missionDemandeRepository.save(new MissionDemande(saved.getIdmission(), d.getIddemande()));
            d.setStatut("AFFECTEE");
            demandeRepository.save(d);
        }

        vehicule.setEtat("Indisponible");
        vehiculeRepository.save(vehicule);

        chauffeur.setDisponibilite(0);
        utilisateurRepository.save(chauffeur);

        try {
            sendMissionAssignedEmail(saved, chauffeur, vehicule, demandes);
        } catch (Exception e) {
            System.err.println("Erreur envoi mail mission : " + e.getMessage());
        }

        return saved;
    }

    @Transactional
    public Mission terminerMission(Integer idMission) {
        Mission mission = missionRepository.findById(idMission)
                .orElseThrow(() -> new RuntimeException("Mission introuvable"));

        if ("TERMINEE".equalsIgnoreCase(mission.getStatutMission())) {
            return mission;
        }

        mission.setStatutMission("TERMINEE");
        mission.setDateFin(LocalDateTime.now());
        Mission saved = missionRepository.save(mission);

        libererVehiculeEtChauffeur(saved);

        return saved;
    }

    @Transactional
    public Mission annulerMission(Integer idMission, AnnulerMissionRequest req) {
        Mission mission = missionRepository.findById(idMission)
                .orElseThrow(() -> new RuntimeException("Mission introuvable"));

        if (req == null || req.getMotif() == null || req.getMotif().trim().isEmpty()) {
            throw new RuntimeException("Motif d'annulation obligatoire");
        }

        mission.setStatutMission("ANNULEE");
        mission.setMotifAnnulation(req.getMotif().trim());
        mission.setDateFin(LocalDateTime.now());

        Mission saved = missionRepository.save(mission);

        try {
            sendMissionCancelledEmail(saved);
        } catch (Exception e) {
            System.err.println("Erreur envoi mail annulation mission : " + e.getMessage());
        }

        libererVehiculeEtChauffeur(saved);

        return saved;
    }

    @Transactional
    public Incident creerIncident(CreateIncidentRequest req) {
        if (req.getIdmission() == null) {
            throw new RuntimeException("Mission obligatoire");
        }

        if (req.getTypeIncident() == null || req.getTypeIncident().trim().isEmpty()) {
            throw new RuntimeException("Type incident obligatoire");
        }

        if (req.getDescription() == null || req.getDescription().trim().isEmpty()) {
            throw new RuntimeException("Description obligatoire");
        }

        Mission mission = missionRepository.findById(req.getIdmission())
                .orElseThrow(() -> new RuntimeException("Mission introuvable"));

        Incident incident = new Incident();
        incident.setIdmission(mission.getIdmission());
        incident.setDateIncident(LocalDateTime.now());
        incident.setTypeIncident(req.getTypeIncident().trim());
        incident.setDescription(req.getDescription().trim());

        Incident savedIncident = incidentRepository.save(incident);

        try {
            sendIncidentEmail(savedIncident, mission);
        } catch (Exception e) {
            System.err.println("Erreur envoi mail incident : " + e.getMessage());
        }

        return savedIncident;
    }

    public List<MissionDto> getMissionsDuChauffeurConnecte() {
        Utilisateur chauffeur = getCurrentUtilisateur();

        List<Mission> missions = missionRepository.findByChauffeurMatriculeOrderByIdmissionDesc(chauffeur.getMatricule());
        List<MissionDto> result = new ArrayList<>();

        for (Mission m : missions) {
            result.add(toDto(m));
        }

        return result;
    }

    public List<Mission> getAllMissions() {
        return missionRepository.findAll()
                .stream()
                .sorted((a, b) -> b.getIdmission().compareTo(a.getIdmission()))
                .toList();
    }

    public List<MissionDto> getAllMissionDtos() {
        List<Mission> missions = missionRepository.findAll();
        List<MissionDto> result = new ArrayList<>();

        for (Mission m : missions) {
            result.add(toDto(m));
        }

        result.sort((a, b) -> b.getIdmission().compareTo(a.getIdmission()));
        return result;
    }

    public MissionDetailsDto getMissionDetails(Integer idMission) {
        Mission mission = missionRepository.findById(idMission)
                .orElseThrow(() -> new RuntimeException("Mission introuvable"));

        MissionDetailsDto dto = new MissionDetailsDto();
        dto.setIdmission(mission.getIdmission());
        dto.setDateDebut(mission.getDateDebut());
        dto.setDateFin(mission.getDateFin());
        dto.setStatutMission(mission.getStatutMission());
        dto.setIdvehicule(mission.getIdvehicule());
        dto.setChauffeurMatricule(mission.getChauffeurMatricule());

        if (mission.getIdvehicule() != null) {
            vehiculeRepository.findById(mission.getIdvehicule()).ifPresent(v -> {
                dto.setImmatriculationVehicule(v.getImmatriculation());
            });
        }

        if (mission.getChauffeurMatricule() != null) {
            utilisateurRepository.findById(mission.getChauffeurMatricule()).ifPresent(u -> {
                dto.setChauffeurNom(u.getNom());
                dto.setChauffeurPrenom(u.getPrenom());
            });
        }

        List<DemandeMiniDto> demandesDtos = new ArrayList<>();
        List<MissionDemande> links = missionDemandeRepository.findByIdmission(idMission);

        for (MissionDemande link : links) {
            demandeRepository.findById(link.getIddemande()).ifPresent(d -> {
                DemandeMiniDto dd = new DemandeMiniDto();
                dd.setIddemande(d.getIddemande());
                dd.setTypeDemande(d.getTypeDemande());
                dd.setStatut(d.getStatut());
                dd.setPriorite(d.getPriorite());
                dd.setDescription(d.getDescription());
                demandesDtos.add(dd);
            });
        }

        if (demandesDtos.isEmpty() && mission.getIddemande() != null) {
            demandeRepository.findById(mission.getIddemande()).ifPresent(d -> {
                DemandeMiniDto dd = new DemandeMiniDto();
                dd.setIddemande(d.getIddemande());
                dd.setTypeDemande(d.getTypeDemande());
                dd.setStatut(d.getStatut());
                dd.setPriorite(d.getPriorite());
                dd.setDescription(d.getDescription());
                demandesDtos.add(dd);
            });
        }

        dto.setDemandes(demandesDtos);
        return dto;
    }

    private MissionDto toDto(Mission m) {
        MissionDto dto = new MissionDto();

        dto.setIdmission(m.getIdmission());
        dto.setDateDebut(m.getDateDebut());
        dto.setDateFin(m.getDateFin());
        dto.setStatutMission(m.getStatutMission());
        dto.setIddemande(m.getIddemande());
        dto.setIdvehicule(m.getIdvehicule());
        dto.setChauffeurMatricule(m.getChauffeurMatricule());
        dto.setMotifAnnulation(m.getMotifAnnulation());

        if (m.getIdvehicule() != null) {
            vehiculeRepository.findById(m.getIdvehicule()).ifPresent(v -> {
                dto.setImmatriculationVehicule(v.getImmatriculation());
            });
        }

        if (m.getChauffeurMatricule() != null) {
            utilisateurRepository.findById(m.getChauffeurMatricule()).ifPresent(u -> {
                dto.setChauffeurNom(u.getNom());
                dto.setChauffeurPrenom(u.getPrenom());
            });
        }

        return dto;
    }

    private Utilisateur getCurrentUtilisateur() {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        String email = authentication.getName();

        return utilisateurRepository.findByEmail(email)
                .orElseThrow(() -> new RuntimeException("Utilisateur connecté introuvable"));
    }

    private void libererVehiculeEtChauffeur(Mission mission) {
        if (mission.getIdvehicule() != null) {
            Vehicule vehicule = vehiculeRepository.findById(mission.getIdvehicule())
                    .orElseThrow(() -> new RuntimeException("Véhicule introuvable"));
            vehicule.setEtat("Disponible");
            vehiculeRepository.save(vehicule);
        }

        if (mission.getChauffeurMatricule() != null) {
            Utilisateur chauffeur = utilisateurRepository.findById(mission.getChauffeurMatricule())
                    .orElseThrow(() -> new RuntimeException("Chauffeur introuvable"));
            chauffeur.setDisponibilite(1);
            utilisateurRepository.save(chauffeur);
        }
    }
    //Email mission affectee
    private void sendMissionAssignedEmail(
            Mission mission,
            Utilisateur chauffeur,
            Vehicule vehicule,
            List<Demande> demandes
    ) {
        if (chauffeur.getEmail() == null || chauffeur.getEmail().isBlank()) {
            return;
        }

        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm");

        String nomComplet = "";
        if (chauffeur.getPrenom() != null) {
            nomComplet += chauffeur.getPrenom() + " ";
        }
        if (chauffeur.getNom() != null) {
            nomComplet += chauffeur.getNom();
        }

        StringBuilder body = new StringBuilder();
        body.append("Bonjour ").append(nomComplet.trim()).append(",\n\n");
        body.append("Une nouvelle mission vous a été affectée.\n\n");

        body.append("Détails de la mission :\n");
        body.append("- ID mission : ").append(mission.getIdmission()).append("\n");
        body.append("- Date début : ")
                .append(mission.getDateDebut() != null ? mission.getDateDebut().format(formatter) : "Non définie")
                .append("\n");
        body.append("- Véhicule : ")
                .append(vehicule.getImmatriculation() != null ? vehicule.getImmatriculation() : "Non défini")
                .append("\n");
        body.append("- Nombre de demandes : ").append(demandes.size()).append("\n\n");

        body.append("Demandes associées :\n");

        int i = 1;
        for (Demande d : demandes) {
            String description = d.getDescription() != null ? d.getDescription() : "Aucune description";
            if (description.length() > 120) {
                description = description.substring(0, 120) + "...";
            }

            body.append(i).append(". ");
            body.append("Type : ")
                    .append(d.getTypeDemande() != null ? d.getTypeDemande() : "Non défini");
            body.append(" | Priorité : ")
                    .append(d.getPriorite() != null ? d.getPriorite() : "Non définie");
            body.append("\n");

            body.append("   Description : ").append(description).append("\n\n");

            i++;
        }

        body.append("Veuillez consulter votre espace chauffeur pour plus de détails.\n\n");
        body.append("Cordialement,\n");
        body.append("Application Parc Automobile");

        emailService.sendMail(
                chauffeur.getEmail(),
                "Nouvelle mission affectée",
                body.toString()
        );
    }
    //Email mission annulee
    private void sendMissionCancelledEmail(Mission mission) {
        if (mission.getChauffeurMatricule() == null) {
            return;
        }

        Utilisateur chauffeur = utilisateurRepository.findById(mission.getChauffeurMatricule())
                .orElseThrow(() -> new RuntimeException("Chauffeur introuvable"));

        if (chauffeur.getEmail() == null || chauffeur.getEmail().isBlank()) {
            return;
        }

        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm");

        String nomComplet = "";
        if (chauffeur.getPrenom() != null) {
            nomComplet += chauffeur.getPrenom() + " ";
        }
        if (chauffeur.getNom() != null) {
            nomComplet += chauffeur.getNom();
        }

        String immatriculation = "Non défini";
        if (mission.getIdvehicule() != null) {
            Vehicule vehicule = vehiculeRepository.findById(mission.getIdvehicule()).orElse(null);
            if (vehicule != null && vehicule.getImmatriculation() != null) {
                immatriculation = vehicule.getImmatriculation();
            }
        }

        StringBuilder body = new StringBuilder();
        body.append("Bonjour ").append(nomComplet.trim()).append(",\n\n");
        body.append("La mission qui vous a été affectée a été annulée.\n\n");
        body.append("Détails de la mission :\n");
        body.append("- ID mission : ").append(mission.getIdmission()).append("\n");
        body.append("- Date début : ")
                .append(mission.getDateDebut() != null ? mission.getDateDebut().format(formatter) : "Non définie")
                .append("\n");
        body.append("- Véhicule : ").append(immatriculation).append("\n");
        body.append("- Motif d'annulation : ")
                .append(mission.getMotifAnnulation() != null ? mission.getMotifAnnulation() : "Non précisé")
                .append("\n\n");
        body.append("Veuillez consulter votre espace chauffeur pour plus de détails.\n\n");
        body.append("Cordialement,\n");
        body.append("Application Parc Automobile");

        emailService.sendMail(
                chauffeur.getEmail(),
                "Mission annulée",
                body.toString()
        );
    }
 
}