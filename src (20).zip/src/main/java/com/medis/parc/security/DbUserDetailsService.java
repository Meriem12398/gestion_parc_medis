package com.medis.parc.security;

import java.util.List;

import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.*;
import org.springframework.stereotype.Service;

import com.medis.parc.entity.Utilisateur;
import com.medis.parc.repository.UtilisateurRepository;

@Service
public class DbUserDetailsService implements UserDetailsService {

    private final UtilisateurRepository repo;

    public DbUserDetailsService(UtilisateurRepository repo) {
        this.repo = repo;
    }

    @Override
    public UserDetails loadUserByUsername(String email) throws UsernameNotFoundException {
        Utilisateur u = repo.findByEmail(email)
                .orElseThrow(() -> new UsernameNotFoundException("User not found"));

        // IMPORTANT: لازم ROLE_ prefix
        String role = "ROLE_" + u.getRole();

        return new org.springframework.security.core.userdetails.User(
                u.getEmail(),
                u.getMotdepasse(),
                List.of(new SimpleGrantedAuthority(role))
        );
    }
}