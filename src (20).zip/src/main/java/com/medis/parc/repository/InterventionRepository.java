package com.medis.parc.repository;

import com.medis.parc.entity.Intervention;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface InterventionRepository extends JpaRepository<Intervention, Integer> {

    List<Intervention> findAllByOrderByIdinterventionDesc();

    List<Intervention> findByIdincidentOrderByIdinterventionDesc(Integer idincident);

    boolean existsByIdincident(Integer idincident);

    Optional<Intervention> findFirstByIdincidentOrderByIdinterventionDesc(Integer idincident);
}