package com.medis.parc.repository;

import com.medis.parc.entity.MissionDemande;
import com.medis.parc.entity.MissionDemandeId;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface MissionDemandeRepository extends JpaRepository<MissionDemande, MissionDemandeId> {

    List<MissionDemande> findByIdmission(Integer idmission);
}