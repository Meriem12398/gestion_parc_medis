package com.medis.parc.repository;

import com.medis.parc.entity.Vidange;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface VidangeRepository extends JpaRepository<Vidange, Integer> {

    List<Vidange> findByStatut(String statut);

    List<Vidange> findByVehicule_Idvehicule(Integer vehiculeId);
}