package com.medis.parc.repository;

import com.medis.parc.entity.Demande;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface DemandeRepository extends JpaRepository<Demande, Integer> {

    @Query("SELECT d FROM Demande d LEFT JOIN FETCH d.createur")
    List<Demande> findAllWithCreateur();

    @Query("""
        SELECT d FROM Demande d
        LEFT JOIN FETCH d.createur
        WHERE (:statut IS NULL OR :statut = '' OR LOWER(:statut) = 'tous' OR d.statut = :statut)
          AND (:priorite IS NULL OR :priorite = '' OR LOWER(:priorite) LIKE 'toutes%' OR d.priorite = :priorite)
    """)
    List<Demande> findAllWithCreateurFiltered(
            @Param("statut") String statut,
            @Param("priorite") String priorite
    );

    @Query("""
        SELECT d FROM Demande d
        LEFT JOIN FETCH d.createur
        WHERE d.matricule = :matricule
        ORDER BY d.iddemande DESC
    """)
    List<Demande> findByMatriculeWithCreateur(@Param("matricule") Integer matricule);

    List<Demande> findByStatutAndPriorite(String statut, String priorite);
    List<Demande> findByStatut(String statut);
    List<Demande> findByPriorite(String priorite);
}