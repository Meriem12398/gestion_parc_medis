package com.medis.parc.repository;

import com.medis.parc.entity.Incident;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface IncidentRepository extends JpaRepository<Incident, Integer> {
    List<Incident> findAllByOrderByIdincidentDesc();
}