package com.medis.parc;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MedisParcAutoApplication {
  public static void main(String[] args) {
    SpringApplication.run(MedisParcAutoApplication.class, args);
  }
}