package com.medis.parc.entity;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "Demande")
public class Demande {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "iddemande")
    private Integer iddemande;

    @Column(name = "type_demande", nullable = false)
    private String typeDemande;

    @Column(name = "date_creation", nullable = false)
    private LocalDateTime dateCreation;

    @Column(name = "date_souhaite")
    private LocalDateTime dateSouhaite;

    @Column(name = "statut", nullable = false)
    private String statut;

    @Column(name = "priorite")
    private String priorite;

    @Column(name = "description")
    private String description;

    @Column(name = "matricule")
    private Integer matricule;

    @Column(name = "motif_refus")
    private String motifRefus;
    
    @Column(name = "score_priorite")
    private Double scorePriorite;

    @Column(name = "priorite_ia")
    private String prioriteIa;
    
    public Double getScorePriorite() {
		return scorePriorite;
	}

	public void setScorePriorite(Double scorePriorite) {
		this.scorePriorite = scorePriorite;
	}

	public String getPrioriteIa() {
		return prioriteIa;
	}

	public void setPrioriteIa(String prioriteIa) {
		this.prioriteIa = prioriteIa;
	}

	@ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "matricule", referencedColumnName = "matricule", insertable = false, updatable = false)
    private Utilisateur createur;

    public Integer getIddemande() {
        return iddemande;
    }

    public void setIddemande(Integer iddemande) {
        this.iddemande = iddemande;
    }

    public String getTypeDemande() {
        return typeDemande;
    }

    public void setTypeDemande(String typeDemande) {
        this.typeDemande = typeDemande;
    }

    public LocalDateTime getDateCreation() {
        return dateCreation;
    }

    public void setDateCreation(LocalDateTime dateCreation) {
        this.dateCreation = dateCreation;
    }

    public LocalDateTime getDateSouhaite() {
        return dateSouhaite;
    }

    public void setDateSouhaite(LocalDateTime dateSouhaite) {
        this.dateSouhaite = dateSouhaite;
    }

    public String getStatut() {
        return statut;
    }

    public void setStatut(String statut) {
        this.statut = statut;
    }

    public String getPriorite() {
        return priorite;
    }

    public void setPriorite(String priorite) {
        this.priorite = priorite;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Integer getMatricule() {
        return matricule;
    }

    public void setMatricule(Integer matricule) {
        this.matricule = matricule;
    }

    public String getMotifRefus() {
        return motifRefus;
    }

    public void setMotifRefus(String motifRefus) {
        this.motifRefus = motifRefus;
    }

    public Utilisateur getCreateur() {
        return createur;
    }

    public void setCreateur(Utilisateur createur) {
        this.createur = createur;
    }
}