package com.medis.parc.entity;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "Incident", schema = "dbo")
public class Incident {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer idincident;

    @Column(name = "date_incident")
    private LocalDateTime dateIncident;

    @Column(name = "type_incident")
    private String typeIncident;

    @Column(name = "description")
    private String description;

    @Column(name = "idmission")
    private Integer idmission;

    @Column(name = "latitude")
    private Double latitude;

    @Column(name = "longitude")
    private Double longitude;

    @Column(name = "adresse")
    private String adresse;

    public Integer getIdincident() {
        return idincident;
    }

    public void setIdincident(Integer idincident) {
        this.idincident = idincident;
    }

    public LocalDateTime getDateIncident() {
        return dateIncident;
    }

    public void setDateIncident(LocalDateTime dateIncident) {
        this.dateIncident = dateIncident;
    }

    public String getTypeIncident() {
        return typeIncident;
    }

    public void setTypeIncident(String typeIncident) {
        this.typeIncident = typeIncident;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Integer getIdmission() {
        return idmission;
    }

    public void setIdmission(Integer idmission) {
        this.idmission = idmission;
    }

    public Double getLatitude() {
        return latitude;
    }

    public void setLatitude(Double latitude) {
        this.latitude = latitude;
    }

    public Double getLongitude() {
        return longitude;
    }

    public void setLongitude(Double longitude) {
        this.longitude = longitude;
    }

    public String getAdresse() {
        return adresse;
    }

    public void setAdresse(String adresse) {
        this.adresse = adresse;
    }
}