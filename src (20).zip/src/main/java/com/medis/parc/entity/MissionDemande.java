package com.medis.parc.entity;

import jakarta.persistence.*;

@Entity
@Table(name = "mission_demande", schema = "dbo")
@IdClass(MissionDemandeId.class)
public class MissionDemande {

    @Id
    @Column(name = "idmission")
    private Integer idmission;

    @Id
    @Column(name = "iddemande")
    private Integer iddemande;

    public MissionDemande() {}

    public MissionDemande(Integer idmission, Integer iddemande) {
        this.idmission = idmission;
        this.iddemande = iddemande;
    }

    public Integer getIdmission() { return idmission; }
    public void setIdmission(Integer idmission) { this.idmission = idmission; }

    public Integer getIddemande() { return iddemande; }
    public void setIddemande(Integer iddemande) { this.iddemande = iddemande; }
}