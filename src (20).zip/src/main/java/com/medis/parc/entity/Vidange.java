package com.medis.parc.entity;

import jakarta.persistence.*;

import java.math.BigDecimal;
import java.time.LocalDate;

@Entity
@Table(name = "Vidange", schema = "dbo")
public class Vidange {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer idvidange;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "vehicule_id", nullable = false)
    private Vehicule vehicule;

    @Column(name = "date_vidange")
    private LocalDate dateVidange;

    @Column(name = "kilometrage_vidange")
    private Integer kilometrageVidange;

    @Column(name = "type_huile", length = 100)
    private String typeHuile;

    @Column(name = "cout", precision = 10, scale = 2)
    private BigDecimal cout;

    @Column(name = "remarque", length = 500)
    private String remarque;

    @Column(name = "prochaine_date")
    private LocalDate prochaineDate;

    @Column(name = "prochain_kilometrage")
    private Integer prochainKilometrage;

    @Column(name = "statut", nullable = false, length = 50)
    private String statut;

    public Integer getIdvidange() {
        return idvidange;
    }

    public void setIdvidange(Integer idvidange) {
        this.idvidange = idvidange;
    }

    public Vehicule getVehicule() {
        return vehicule;
    }

    public void setVehicule(Vehicule vehicule) {
        this.vehicule = vehicule;
    }

    public LocalDate getDateVidange() {
        return dateVidange;
    }

    public void setDateVidange(LocalDate dateVidange) {
        this.dateVidange = dateVidange;
    }

    public Integer getKilometrageVidange() {
        return kilometrageVidange;
    }

    public void setKilometrageVidange(Integer kilometrageVidange) {
        this.kilometrageVidange = kilometrageVidange;
    }

    public String getTypeHuile() {
        return typeHuile;
    }

    public void setTypeHuile(String typeHuile) {
        this.typeHuile = typeHuile;
    }

    public BigDecimal getCout() {
        return cout;
    }

    public void setCout(BigDecimal cout) {
        this.cout = cout;
    }

    public String getRemarque() {
        return remarque;
    }

    public void setRemarque(String remarque) {
        this.remarque = remarque;
    }

    public LocalDate getProchaineDate() {
        return prochaineDate;
    }

    public void setProchaineDate(LocalDate prochaineDate) {
        this.prochaineDate = prochaineDate;
    }

    public Integer getProchainKilometrage() {
        return prochainKilometrage;
    }

    public void setProchainKilometrage(Integer prochainKilometrage) {
        this.prochainKilometrage = prochainKilometrage;
    }

    public String getStatut() {
        return statut;
    }

    public void setStatut(String statut) {
        this.statut = statut;
    }
}