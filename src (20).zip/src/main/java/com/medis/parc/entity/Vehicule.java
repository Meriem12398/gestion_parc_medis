package com.medis.parc.entity;

import jakarta.persistence.*;

import java.time.LocalDate;

@Entity
@Table(name = "Vehicule", schema = "dbo")
public class Vehicule {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer idvehicule;

    @Column(nullable = false, unique = true, length = 20)
    private String immatriculation;

    @Column(nullable = false, length = 100)
    private String marque;

    @Column(nullable = false, length = 100)
    private String modele;

    private Integer kilometrage;

    @Column(nullable = false, length = 50)
    private String etat;

    @Column(name = "type_carburant", length = 50)
    private String typeCarburant;

    @Column(name = "date_achat")
    private LocalDate dateAchat;

    // Getters & Setters

    public Integer getIdvehicule() { return idvehicule; }
    public void setIdvehicule(Integer idvehicule) { this.idvehicule = idvehicule; }

    public String getImmatriculation() { return immatriculation; }
    public void setImmatriculation(String immatriculation) { this.immatriculation = immatriculation; }

    public String getMarque() { return marque; }
    public void setMarque(String marque) { this.marque = marque; }

    public String getModele() { return modele; }
    public void setModele(String modele) { this.modele = modele; }

    public Integer getKilometrage() { return kilometrage; }
    public void setKilometrage(Integer kilometrage) { this.kilometrage = kilometrage; }

    public String getEtat() { return etat; }
    public void setEtat(String etat) { this.etat = etat; }

    public String getTypeCarburant() { return typeCarburant; }
    public void setTypeCarburant(String typeCarburant) { this.typeCarburant = typeCarburant; }

    public LocalDate getDateAchat() { return dateAchat; }
    public void setDateAchat(LocalDate dateAchat) { this.dateAchat = dateAchat; }
}