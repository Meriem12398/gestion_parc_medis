package com.medis.parc.entity;

import java.io.Serializable;
import java.util.Objects;

public class MissionDemandeId implements Serializable {

    private Integer idmission;
    private Integer iddemande;

    public MissionDemandeId() {}

    public MissionDemandeId(Integer idmission, Integer iddemande) {
        this.idmission = idmission;
        this.iddemande = iddemande;
    }

    public Integer getIdmission() { return idmission; }
    public void setIdmission(Integer idmission) { this.idmission = idmission; }

    public Integer getIddemande() { return iddemande; }
    public void setIddemande(Integer iddemande) { this.iddemande = iddemande; }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof MissionDemandeId)) return false;
        MissionDemandeId that = (MissionDemandeId) o;
        return Objects.equals(idmission, that.idmission) &&
               Objects.equals(iddemande, that.iddemande);
    }

    @Override
    public int hashCode() {
        return Objects.hash(idmission, iddemande);
    }
}