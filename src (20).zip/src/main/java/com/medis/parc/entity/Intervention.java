package com.medis.parc.entity;

import jakarta.persistence.*;
import java.math.BigDecimal;
import java.time.LocalDateTime;

@Entity
@Table(name = "Intervention", schema = "dbo")
public class Intervention {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer idintervention;

    @Column(name = "date_intervention")
    private LocalDateTime dateIntervention;

    @Column(name = "type_intervention")
    private String typeIntervention;

    @Column(name = "description")
    private String description;

    @Column(name = "cout")
    private BigDecimal cout;

    @Column(name = "idincident")
    private Integer idincident;

    public Integer getIdintervention() {
        return idintervention;
    }

    public void setIdintervention(Integer idintervention) {
        this.idintervention = idintervention;
    }

    public LocalDateTime getDateIntervention() {
        return dateIntervention;
    }

    public void setDateIntervention(LocalDateTime dateIntervention) {
        this.dateIntervention = dateIntervention;
    }

    public String getTypeIntervention() {
        return typeIntervention;
    }

    public void setTypeIntervention(String typeIntervention) {
        this.typeIntervention = typeIntervention;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public BigDecimal getCout() {
        return cout;
    }

    public void setCout(BigDecimal cout) {
        this.cout = cout;
    }

    public Integer getIdincident() {
        return idincident;
    }

    public void setIdincident(Integer idincident) {
        this.idincident = idincident;
    }
}