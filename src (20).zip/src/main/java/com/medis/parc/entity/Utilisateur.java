package com.medis.parc.entity;

import jakarta.persistence.*;

@Entity
@Table(name = "utilisateur", schema = "dbo")
public class Utilisateur {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer matricule;

    @Column(nullable = false, length = 100)
    private String nom;

    @Column(nullable = false, length = 100)
    private String prenom;

    @Column(nullable = false, unique = true, length = 150)
    private String email;

    @Column(nullable = false)
    private String motdepasse;

    @Column(nullable = false, length = 30)
    private String role;
    
    @Column(length = 30)
    private String telephone;

    @Column(nullable = false, length = 100)
    private String departement;

    @Column(length = 10)
    private String type_permis;

    @Column(nullable = false)
    private Integer disponibilite = 1;;

    // getters/setters
    public Integer getMatricule() { return matricule; }
    public void setMatricule(Integer matricule) { this.matricule = matricule; }

    public String getTelephone() {
		return telephone;
	}
	public void setTelephone(String telephone) {
		this.telephone = telephone;
	}
	public String getDepartement() {
		return departement;
	}
	public void setDepartement(String departement) {
		this.departement = departement;
	}
	public String getType_permis() {
		return type_permis;
	}
	public void setType_permis(String type_permis) {
		this.type_permis = type_permis;
	}
	public Integer getDisponibilite() {
		return disponibilite;
	}
	public void setDisponibilite(Integer disponibilite) {
		this.disponibilite = disponibilite;
	}
	public String getNom() { return nom; }
    public void setNom(String nom) { this.nom = nom; }

    public String getPrenom() { return prenom; }
    public void setPrenom(String prenom) { this.prenom = prenom; }

    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }

    public String getMotdepasse() { return motdepasse; }
    public void setMotdepasse(String motdepasse) { this.motdepasse = motdepasse; }

    public String getRole() { return role; }
    public void setRole(String role) { this.role = role; }
}