package com.medis.parc;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MedisParcAutoApplicationTests {

	@Test
	void contextLoads() {
	}

}
