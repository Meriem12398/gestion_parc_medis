import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { UtilisateurDto, UtilisateurService } from '../../auth/services/utilisateur.service';
import * as XLSX from 'xlsx';
import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';

type DispoFilter = 'ALL' | 'DISPONIBLE' | 'INDISPONIBLE';
type RoleType = 'CHAUFFEUR' | 'DEMANDEUR';
type ViewFilter = 'ALL' | 'IT' | 'TRANSPORT' | 'RH';
type SortBy = 'RECENT' | 'ANCIEN' | 'NOM_AZ' | 'NOM_ZA';
type QuickFilter = 'NONE' | 'DISPONIBLE' | 'INDISPONIBLE' | 'NO_TEL' | 'NO_PERMIS';

@Component({
  selector: 'app-utilisateurs',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './utilisateurs.html',
  styleUrls: ['./utilisateurs.scss']
})
export class UtilisateursComponent implements OnInit {

  utilisateurs: UtilisateurDto[] = [];
  loading = true;
  errorMsg = '';
  successMsg = '';

  addErrorMsg = '';
  editErrorMsg = '';
  deleteErrorMsg = '';

  searchTerm = '';
  dispoFilter: DispoFilter = 'ALL';
  viewFilter: ViewFilter = 'ALL';
  sortBy: SortBy = 'RECENT';
  quickFilter: QuickFilter = 'NONE';

  page = 1;
  pageSize = 8;
  pageSizes = [5, 8, 10, 15, 20];

  sortColumnName: string = '';
  sortDirection: 'asc' | 'desc' = 'asc';

  editOpen = false;
  editing?: UtilisateurDto;
  editModel?: Partial<UtilisateurDto>;

  deleteOpen = false;
  deleting?: UtilisateurDto;

  addOpen = false;
  addModel = this.getEmptyAddModel();

  selectedUser?: UtilisateurDto;

  resetPasswordValue = '';
  resetPasswordError = '';
  resetPasswordSuccess = '';

  private getEmptyAddModel() {
    return {
      nom: '',
      prenom: '',
      motDePasse: '',
      email: '',
      telephone: '',
      departement: '',
      typePermis: '',
      disponibilite: 1 as number | null,
      role: 'CHAUFFEUR' as RoleType
    };
  }

  constructor(
    private utilisateurService: UtilisateurService,
    private route: ActivatedRoute
  ) {}

  ngOnInit(): void {
    this.loadChauffeurs();

    this.route.queryParams.subscribe(params => {
      if (params['action'] === 'add') this.openAdd();
    });
  }

  private showSuccess(msg: string): void {
    this.successMsg = msg;
    this.errorMsg = '';

    setTimeout(() => {
      this.successMsg = '';
    }, 3000);
  }

  private showError(msg: string): void {
    this.errorMsg = msg;
    this.successMsg = '';
  }

  loadChauffeurs(): void {
    this.loading = true;
    this.errorMsg = '';

    this.utilisateurService.getChauffeurs().subscribe({
      next: (data) => {
        this.utilisateurs = data || [];
        this.loading = false;
        this.goToPage(this.page);
      },
      error: (err: any) => {
        this.loading = false;
        this.showError(err?.error?.message || 'Erreur lors du chargement des chauffeurs');
      }
    });
  }

  get totalChauffeurs(): number {
    return (this.utilisateurs || []).length;
  }

  get totalDisponibles(): number {
    return (this.utilisateurs || []).filter(u => u.disponibilite === 1).length;
  }

  get totalIndisponibles(): number {
    return (this.utilisateurs || []).filter(u => u.disponibilite !== 1).length;
  }

  get totalSansTelephone(): number {
    return (this.utilisateurs || []).filter(u => !(u.telephone || '').trim()).length;
  }

  get totalSansPermis(): number {
    return (this.utilisateurs || []).filter(u => !(u.typePermis || '').trim()).length;
  }

  get totalDepartments(): number {
    const set = new Set(
      (this.utilisateurs || [])
        .map(u => (u.departement || '').trim().toLowerCase())
        .filter(Boolean)
    );
    return set.size;
  }

  get topDepartment(): string {
    const map = new Map<string, number>();

    (this.utilisateurs || []).forEach(u => {
      const dep = (u.departement || '').trim();
      if (!dep) return;
      const key = dep;
      map.set(key, (map.get(key) || 0) + 1);
    });

    let best = '';
    let bestCount = 0;

    map.forEach((count, dep) => {
      if (count > bestCount) {
        bestCount = count;
        best = dep;
      }
    });

    return best ? `${best} (${bestCount})` : '-';
  }

  exportExcel(): void {
    const data = this.filteredUtilisateurs.map(u => ({
      Nom: u.nom,
      Prenom: u.prenom,
      Email: u.email,
      Telephone: u.telephone,
      Departement: u.departement,
      Permis: u.typePermis,
      Disponibilite: u.disponibilite ? 'Disponible' : 'Indisponible'
    }));

    const ws: XLSX.WorkSheet = XLSX.utils.json_to_sheet(data);

    const wb: XLSX.WorkBook = {
      Sheets: { Chauffeurs: ws },
      SheetNames: ['Chauffeurs']
    };

    XLSX.writeFile(wb, 'chauffeurs.xlsx');
    this.showSuccess('Export Excel effectué avec succès.');
  }

  exportPDF(): void {
    const rows = this.filteredUtilisateurs.map(u => [
      u.nom || '',
      u.prenom || '',
      u.email || '-',
      u.telephone || '-',
      u.departement || '-',
      u.typePermis || '-',
      u.disponibilite === 1 ? 'Disponible' : 'Indisponible'
    ]);

    const doc = new jsPDF('landscape');

    doc.setFontSize(14);
    doc.text('Liste des chauffeurs', 14, 15);

    autoTable(doc, {
      startY: 22,
      head: [[
        'Nom',
        'Prenom',
        'Email',
        'Telephone',
        'Departement',
        'Type Permis',
        'Disponibilite'
      ]],
      body: rows,
      styles: {
        fontSize: 9
      },
      headStyles: {
        fillColor: [41, 128, 185]
      }
    });

    doc.save('chauffeurs.pdf');
    this.showSuccess('Export PDF effectué avec succès.');
  }

  setQuickFilter(q: QuickFilter | any): void {
    const key = (q ?? 'NONE') as QuickFilter;

    if (this.quickFilter === key) this.quickFilter = 'NONE';
    else this.quickFilter = key;

    this.page = 1;
  }

  onFiltersChange(): void {
    this.page = 1;
  }

  sortColumn(column: string): void {
    if (this.sortColumnName === column) {
      this.sortDirection = this.sortDirection === 'asc' ? 'desc' : 'asc';
    } else {
      this.sortColumnName = column;
      this.sortDirection = 'asc';
    }

    this.page = 1;
  }

  private normalize(s: any): string {
    return (s ?? '').toString().trim().toLowerCase();
  }

  private matchViewFilter(u: UtilisateurDto): boolean {
    if (this.viewFilter === 'ALL') return true;

    const dep = this.normalize(u.departement);

    if (this.viewFilter === 'IT') return dep.includes('it');
    if (this.viewFilter === 'TRANSPORT') return dep.includes('transport');
    if (this.viewFilter === 'RH') return dep.includes('rh') || dep.includes('ressource') || dep.includes('human');

    return true;
  }

  private applyQuickFilter(u: UtilisateurDto): boolean {
    switch (this.quickFilter) {
      case 'DISPONIBLE':
        return u.disponibilite === 1;
      case 'INDISPONIBLE':
        return u.disponibilite !== 1;
      case 'NO_TEL':
        return !(u.telephone || '').trim();
      case 'NO_PERMIS':
        return !(u.typePermis || '').trim();
      case 'NONE':
      default:
        return true;
    }
  }

  private sortList(list: UtilisateurDto[]): UtilisateurDto[] {
    const arr = [...(list || [])];
    const s = (v: any) => (v ?? '').toString().trim().toLowerCase();
    const id = (u: UtilisateurDto) => Number(u.matricule ?? 0) || 0;

    if (this.sortColumnName) {
      arr.sort((a: any, b: any) => {
        let v1 = a[this.sortColumnName];
        let v2 = b[this.sortColumnName];

        if (this.sortColumnName === 'disponibilite') {
          v1 = Number(v1 ?? 0);
          v2 = Number(v2 ?? 0);
        } else {
          v1 = (v1 ?? '').toString().trim().toLowerCase();
          v2 = (v2 ?? '').toString().trim().toLowerCase();
        }

        if (v1 < v2) return this.sortDirection === 'asc' ? -1 : 1;
        if (v1 > v2) return this.sortDirection === 'asc' ? 1 : -1;
        return 0;
      });

      return arr;
    }

    arr.sort((a, b) => {
      switch (this.sortBy) {
        case 'ANCIEN':
          return id(a) - id(b);
        case 'NOM_AZ':
          return s(a.nom).localeCompare(s(b.nom));
        case 'NOM_ZA':
          return s(b.nom).localeCompare(s(a.nom));
        case 'RECENT':
        default:
          return id(b) - id(a);
      }
    });

    return arr;
  }

  get filteredUtilisateurs(): UtilisateurDto[] {
    const q = this.normalize(this.searchTerm);

    const base = (this.utilisateurs || []).filter(u => {
      const fullText = this.normalize(
        `${u.nom ?? ''} ${u.prenom ?? ''} ${u.email ?? ''} ${u.telephone ?? ''} ${u.departement ?? ''} ${u.typePermis ?? ''}`
      );

      const matchSearch = !q || fullText.includes(q);

      const isDisponible = u.disponibilite === 1;
      const matchDispo =
        this.dispoFilter === 'ALL' ||
        (this.dispoFilter === 'DISPONIBLE' && isDisponible) ||
        (this.dispoFilter === 'INDISPONIBLE' && !isDisponible);

      const matchView = this.matchViewFilter(u);
      const matchQuick = this.applyQuickFilter(u);

      return matchSearch && matchDispo && matchView && matchQuick;
    });

    return this.sortList(base);
  }

  get totalItems(): number {
    return this.filteredUtilisateurs.length;
  }

  get totalPages(): number {
    return Math.max(1, Math.ceil(this.totalItems / this.pageSize));
  }

  get pagedUtilisateurs(): UtilisateurDto[] {
    const start = (this.page - 1) * this.pageSize;
    return this.filteredUtilisateurs.slice(start, start + this.pageSize);
  }

  goToPage(p: number): void {
    if (p < 1) p = 1;
    if (p > this.totalPages) p = this.totalPages;
    this.page = p;
  }

  nextPage(): void {
    this.goToPage(this.page + 1);
  }

  prevPage(): void {
    this.goToPage(this.page - 1);
  }

  onPageSizeChange(): void {
    this.page = 1;
  }

  openAdd(): void {
    this.errorMsg = '';
    this.addErrorMsg = '';
    this.addModel = this.getEmptyAddModel();
    this.addOpen = true;
  }

  closeAdd(): void {
    this.addOpen = false;
    this.addErrorMsg = '';
  }

  onRoleChange(): void {
    if (this.addModel.role === 'DEMANDEUR') {
      this.addModel.typePermis = '';
      this.addModel.disponibilite = null;
    } else {
      if (this.addModel.disponibilite === null) this.addModel.disponibilite = 1;
    }
  }

  onTelInput(e: Event): void {
    const input = e.target as HTMLInputElement;
    let v = (input.value || '').replace(/\D/g, '');
    if (v.length > 8) v = v.slice(0, 8);
    input.value = v;
    this.addModel.telephone = v;
  }

  canSubmitAdd(): boolean {
    const nomOk = /^[A-Za-zÀ-ÿ' -]{2,30}$/.test((this.addModel.nom || '').trim());
    const prenomOk = /^[A-Za-zÀ-ÿ' -]{2,30}$/.test((this.addModel.prenom || '').trim());
    const emailOk = !!(this.addModel.email || '').trim();
    const pwdOk = ((this.addModel.motDePasse || '').trim().length >= 6);

    const tel = (this.addModel.telephone || '').trim();
    const telOk = !tel || /^[0-9]{8}$/.test(tel);

    if (!nomOk || !prenomOk || !emailOk || !pwdOk || !telOk) return false;

    if (this.addModel.role === 'CHAUFFEUR') {
      if (!(this.addModel.typePermis || '').trim()) return false;
    }

    return true;
  }

  private validateAdd(): string | null {
    if (!this.addModel.nom?.trim()) return 'Nom obligatoire';
    if (!this.addModel.prenom?.trim()) return 'Prénom obligatoire';
    if (!this.addModel.email?.trim()) return 'Email obligatoire';
    if (!this.addModel.motDePasse?.trim()) return 'Mot de passe obligatoire';

    if (this.addModel.role === 'CHAUFFEUR') {
      if (!this.addModel.typePermis?.trim()) return 'Type permis obligatoire pour chauffeur';
      if (this.addModel.disponibilite === null || this.addModel.disponibilite === undefined) {
        return 'Disponibilité obligatoire pour chauffeur';
      }
    }
    return null;
  }

  confirmAdd(): void {
    this.addErrorMsg = '';

    const errMsg = this.validateAdd();
    if (errMsg) {
      this.addErrorMsg = errMsg;
      return;
    }

    const payload: any = {
      nom: this.addModel.nom.trim(),
      prenom: this.addModel.prenom.trim(),
      email: this.addModel.email.trim(),
      telephone: this.addModel.telephone || '',
      departement: this.addModel.departement || '',
      role: this.addModel.role,
      motDePasse: this.addModel.motDePasse
    };

    if (this.addModel.role === 'CHAUFFEUR') {
      payload.typePermis = this.addModel.typePermis || '';
      payload.disponibilite = this.addModel.disponibilite ?? 1;
    }

    this.utilisateurService.createChauffeur(payload).subscribe({
      next: () => {
        this.showSuccess('Utilisateur ajouté avec succès ✅');
        this.closeAdd();
        this.utilisateurService.refresh();
        this.loadChauffeurs();
      },
      error: (err) => {
        const msg = err?.error?.message || 'Erreur ajout utilisateur';
        this.addErrorMsg = msg;
      }
    });
  }

  onEdit(u: UtilisateurDto): void {
    this.editErrorMsg = '';
    this.editing = u;
    this.editModel = {
      nom: u.nom,
      prenom: u.prenom,
      email: u.email,
      telephone: u.telephone,
      departement: u.departement,
      typePermis: u.typePermis,
      disponibilite: u.disponibilite
    };
    this.editOpen = true;
  }

  closeEdit(): void {
    this.editOpen = false;
    this.editing = undefined;
    this.editModel = undefined;
    this.editErrorMsg = '';
  }

  saveEdit(): void {
    if (!this.editing || !this.editModel) return;

    this.editErrorMsg = '';

    const payload: any = {
      nom: (this.editModel.nom ?? '').trim(),
      prenom: (this.editModel.prenom ?? '').trim(),
      email: (this.editModel.email ?? '').trim(),
      telephone: (this.editModel.telephone ?? '').trim(),
      departement: (this.editModel.departement ?? '').trim(),
      typePermis: (this.editModel.typePermis ?? '').trim(),
      disponibilite: this.editModel.disponibilite,
      role: 'CHAUFFEUR'
    };

    Object.keys(payload).forEach(k => {
      const v = payload[k];
      if ((v === null || v === undefined || v === '') && k !== 'disponibilite') delete payload[k];
    });

    this.utilisateurService.update(this.editing.matricule, payload).subscribe({
      next: () => {
        this.showSuccess('Utilisateur modifié avec succès ✅');
        this.closeEdit();
        this.utilisateurService.refresh();
        this.loadChauffeurs();
      },
      error: (err: any) => {
        const msg = err?.error?.message || 'Erreur modification';
        this.editErrorMsg = msg;
      }
    });
  }

  onAskDelete(u: UtilisateurDto): void {
    this.deleteErrorMsg = '';
    this.deleting = u;
    this.deleteOpen = true;
  }

  closeDelete(): void {
    this.deleteOpen = false;
    this.deleting = undefined;
    this.deleteErrorMsg = '';
  }

  confirmDelete(): void {
    if (!this.deleting) return;

    this.deleteErrorMsg = '';

    this.utilisateurService.delete(this.deleting.matricule).subscribe({
      next: () => {
        this.showSuccess('Utilisateur supprimé ✅');
        this.closeDelete();
        this.utilisateurService.refresh();
        this.loadChauffeurs();
      },
      error: (err: any) => {
        const msg = err?.error?.message || 'Erreur suppression';
        this.deleteErrorMsg = msg;
      }
    });
  }

  openFiche(u: UtilisateurDto): void {
    this.selectedUser = u;
    this.resetPasswordValue = '';
    this.resetPasswordError = '';
    this.resetPasswordSuccess = '';
  }

  closeFiche(): void {
    this.selectedUser = undefined;
    this.resetPasswordValue = '';
    this.resetPasswordError = '';
    this.resetPasswordSuccess = '';
  }

  confirmResetPassword(): void {
    if (!this.selectedUser) return;

    const pwd = (this.resetPasswordValue || '').trim();

    this.resetPasswordError = '';
    this.resetPasswordSuccess = '';

    if (!pwd) {
      this.resetPasswordError = 'Nouveau mot de passe obligatoire';
      return;
    }

    if (pwd.length < 6) {
      this.resetPasswordError = 'Le mot de passe doit contenir au moins 6 caractères';
      return;
    }

    this.utilisateurService.resetPassword(this.selectedUser.matricule, pwd).subscribe({
      next: () => {
        this.resetPasswordSuccess = 'Mot de passe réinitialisé avec succès ✅';
        this.resetPasswordValue = '';
      },
      error: (err: any) => {
        this.resetPasswordError = err?.error || 'Erreur lors de la réinitialisation du mot de passe';
      }
    });
  }

  getInitials(u: Partial<UtilisateurDto>): string {
    const nom = (u.nom || '').trim();
    const prenom = (u.prenom || '').trim();

    const a = prenom ? prenom.charAt(0) : '';
    const b = nom ? nom.charAt(0) : '';

    return (a + b).toUpperCase() || 'U';
  }
}