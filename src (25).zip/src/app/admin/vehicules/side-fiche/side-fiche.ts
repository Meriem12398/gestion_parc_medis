import { CommonModule } from '@angular/common';
import { Component, EventEmitter, Input, Output } from '@angular/core';

export type FicheTone = 'default' | 'success' | 'danger' | 'warn' | 'info';
export type TrendDirection = 'up' | 'down' | 'neutral';

export type FicheBlock =
  | {
      type: 'info-grid';
      title?: string;
      items: { label: string; value: any }[];
    }
  | {
      type: 'stats-grid';
      title?: string;
      items: {
        label: string;
        value: string | number;
        sub?: string;
        icon?: string;
        trend?: string;
        trendDirection?: TrendDirection;
        tone?: FicheTone;
      }[];
    }
  | {
      type: 'status-grid';
      title?: string;
      items: {
        label: string;
        value: string;
        icon?: string;
        tone?: FicheTone;
      }[];
    }
  | {
      type: 'progress-grid';
      title?: string;
      items: {
        label: string;
        value: number;
        suffix?: string;
        tone?: FicheTone;
      }[];
    };

@Component({
  selector: 'app-side-fiche',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './side-fiche.html',
  styleUrls: ['./side-fiche.scss']
})
export class SideFicheComponent {
  @Input() open = false;
  @Input() title = 'Fiche technique';
  @Input() subtitle = '';
  @Input() avatarText = 'FT';
  @Input() blocks: FicheBlock[] = [];

  @Output() closed = new EventEmitter<void>();

  close(): void {
    this.closed.emit();
  }

  asText(value: any): string {
    if (value === null || value === undefined || value === '') return '-';
    return String(value);
  }

  clampPercent(value: number): number {
    const n = Number(value ?? 0);
    if (isNaN(n)) return 0;
    return Math.max(0, Math.min(100, n));
  }

  trendIcon(dir?: TrendDirection): string {
    if (dir === 'up') return '↑';
    if (dir === 'down') return '↓';
    return '•';
  }

  toneClass(tone?: FicheTone): string {
    return tone ? `tone-${tone}` : 'tone-default';
  }
}