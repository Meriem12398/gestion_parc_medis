import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import * as XLSX from 'xlsx';
import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';

import { VehiculeDto, VehiculeService } from '../../auth/services/vehicule.service';
import { SideFicheComponent, FicheBlock } from './side-fiche/side-fiche';

type EtatFilter = 'ALL' | 'Disponible' | 'En panne' | 'En maintenance' | 'Neuf';
type SortBy = 'RECENT' | 'ANCIEN' | 'MARQUE_AZ' | 'MARQUE_ZA' | 'KM_ASC' | 'KM_DESC';
type QuickFilter = 'NONE' | 'DISPONIBLE' | 'PANNE' | 'MAINTENANCE' | 'NEUF' | 'KM_100K';

@Component({
  selector: 'app-vehicules',
  standalone: true,
  imports: [CommonModule, FormsModule, SideFicheComponent],
  templateUrl: './vehicules.html',
  styleUrls: ['./vehicules.scss']
})
export class VehiculesComponent implements OnInit {

  loading = false;
  errorMsg = '';
  successMsg = '';

  addErrorMsg = '';
  editErrorMsg = '';
  deleteErrorMsg = '';

  vehicules: VehiculeDto[] = [];

  searchTerm = '';
  etatFilter: EtatFilter = 'ALL';
  sortBy: SortBy = 'RECENT';
  quickFilter: QuickFilter = 'NONE';

page = 1;
pageSize = 8;
pageSizes = [5, 8, 10, 15, 20];

  sortColumnName: string = '';
  sortDirection: 'asc' | 'desc' = 'asc';

  addOpen = false;
  editOpen = false;
  deleteOpen = false;

  addModel: Partial<VehiculeDto> = this.getEmptyAddModel();
  editModel?: VehiculeDto;
  deleting?: VehiculeDto;

  selectedVehicule?: VehiculeDto;

  constructor(
    private vehiculeService: VehiculeService,
    private route: ActivatedRoute,
    private router: Router
  ) {}

  ngOnInit(): void {
    this.load();

    this.route.queryParams.subscribe(params => {
      if (params['action'] === 'add') this.openAdd();
    });

    this.vehiculeService.onRefresh().subscribe(() => this.load());
  }

sortColumn(column: string): void {
  if (this.sortColumnName === column) {
    this.sortDirection = this.sortDirection === 'asc' ? 'desc' : 'asc';
  } else {
    this.sortColumnName = column;
    this.sortDirection = 'asc';
  }

  this.page = 1;
  this.goToPage(this.page);
}

  private showSuccess(msg: string): void {
    this.successMsg = msg;
    this.errorMsg = '';

    setTimeout(() => {
      this.successMsg = '';
    }, 3000);
  }

  private showError(msg: string): void {
    this.errorMsg = msg;
    this.successMsg = '';
  }

  private getEmptyAddModel(): Partial<VehiculeDto> {
    return {
      immatriculation: '',
      marque: '',
      modele: '',
      kilometrage: 0,
      etat: 'Disponible',
      typeCarburant: '',
      dateAchat: ''
    };
  }

  load(): void {
    this.loading = true;
    this.errorMsg = '';

    this.vehiculeService.getAll().subscribe({
next: (data) => {
  this.vehicules = data ?? [];
  this.loading = false;
  this.goToPage(1);

  if (this.selectedVehicule?.idvehicule) {
    const refreshed = this.vehicules.find(v => v.idvehicule === this.selectedVehicule?.idvehicule);
    this.selectedVehicule = refreshed;
  }
},
      error: () => {
        this.loading = false;
        this.showError('Erreur de chargement des véhicules.');
      }
    });
  }

  get totalVehicules(): number {
    return (this.vehicules || []).length;
  }

  get totalDisponibles(): number {
    return (this.vehicules || []).filter(v => v.etat === 'Disponible').length;
  }

  get totalEnPanne(): number {
    return (this.vehicules || []).filter(v => v.etat === 'En panne').length;
  }

  get totalEnMaintenance(): number {
    return (this.vehicules || []).filter(v => v.etat === 'En maintenance').length;
  }

  get totalNeufs(): number {
    return (this.vehicules || []).filter(v => v.etat === 'Neuf').length;
  }

  get totalHighKm(): number {
    return (this.vehicules || []).filter(v => Number(v.kilometrage || 0) >= 100000).length;
  }

setQuickFilter(q: QuickFilter): void {
  this.quickFilter = (this.quickFilter === q) ? 'NONE' : q;
  this.page = 1;
  this.goToPage(this.page);
}

  onFiltersChanged(): void {
  this.page = 1;
  this.goToPage(this.page);
}

  private normalize(s: any): string {
    return (s ?? '').toString().trim().toLowerCase();
  }

  private applyQuickFilter(v: VehiculeDto): boolean {
    switch (this.quickFilter) {
      case 'DISPONIBLE': return v.etat === 'Disponible';
      case 'PANNE': return v.etat === 'En panne';
      case 'MAINTENANCE': return v.etat === 'En maintenance';
      case 'NEUF': return v.etat === 'Neuf';
      case 'KM_100K': return Number(v.kilometrage || 0) >= 100000;
      case 'NONE':
      default: return true;
    }
  }

  private getSortableValue(v: VehiculeDto, column: string): any {
    switch (column) {
      case 'immatriculation':
        return this.normalize(v.immatriculation);
      case 'marque':
        return this.normalize(v.marque);
      case 'modele':
        return this.normalize(v.modele);
      case 'kilometrage':
        return Number(v.kilometrage ?? 0);
      case 'etat':
        return this.normalize(v.etat);
      case 'typeCarburant':
        return this.normalize(v.typeCarburant);
      case 'dateAchat':
        return v.dateAchat ? new Date(v.dateAchat).getTime() : 0;
      default:
        return this.normalize((v as any)[column]);
    }
  }

  private sortList(list: VehiculeDto[]): VehiculeDto[] {
    const arr = [...(list || [])];
    const s = (x: any) => (x ?? '').toString().trim().toLowerCase();
    const id = (v: VehiculeDto) => Number(v.idvehicule ?? 0) || 0;
    const km = (v: VehiculeDto) => Number(v.kilometrage ?? 0) || 0;

    if (this.sortColumnName) {
      arr.sort((a, b) => {
        const v1 = this.getSortableValue(a, this.sortColumnName);
        const v2 = this.getSortableValue(b, this.sortColumnName);

        if (v1 < v2) return this.sortDirection === 'asc' ? -1 : 1;
        if (v1 > v2) return this.sortDirection === 'asc' ? 1 : -1;
        return 0;
      });

      return arr;
    }

    arr.sort((a, b) => {
      switch (this.sortBy) {
        case 'ANCIEN': return id(a) - id(b);
        case 'MARQUE_AZ': return s(a.marque).localeCompare(s(b.marque));
        case 'MARQUE_ZA': return s(b.marque).localeCompare(s(a.marque));
        case 'KM_ASC': return km(a) - km(b);
        case 'KM_DESC': return km(b) - km(a);
        case 'RECENT':
        default: return id(b) - id(a);
      }
    });

    return arr;
  }

  get filteredVehicules(): VehiculeDto[] {
    const q = this.normalize(this.searchTerm);

    const base = (this.vehicules || []).filter(v => {
      const fullText = this.normalize(
        `${v.immatriculation ?? ''} ${v.marque ?? ''} ${v.modele ?? ''} ${v.kilometrage ?? ''} ${v.etat ?? ''} ${v.typeCarburant ?? ''} ${v.dateAchat ?? ''}`
      );

      const matchSearch = !q || fullText.includes(q);
      const matchEtat = this.etatFilter === 'ALL' || v.etat === this.etatFilter;
      const matchQuick = this.applyQuickFilter(v);

      return matchSearch && matchEtat && matchQuick;
    });

    return this.sortList(base);
  }

  get totalItems(): number {
    return this.filteredVehicules.length;
  }

  get totalPages(): number {
    return Math.max(1, Math.ceil(this.totalItems / this.pageSize));
  }

  get pagedVehicules(): VehiculeDto[] {
    const start = (this.page - 1) * this.pageSize;
    return this.filteredVehicules.slice(start, start + this.pageSize);
  }

  goToPage(p: number): void {
    if (p < 1) p = 1;
    if (p > this.totalPages) p = this.totalPages;
    this.page = p;
  }

  nextPage(): void {
    this.goToPage(this.page + 1);
  }

  prevPage(): void {
    this.goToPage(this.page - 1);
  }



  onPageSizeChange(): void {
  this.page = 1;
  this.goToPage(this.page);
}

  cleanKilometrageInput(e: Event): void {
    const input = e.target as HTMLInputElement;
    input.value = (input.value || '').replace(/[^\d]/g, '');
    this.addModel.kilometrage = Number(input.value || 0);
  }

  cleanImmatInput(e: Event): void {
    const input = e.target as HTMLInputElement;
    input.value = (input.value || '').toUpperCase().replace(/[^A-Z0-9]/g, '');
    this.addModel.immatriculation = input.value;
  }

  canSubmitAdd(): boolean {
    const a = this.addModel;
    if (!a.immatriculation || a.immatriculation.trim().length < 3) return false;
    if (!a.marque || a.marque.trim().length < 2) return false;
    if (!a.modele || a.modele.trim().length < 1) return false;
    if (a.kilometrage === null || a.kilometrage === undefined) return false;
    if (Number(a.kilometrage) < 0) return false;
    if (!a.etat) return false;
    return true;
  }

  openAdd(): void {
    this.addErrorMsg = '';
    this.addOpen = true;
    this.addModel = this.getEmptyAddModel();
  }

  closeAdd(): void {
    this.addOpen = false;
    this.addErrorMsg = '';
    this.router.navigate([], { queryParams: { action: null }, queryParamsHandling: 'merge' });
  }

  confirmAdd(): void {
    this.addErrorMsg = '';

    if (!this.canSubmitAdd()) {
      this.addErrorMsg = 'Veuillez remplir correctement tous les champs.';
      return;
    }

    this.vehiculeService.create(this.addModel).subscribe({
      next: () => {
        this.closeAdd();
        this.vehiculeService.refresh();
        this.showSuccess('Véhicule ajouté avec succès ✅');
      },
      error: (err) => {
        const msg = err?.error?.message || 'Erreur ajout véhicule.';
        this.addErrorMsg = msg;
      }
    });
  }

  onEdit(v: VehiculeDto): void {
    this.editErrorMsg = '';
    this.editModel = { ...v };
    this.editOpen = true;
  }

  closeEdit(): void {
    this.editOpen = false;
    this.editModel = undefined;
    this.editErrorMsg = '';
  }

  saveEdit(): void {
    if (!this.editModel?.idvehicule) return;

    this.editErrorMsg = '';

    const id = this.editModel.idvehicule;
    const payload: Partial<VehiculeDto> = {
      immatriculation: this.editModel.immatriculation,
      marque: this.editModel.marque,
      modele: this.editModel.modele,
      kilometrage: this.editModel.kilometrage,
      etat: this.editModel.etat,
      typeCarburant: this.editModel.typeCarburant,
      dateAchat: this.editModel.dateAchat
    };

    this.vehiculeService.update(id, payload).subscribe({
      next: () => {
        this.closeEdit();
        this.vehiculeService.refresh();
        this.showSuccess('Véhicule modifié avec succès ✅');
      },
      error: (err) => {
        this.editErrorMsg = err?.error?.message || 'Erreur modification véhicule.';
      }
    });
  }

  onAskDelete(v: VehiculeDto): void {
    this.deleteErrorMsg = '';
    this.deleting = v;
    this.deleteOpen = true;
  }

  closeDelete(): void {
    this.deleteOpen = false;
    this.deleting = undefined;
    this.deleteErrorMsg = '';
  }

  confirmDelete(): void {
    if (!this.deleting?.idvehicule) return;

    this.deleteErrorMsg = '';

    this.vehiculeService.delete(this.deleting.idvehicule).subscribe({
      next: () => {
        this.closeDelete();
        this.vehiculeService.refresh();
        this.showSuccess('Véhicule supprimé avec succès ✅');
      },
      error: (err) => {
        this.deleteErrorMsg = err?.error?.message || 'Erreur suppression véhicule.';
      }
    });
  }

  exportExcel(): void {
    const data = this.filteredVehicules.map(v => ({
      Immatriculation: v.immatriculation,
      Marque: v.marque,
      Modele: v.modele,
      Kilometrage: v.kilometrage,
      TypeCarburant: v.typeCarburant,
      DateAchat: v.dateAchat,
      Etat: v.etat
    }));

    const ws = XLSX.utils.json_to_sheet(data);
    const wb: XLSX.WorkBook = { Sheets: { Vehicules: ws }, SheetNames: ['Vehicules'] };
    XLSX.writeFile(wb, 'vehicules.xlsx');

    this.showSuccess('Export Excel effectué avec succès.');
  }

  exportPDF(): void {
    const rows = this.filteredVehicules.map(v => [
      v.immatriculation ?? '',
      v.marque ?? '',
      v.modele ?? '',
      v.kilometrage ?? 0,
      v.typeCarburant ?? '',
      v.dateAchat ?? '',
      v.etat ?? ''
    ]);

    const doc = new jsPDF('landscape');

    doc.setFontSize(14);
    doc.text('Liste des vehicules', 14, 15);

    autoTable(doc, {
      startY: 22,
      head: [[
        'Immatriculation',
        'Marque',
        'Modele',
        'Kilometrage',
        'Type carburant',
        'Date achat',
        'Etat'
      ]],
      body: rows,
      styles: {
        fontSize: 9
      },
      headStyles: {
        fillColor: [41, 128, 185]
      }
    });

    doc.save('vehicules.pdf');
    this.showSuccess('Export PDF effectué avec succès.');
  }

  openFiche(v: VehiculeDto): void {
    this.selectedVehicule = v;
  }

  closeFiche(): void {
    this.selectedVehicule = undefined;
  }

  getVehiculeAvatarText(v?: VehiculeDto): string {
    if (!v) return 'VH';

    const marque = (v.marque || '').trim();
    const modele = (v.modele || '').trim();

    const a = marque ? marque.charAt(0) : 'V';
    const b = modele ? modele.charAt(0) : 'H';

    return (a + b).toUpperCase();
  }

  getVehiculeFicheBlocks(): FicheBlock[] {
    if (!this.selectedVehicule) return [];

    const v = this.selectedVehicule;
    const km = Number(v.kilometrage ?? 0);
    const utilisation = Math.max(0, Math.min(100, Math.round(km / 2000)));
    const etatTone =
      v.etat === 'Disponible' ? 'success' :
      v.etat === 'En panne' ? 'danger' :
      v.etat === 'En maintenance' ? 'info' :
      v.etat === 'Neuf' ? 'warn' : 'default';

    const entretien =
      km >= 100000 ? 'Contrôle recommandé' :
      km >= 60000 ? 'À surveiller' :
      'RAS';

    const entretienTone =
      km >= 100000 ? 'danger' :
      km >= 60000 ? 'warn' : 'success';

    return [
      {
        type: 'info-grid',
        title: 'Informations générales',
        items: [
          { label: 'ID', value: v.idvehicule },
          { label: 'Immatriculation', value: v.immatriculation },
          { label: 'Marque', value: v.marque },
          { label: 'Modèle', value: v.modele }
        ]
      },
      {
        type: 'info-grid',
        title: 'Informations véhicule',
        items: [
          { label: 'Type carburant', value: v.typeCarburant || '-' },
          { label: 'Date achat', value: v.dateAchat || '-' },
          { label: 'Kilométrage', value: `${km.toLocaleString()} km` },
          { label: 'État', value: v.etat || '-' }
        ]
      },
      {
        type: 'stats-grid',
        title: 'Indicateurs',
        items: [
          {
            label: 'Kilométrage',
            value: `${km.toLocaleString()} km`,
            sub: km >= 100000 ? 'Kilométrage élevé' : 'Kilométrage normal',
            icon: '📈',
            tone: km >= 100000 ? 'warn' : 'info'
          },
          {
            label: 'État actuel',
            value: v.etat || '-',
            sub: 'Statut du véhicule',
            icon: v.etat === 'Disponible' ? '✅' : v.etat === 'En panne' ? '⛔' : v.etat === 'En maintenance' ? '🛠️' : '✨',
            tone: etatTone
          }
        ]
      },
      {
        type: 'status-grid',
        title: 'Résumé',
        items: [
          {
            label: 'Disponibilité',
            value: v.etat === 'Disponible' ? 'Prêt à l’usage' : 'Non disponible',
            icon: v.etat === 'Disponible' ? '🟢' : '🔴',
            tone: v.etat === 'Disponible' ? 'success' : 'danger'
          },
          {
            label: 'Entretien',
            value: entretien,
            icon: '🧰',
            tone: entretienTone
          }
        ]
      },
      {
        type: 'progress-grid',
        title: 'Suivi',
        items: [
          {
            label: 'Niveau d’utilisation estimé',
            value: utilisation,
            suffix: '%',
            tone: km >= 100000 ? 'warn' : 'info'
          }
        ]
      }
    ];
  }
}