import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import * as XLSX from 'xlsx';
import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';
import { Router } from '@angular/router';
import { IncidentDto, IncidentService } from '../../../auth/services/incident.service';
import { InterventionService } from '../../../auth/services/intervention.service';

type SortBy = 'RECENT' | 'ANCIEN';

@Component({
  selector: 'app-incidents',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './incidents.html',
  styleUrls: ['./incidents.scss']
})
export class IncidentsComponent implements OnInit {
  incidents: IncidentDto[] = [];
  loading = false;
  errorMsg = '';
  successMsg = '';

  searchTerm = '';
  sortBy: SortBy = 'RECENT';

  page = 1;
  pageSize = 8;
  pageSizes = [5, 8, 10, 15, 20];

  sortColumnName: string = '';
  sortDirection: 'asc' | 'desc' = 'asc';

  stats = {
    total: 0,
    today: 0
  };

  showInterventionModal = false;
  selectedIncident: IncidentDto | null = null;

  interventionForm = {
    typeIntervention: '',
    description: '',
    cout: null as number | null
  };

  treatedIncidentIds = new Set<number>();

  constructor(
    private incidentService: IncidentService,
    private interventionService: InterventionService,
    private router: Router
  ) {}

  ngOnInit(): void {
    this.load();
  }

  sortColumn(column: string): void {
    if (this.sortColumnName === column) {
      this.sortDirection = this.sortDirection === 'asc' ? 'desc' : 'asc';
    } else {
      this.sortColumnName = column;
      this.sortDirection = 'asc';
    }

    this.page = 1;
  }

  private normalize(v: any): string {
    return (v ?? '').toString().trim().toLowerCase();
  }

  private isToday(value: string | null | undefined): boolean {
    if (!value) return false;
    const d = new Date(value);
    const now = new Date();

    return d.getFullYear() === now.getFullYear()
      && d.getMonth() === now.getMonth()
      && d.getDate() === now.getDate();
  }

  private computeStats(list: IncidentDto[]): void {
    this.stats.total = list.length;
    this.stats.today = list.filter(i => this.isToday(i.dateIncident)).length;
  }

  private showSuccess(msg: string): void {
    this.successMsg = msg;
    this.errorMsg = '';

    setTimeout(() => {
      this.successMsg = '';
    }, 3000);
  }

  private showError(msg: string): void {
    this.errorMsg = msg;
    this.successMsg = '';
  }

  load(): void {
    this.loading = true;
    this.errorMsg = '';

    this.incidentService.getAll().subscribe({
      next: (data: IncidentDto[]) => {
        this.incidents = data ?? [];
        this.computeStats(this.incidents);
        this.loading = false;
        this.page = 1;
        this.loadTreatedIncidents();
      },
      error: (err: any) => {
        console.error(err);
        this.showError('Erreur lors du chargement des incidents.');
        this.loading = false;
      }
    });
  }

  private loadTreatedIncidents(): void {
    this.interventionService.getAll().subscribe({
      next: (data) => {
        this.treatedIncidentIds = new Set((data ?? []).map(x => x.idincident));
      },
      error: () => {
        this.treatedIncidentIds = new Set<number>();
      }
    });
  }

  isIncidentTreated(idincident: number): boolean {
    return this.treatedIncidentIds.has(idincident);
  }

  onFiltersChange(): void {
    this.page = 1;
  }

  private getSortableValue(i: IncidentDto, column: string): any {
    switch (column) {
      case 'idincident':
        return Number(i.idincident ?? 0);
      case 'dateIncident':
        return new Date(i.dateIncident || 0).getTime();
      case 'typeIncident':
        return this.normalize(i.typeIncident);
      case 'description':
        return this.normalize(i.description);
      case 'idmission':
        return Number(i.idmission ?? 0);
      case 'adresse':
        return this.normalize(i.adresse);
      default:
        return this.normalize((i as any)[column]);
    }
  }

  private sortList(list: IncidentDto[]): IncidentDto[] {
    const arr = [...list];

    if (this.sortColumnName) {
      arr.sort((a, b) => {
        const v1 = this.getSortableValue(a, this.sortColumnName);
        const v2 = this.getSortableValue(b, this.sortColumnName);

        if (v1 < v2) return this.sortDirection === 'asc' ? -1 : 1;
        if (v1 > v2) return this.sortDirection === 'asc' ? 1 : -1;
        return 0;
      });

      return arr;
    }

    arr.sort((a, b) => {
      const da = new Date(a.dateIncident || 0).getTime();
      const db = new Date(b.dateIncident || 0).getTime();
      return this.sortBy === 'ANCIEN' ? da - db : db - da;
    });

    return arr;
  }

  get filteredIncidents(): IncidentDto[] {
    const q = this.normalize(this.searchTerm);

    const base = this.incidents.filter(i => {
      const fullText = this.normalize(`
        ${i.idincident}
        ${i.idmission}
        ${i.typeIncident}
        ${i.description}
        ${i.dateIncident}
        ${i.adresse ?? ''}
        ${i.latitude ?? ''}
        ${i.longitude ?? ''}
      `);

      return !q || fullText.includes(q);
    });

    return this.sortList(base);
  }

  get totalItems(): number {
    return this.filteredIncidents.length;
  }

  get totalPages(): number {
    return Math.max(1, Math.ceil(this.totalItems / this.pageSize));
  }

  get pagedIncidents(): IncidentDto[] {
    const start = (this.page - 1) * this.pageSize;
    return this.filteredIncidents.slice(start, start + this.pageSize);
  }

  goToPage(p: number): void {
    if (p < 1) p = 1;
    if (p > this.totalPages) p = this.totalPages;
    this.page = p;
  }

  nextPage(): void {
    this.goToPage(this.page + 1);
  }

  prevPage(): void {
    this.goToPage(this.page - 1);
  }

  onPageSizeChange(): void {
    this.page = 1;
  }

  refresh(): void {
    this.load();
  }

  exportExcel(): void {
    const data = this.filteredIncidents.map(i => ({
      ID_Incident: i.idincident,
      DateIncident: i.dateIncident,
      TypeIncident: i.typeIncident,
      Description: i.description,
      ID_Mission: i.idmission,
      Adresse: i.adresse || '-',
      Latitude: i.latitude ?? '-',
      Longitude: i.longitude ?? '-',
      Intervention: this.isIncidentTreated(i.idincident) ? 'Oui' : 'Non'
    }));

    const ws: XLSX.WorkSheet = XLSX.utils.json_to_sheet(data);
    const wb: XLSX.WorkBook = { Sheets: { Incidents: ws }, SheetNames: ['Incidents'] };
    XLSX.writeFile(wb, 'incidents.xlsx');
  }

  exportPDF(): void {
    const rows = this.filteredIncidents.map(i => [
      i.idincident ?? '',
      i.dateIncident ?? '',
      i.typeIncident || '-',
      i.description || '-',
      i.idmission ?? '',
      i.adresse || '-',
      this.isIncidentTreated(i.idincident) ? 'Oui' : 'Non'
    ]);

    const doc = new jsPDF('landscape');

    doc.setFontSize(14);
    doc.text('Liste des incidents', 14, 15);

    autoTable(doc, {
      startY: 22,
      head: [[
        'ID Incident',
        'Date',
        'Type',
        'Description',
        'ID Mission',
        'Adresse',
        'Intervention'
      ]],
      body: rows,
      styles: {
        fontSize: 9
      },
      headStyles: {
        fillColor: [41, 128, 185]
      }
    });

    doc.save('incidents.pdf');
  }

  openMap(incident: IncidentDto): void {
    if (incident.latitude !== null && incident.longitude !== null) {
      window.open(
        `https://www.google.com/maps?q=${incident.latitude},${incident.longitude}`,
        '_blank'
      );
    }
  }

  openInterventionModal(incident: IncidentDto): void {
    if (this.isIncidentTreated(incident.idincident)) return;

    this.errorMsg = '';
    this.selectedIncident = incident;
    this.interventionForm = {
      typeIntervention: '',
      description: '',
      cout: null
    };
    this.showInterventionModal = true;
  }

  closeInterventionModal(): void {
    this.showInterventionModal = false;
    this.selectedIncident = null;
    this.errorMsg = '';
    this.interventionForm = {
      typeIntervention: '',
      description: '',
      cout: null
    };
  }

  submitIntervention(): void {
    this.errorMsg = '';

    if (!this.selectedIncident) {
      this.showError('Incident introuvable.');
      return;
    }

    if (!this.interventionForm.typeIntervention.trim()) {
      this.showError('Type intervention obligatoire.');
      return;
    }

    if (!this.interventionForm.description.trim()) {
      this.showError('Description obligatoire.');
      return;
    }

    const payload = {
      idincident: this.selectedIncident.idincident,
      typeIntervention: this.interventionForm.typeIntervention,
      description: this.interventionForm.description,
      cout: this.interventionForm.cout
    };

    this.interventionService.create(payload).subscribe({
      next: () => {
        this.treatedIncidentIds.add(this.selectedIncident!.idincident);
        this.closeInterventionModal();
        this.showSuccess('Intervention créée avec succès.');
      },
      error: (err: any) => {
        console.error(err);
        this.showError(
          err?.error?.message ||
          err?.error ||
          'Erreur lors de la création de l’intervention.'
        );
      }
    });
  }

  goToIncidentLinked(idincident: number): void {
    this.router.navigate(['/home/incidents'], {
      queryParams: { incidentId: idincident }
    });
  }
}