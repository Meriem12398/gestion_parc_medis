import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import * as XLSX from 'xlsx';
import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';
import { MissionDetailsDto, MissionDto, MissionService } from '../../../../auth/services/mission.service';

type StatutMissionFilter = 'ALL' | 'TERMINEE' | 'ANNULEE';
type SortBy = 'RECENT' | 'ANCIEN';
type QuickFilter = 'NONE' | 'TERMINEE' | 'ANNULEE';

@Component({
  selector: 'app-historique-missions',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './historique-missions.html',
  styleUrl: './historique-missions.scss'
})
export class HistoriqueMissionsComponent implements OnInit {

  missions: MissionDto[] = [];
  loading = false;
  pageErrorMsg = '';
  successMsg = '';

  searchTerm = '';
  statutFilter: StatutMissionFilter = 'ALL';
  sortBy: SortBy = 'RECENT';
  quickFilter: QuickFilter = 'NONE';

  page = 1;
  pageSize = 8;
  pageSizes = [5, 8, 10, 15, 20];

  sortColumnName: string = '';
  sortDirection: 'asc' | 'desc' = 'asc';

  detailsOpen = false;
  detailsLoading = false;
  detailsErrorMsg = '';
  selectedMission: MissionDetailsDto | null = null;

  stats = {
    total: 0,
    terminees: 0,
    annulees: 0
  };

  constructor(private missionService: MissionService) {}

  ngOnInit(): void {
    this.load();
  }

  sortColumn(column: string): void {
    if (this.sortColumnName === column) {
      this.sortDirection = this.sortDirection === 'asc' ? 'desc' : 'asc';
    } else {
      this.sortColumnName = column;
      this.sortDirection = 'asc';
    }

    this.page = 1;
  }

  private normalize(v: any): string {
    return (v ?? '').toString().trim().toLowerCase();
  }

  private computeStats(list: MissionDto[]): void {
    const historique = (list || []).filter(m => {
      const st = this.normalize(m.statutMission);
      return st === 'terminee' || st === 'annulee';
    });

    this.stats.total = historique.length;
    this.stats.terminees = historique.filter(m => this.normalize(m.statutMission) === 'terminee').length;
    this.stats.annulees = historique.filter(m => this.normalize(m.statutMission) === 'annulee').length;
  }

  private showSuccess(msg: string): void {
    this.successMsg = msg;
    this.pageErrorMsg = '';

    setTimeout(() => {
      this.successMsg = '';
    }, 3000);
  }

  private showError(msg: string): void {
    this.pageErrorMsg = msg;
    this.successMsg = '';
  }

  load(): void {
    this.loading = true;
    this.pageErrorMsg = '';

    this.missionService.getAll().subscribe({
      next: (data: MissionDto[]) => {
        this.missions = data || [];
        this.computeStats(this.missions);
        this.loading = false;
        this.goToPage(this.page);
      },
      error: (err: any) => {
        console.error(err);
        this.showError('Erreur lors du chargement de l’historique des missions');
        this.loading = false;
      }
    });
  }

  setQuickFilter(q: QuickFilter): void {
    this.quickFilter = this.quickFilter === q ? 'NONE' : q;
    this.page = 1;
  }

  onFiltersChange(): void {
    this.page = 1;
  }

  private matchStatut(m: MissionDto): boolean {
    if (this.statutFilter === 'ALL') return true;
    return this.normalize(m.statutMission) === this.normalize(this.statutFilter);
  }

  private applyQuickFilter(m: MissionDto): boolean {
    switch (this.quickFilter) {
      case 'TERMINEE':
        return this.normalize(m.statutMission) === 'terminee';
      case 'ANNULEE':
        return this.normalize(m.statutMission) === 'annulee';
      default:
        return true;
    }
  }

  private getSortableValue(m: MissionDto, column: string): any {
    switch (column) {
      case 'idmission':
        return Number(m.idmission ?? 0);
      case 'dateDebut':
        return new Date(m.dateDebut || 0).getTime();
      case 'dateFin':
        return new Date(m.dateFin || 0).getTime();
      case 'statutMission':
        return this.normalize(m.statutMission);
      case 'immatriculationVehicule':
        return this.normalize(m.immatriculationVehicule);
      case 'chauffeurFullName':
        return this.normalize(`${m.chauffeurPrenom ?? ''} ${m.chauffeurNom ?? ''}`);
      case 'iddemande':
        return Number(m.iddemande ?? 0);
      default:
        return this.normalize((m as any)[column]);
    }
  }

  private sortList(list: MissionDto[]): MissionDto[] {
    const arr = [...list];

    if (this.sortColumnName) {
      arr.sort((a, b) => {
        const v1 = this.getSortableValue(a, this.sortColumnName);
        const v2 = this.getSortableValue(b, this.sortColumnName);

        if (v1 < v2) return this.sortDirection === 'asc' ? -1 : 1;
        if (v1 > v2) return this.sortDirection === 'asc' ? 1 : -1;
        return 0;
      });

      return arr;
    }

    arr.sort((a, b) => {
      const da = new Date(a.dateDebut || 0).getTime();
      const db = new Date(b.dateDebut || 0).getTime();

      switch (this.sortBy) {
        case 'ANCIEN':
          return da - db;
        case 'RECENT':
        default:
          return db - da;
      }
    });

    return arr;
  }

  get filteredMissions(): MissionDto[] {
    const q = this.normalize(this.searchTerm);

    const base = (this.missions || []).filter(m => {
      const st = this.normalize(m.statutMission);
      const historiqueOnly = st === 'terminee' || st === 'annulee';
      if (!historiqueOnly) return false;

      const chauffeurFullName = `${m.chauffeurPrenom ?? ''} ${m.chauffeurNom ?? ''}`.trim();

      const fullText = this.normalize(
        `${m.idmission} ${m.statutMission} ${m.idvehicule} ${m.iddemande} ${m.chauffeurMatricule ?? ''} ${m.immatriculationVehicule ?? ''} ${chauffeurFullName}`
      );

      const matchSearch = !q || fullText.includes(q);
      const matchStatut = this.matchStatut(m);
      const matchQuick = this.applyQuickFilter(m);

      return matchSearch && matchStatut && matchQuick;
    });

    return this.sortList(base);
  }

  get totalItems(): number {
    return this.filteredMissions.length;
  }

  get totalPages(): number {
    return Math.max(1, Math.ceil(this.totalItems / this.pageSize));
  }

  get pagedMissions(): MissionDto[] {
    const start = (this.page - 1) * this.pageSize;
    return this.filteredMissions.slice(start, start + this.pageSize);
  }

  goToPage(p: number): void {
    if (p < 1) p = 1;
    if (p > this.totalPages) p = this.totalPages;
    this.page = p;
  }

  nextPage(): void {
    this.goToPage(this.page + 1);
  }

  prevPage(): void {
    this.goToPage(this.page - 1);
  }

  onPageSizeChange(): void {
    this.page = 1;
  }

  exportExcel(): void {
    const data = this.filteredMissions.map(m => ({
      ID_Mission: m.idmission,
      DateDebut: m.dateDebut,
      DateFin: m.dateFin ?? '-',
      Statut: m.statutMission,
      Vehicule: m.immatriculationVehicule ?? '-',
      Chauffeur: `${m.chauffeurPrenom ?? ''} ${m.chauffeurNom ?? ''}`.trim() || '-',
      ID_Demande: m.iddemande
    }));

    const ws: XLSX.WorkSheet = XLSX.utils.json_to_sheet(data);
    const wb: XLSX.WorkBook = { Sheets: { HistoriqueMissions: ws }, SheetNames: ['HistoriqueMissions'] };
    XLSX.writeFile(wb, 'historique-missions.xlsx');

    this.showSuccess('Export Excel effectué avec succès.');
  }

  exportPDF(): void {
    const rows = this.filteredMissions.map(m => [
      m.idmission ?? '',
      m.dateDebut ?? '',
      m.dateFin ?? '-',
      m.statutMission ?? '',
      m.immatriculationVehicule ?? '-',
      `${m.chauffeurPrenom ?? ''} ${m.chauffeurNom ?? ''}`.trim() || '-',
      m.iddemande ?? ''
    ]);

    const doc = new jsPDF('landscape');

    doc.setFontSize(14);
    doc.text('Historique des missions', 14, 15);

    autoTable(doc, {
      startY: 22,
      head: [[
        'ID Mission',
        'Date Debut',
        'Date Fin',
        'Statut',
        'Vehicule',
        'Chauffeur',
        'ID Demande'
      ]],
      body: rows,
      styles: {
        fontSize: 9
      },
      headStyles: {
        fillColor: [41, 128, 185]
      }
    });

    doc.save('historique-missions.pdf');
    this.showSuccess('Export PDF effectué avec succès.');
  }

  openDetails(m: MissionDto): void {
    this.detailsOpen = true;
    this.detailsLoading = true;
    this.detailsErrorMsg = '';
    this.selectedMission = null;

    this.missionService.getDetails(m.idmission).subscribe({
      next: (data: MissionDetailsDto) => {
        this.selectedMission = data;
        this.detailsLoading = false;
      },
      error: (err: any) => {
        console.error(err);
        this.detailsErrorMsg = 'Erreur lors du chargement des détails';
        this.detailsLoading = false;
      }
    });
  }

  closeDetails(): void {
    this.detailsOpen = false;
    this.detailsLoading = false;
    this.detailsErrorMsg = '';
    this.selectedMission = null;
  }
}