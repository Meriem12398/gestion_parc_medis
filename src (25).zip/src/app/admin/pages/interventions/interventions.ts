import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import * as XLSX from 'xlsx';
import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';
import { Router } from '@angular/router';
import { InterventionHistoriqueDto, InterventionService } from '../../../auth/services/intervention.service';

type SortBy = 'RECENT' | 'ANCIEN';

@Component({
  selector: 'app-interventions',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './interventions.html',
  styleUrls: ['./interventions.scss']
})
export class InterventionsComponent implements OnInit {
  interventions: InterventionHistoriqueDto[] = [];
  loading = false;
  errorMsg = '';
  successMsg = '';

  searchTerm = '';
  vehiculeFilter = '';
  sortBy: SortBy = 'RECENT';

  page = 1;
  pageSize = 8;
  pageSizes = [5, 8, 10, 15, 20];

  sortColumnName: string = '';
  sortDirection: 'asc' | 'desc' = 'asc';

  stats = {
    total: 0,
    totalCost: 0
  };

  constructor(
    private interventionService: InterventionService,
    private router: Router
  ) {}

  ngOnInit(): void {
    this.load();
  }

  sortColumn(column: string): void {
    if (this.sortColumnName === column) {
      this.sortDirection = this.sortDirection === 'asc' ? 'desc' : 'asc';
    } else {
      this.sortColumnName = column;
      this.sortDirection = 'asc';
    }

    this.page = 1;
  }

  private normalize(v: any): string {
    return (v ?? '').toString().trim().toLowerCase();
  }

  private computeStats(list: InterventionHistoriqueDto[]): void {
    this.stats.total = list.length;
    this.stats.totalCost = list.reduce((sum, i) => sum + Number(i.cout ?? 0), 0);
  }

  private showSuccess(msg: string): void {
    this.successMsg = msg;
    this.errorMsg = '';

    setTimeout(() => {
      this.successMsg = '';
    }, 3000);
  }

  private showError(msg: string): void {
    this.errorMsg = msg;
    this.successMsg = '';
  }

  load(): void {
    this.loading = true;
    this.errorMsg = '';

    this.interventionService.getHistorique().subscribe({
      next: (data: InterventionHistoriqueDto[]) => {
        this.interventions = data ?? [];
        this.computeStats(this.interventions);
        this.loading = false;
        this.page = 1;
      },
      error: (err: any) => {
        console.error(err);
        this.showError('Erreur lors du chargement de l’historique des interventions.');
        this.loading = false;
      }
    });
  }

  onFiltersChange(): void {
    this.page = 1;
  }

  private getSortableValue(i: InterventionHistoriqueDto, column: string): any {
    switch (column) {
      case 'idintervention':
        return Number(i.idintervention ?? 0);
      case 'dateIntervention':
        return new Date(i.dateIntervention || 0).getTime();
      case 'typeIntervention':
        return this.normalize(i.typeIntervention);
      case 'description':
        return this.normalize(i.description);
      case 'cout':
        return Number(i.cout ?? 0);
      case 'idincident':
        return Number(i.idincident ?? 0);
      case 'idmission':
        return Number(i.idmission ?? 0);
      case 'vehiculeFull':
        return this.normalize(
          `${i.immatriculationVehicule ?? ''} ${i.marqueVehicule ?? ''} ${i.modeleVehicule ?? ''}`
        );
      default:
        return this.normalize((i as any)[column]);
    }
  }

  private sortList(list: InterventionHistoriqueDto[]): InterventionHistoriqueDto[] {
    const arr = [...list];

    if (this.sortColumnName) {
      arr.sort((a, b) => {
        const v1 = this.getSortableValue(a, this.sortColumnName);
        const v2 = this.getSortableValue(b, this.sortColumnName);

        if (v1 < v2) return this.sortDirection === 'asc' ? -1 : 1;
        if (v1 > v2) return this.sortDirection === 'asc' ? 1 : -1;
        return 0;
      });

      return arr;
    }

    arr.sort((a, b) => {
      const da = new Date(a.dateIntervention || 0).getTime();
      const db = new Date(b.dateIntervention || 0).getTime();
      return this.sortBy === 'ANCIEN' ? da - db : db - da;
    });

    return arr;
  }

  get filteredInterventions(): InterventionHistoriqueDto[] {
    const q = this.normalize(this.searchTerm);
    const vehiculeQ = this.normalize(this.vehiculeFilter);

    const base = this.interventions.filter(i => {
      const fullText = this.normalize(`
        ${i.idintervention}
        ${i.idincident}
        ${i.idmission ?? ''}
        ${i.idvehicule ?? ''}
        ${i.immatriculationVehicule ?? ''}
        ${i.marqueVehicule ?? ''}
        ${i.modeleVehicule ?? ''}
        ${i.typeIntervention}
        ${i.description}
        ${i.cout ?? ''}
        ${i.dateIntervention}
      `);

      const vehiculeText = this.normalize(`
        ${i.immatriculationVehicule ?? ''}
        ${i.marqueVehicule ?? ''}
        ${i.modeleVehicule ?? ''}
        ${i.idvehicule ?? ''}
      `);

      const matchSearch = !q || fullText.includes(q);
      const matchVehicule = !vehiculeQ || vehiculeText.includes(vehiculeQ);

      return matchSearch && matchVehicule;
    });

    return this.sortList(base);
  }

  get totalItems(): number {
    return this.filteredInterventions.length;
  }

  get totalPages(): number {
    return Math.max(1, Math.ceil(this.totalItems / this.pageSize));
  }

  get pagedInterventions(): InterventionHistoriqueDto[] {
    const start = (this.page - 1) * this.pageSize;
    return this.filteredInterventions.slice(start, start + this.pageSize);
  }

  goToPage(p: number): void {
    if (p < 1) p = 1;
    if (p > this.totalPages) p = this.totalPages;
    this.page = p;
  }

  nextPage(): void {
    this.goToPage(this.page + 1);
  }

  prevPage(): void {
    this.goToPage(this.page - 1);
  }

  onPageSizeChange(): void {
    this.page = 1;
  }

  refresh(): void {
    this.load();
  }

  goToIncidentLinked(idincident: number): void {
    this.router.navigate(['/home/incidents'], {
      queryParams: { incidentId: idincident }
    });
  }

  exportExcel(): void {
    const data = this.filteredInterventions.map(i => ({
      ID_Intervention: i.idintervention,
      DateIntervention: i.dateIntervention,
      TypeIntervention: i.typeIntervention,
      Description: i.description,
      Cout: i.cout ?? 0,
      ID_Incident: i.idincident,
      ID_Mission: i.idmission ?? '-',
      ID_Vehicule: i.idvehicule ?? '-',
      Immatriculation: i.immatriculationVehicule ?? '-',
      Marque: i.marqueVehicule ?? '-',
      Modele: i.modeleVehicule ?? '-'
    }));

    const ws: XLSX.WorkSheet = XLSX.utils.json_to_sheet(data);
    const wb: XLSX.WorkBook = { Sheets: { Interventions: ws }, SheetNames: ['Interventions'] };
    XLSX.writeFile(wb, 'historique-interventions.xlsx');

    this.showSuccess('Export Excel effectué avec succès.');
  }

  exportPDF(): void {
    const rows = this.filteredInterventions.map(i => [
      i.idintervention ?? '',
      i.dateIntervention ?? '',
      i.typeIntervention || '-',
      i.description || '-',
      i.cout ?? 0,
      i.idincident ?? '',
      i.idmission ?? '-',
      ((i.immatriculationVehicule || '') + ' ' + (i.marqueVehicule || '') + ' ' + (i.modeleVehicule || '')).trim() || '-'
    ]);

    const doc = new jsPDF('landscape');

    doc.setFontSize(14);
    doc.text('Historique des interventions', 14, 15);

    autoTable(doc, {
      startY: 22,
      head: [[
        'ID Intervention',
        'Date',
        'Type',
        'Description',
        'Cout',
        'ID Incident',
        'ID Mission',
        'Vehicule'
      ]],
      body: rows,
      styles: {
        fontSize: 8
      },
      headStyles: {
        fillColor: [41, 128, 185]
      }
    });

    doc.save('historique-interventions.pdf');
    this.showSuccess('Export PDF effectué avec succès.');
  }
}