import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';



import * as XLSX from 'xlsx';
import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';
import { Demande } from '../../../../models/demande.model';
import { DemandeService } from '../../../../auth/services/demande.service';

type StatutFilter = 'ALL' | 'REFUSEE' | 'AFFECTEE';
type PrioriteFilter = 'ALL' | 'Haute' | 'Moyenne' | 'Faible';
type SortBy = 'RECENT' | 'ANCIEN' | 'PRIO_HIGH' | 'PRIO_LOW';
type QuickFilter = 'NONE' | 'REFUSEE' | 'AFFECTEE';

@Component({
  selector: 'app-historique-demandes',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './historique-demandes.html',
  styleUrl: './historique-demandes.scss'
})
export class HistoriqueDemandesComponent implements OnInit {

  demandes: Demande[] = [];
  loading = false;

  pageErrorMsg = '';
  successMsg = '';

  searchTerm = '';
  statutFilter: StatutFilter = 'ALL';
  prioriteFilter: PrioriteFilter = 'ALL';
  sortBy: SortBy = 'RECENT';
  quickFilter: QuickFilter = 'NONE';

  page = 1;
  pageSize = 8;
  pageSizes = [5, 8, 10, 15, 20];

  sortColumnName: string = '';
  sortDirection: 'asc' | 'desc' = 'asc';

  stats = {
    total: 0,
    refusee: 0,
    affectee: 0
  };

  constructor(private demandeService: DemandeService) {}

  ngOnInit(): void {
    this.load();
  }

  private normalizeStatut(s: any): string {
    return (s ?? '')
      .toString()
      .trim()
      .toLowerCase()
      .replace(/é/g, 'e')
      .replace(/è/g, 'e')
      .replace(/ê/g, 'e');
  }

  private normalize(s: any): string {
    return (s ?? '').toString().trim().toLowerCase();
  }

  isRefusee(d: Demande): boolean {
    const s = this.normalizeStatut((d as any)?.statut);
    return s === 'refusee' || s.includes('refus');
  }

  isAffectee(d: Demande): boolean {
    const s = this.normalizeStatut((d as any)?.statut);
    return s === 'affectee' || s.includes('affect');
  }

  private computeStats(list: Demande[]): void {
    const hist = (list || []).filter(d => this.isRefusee(d) || this.isAffectee(d));

    this.stats.total = hist.length;
    this.stats.refusee = hist.filter(d => this.isRefusee(d)).length;
    this.stats.affectee = hist.filter(d => this.isAffectee(d)).length;
  }

  private showError(msg: string) {
    this.pageErrorMsg = msg;
    this.successMsg = '';
  }

  load(): void {
    this.loading = true;
    this.pageErrorMsg = '';

    this.demandeService.getAll(undefined, undefined).subscribe({
      next: (data: Demande[]) => {
        this.demandes = data || [];
        this.computeStats(this.demandes);
        this.loading = false;
        this.goToPage(this.page);
      },
      error: (err: any) => {
        console.error(err);
        this.showError('Erreur lors du chargement de l’historique des demandes');
        this.loading = false;
      }
    });
  }

  sortColumn(column: string): void {
    if (this.sortColumnName === column) {
      this.sortDirection = this.sortDirection === 'asc' ? 'desc' : 'asc';
    } else {
      this.sortColumnName = column;
      this.sortDirection = 'asc';
    }

    this.page = 1;
  }

  setQuickFilter(q: QuickFilter | any): void {
    const key = (q ?? 'NONE') as QuickFilter;
    this.quickFilter = (this.quickFilter === key) ? 'NONE' : key;
    this.page = 1;
  }

  onFiltersChange(): void {
    this.page = 1;
  }

  private matchStatutFilter(d: Demande): boolean {
    if (this.statutFilter === 'ALL') return true;
    return this.normalizeStatut((d as any).statut) === this.normalizeStatut(this.statutFilter);
  }

  private matchPrioriteFilter(d: Demande): boolean {
    if (this.prioriteFilter === 'ALL') return true;
    return ((d as any).priorite || '') === this.prioriteFilter;
  }

  private applyQuickFilter(d: Demande): boolean {
    switch (this.quickFilter) {
      case 'REFUSEE': return this.isRefusee(d);
      case 'AFFECTEE': return this.isAffectee(d);
      default: return true;
    }
  }

  private prioWeight(p: any): number {
    const v = (p ?? '').toString().trim().toLowerCase();
    if (v === 'haute') return 3;
    if (v === 'moyenne') return 2;
    if (v === 'faible') return 1;
    return 0;
  }

  private getSortableValue(d: any, column: string): any {
    switch (column) {
      case 'iddemande':
        return Number(d?.iddemande ?? 0);
      case 'typeDemande':
        return this.normalize(d?.typeDemande);
      case 'dateCreation':
        return new Date(d?.dateCreation || 0).getTime();
      case 'dateSouhaite':
        return new Date(d?.dateSouhaite || 0).getTime();
      case 'statut':
        return this.normalize(d?.statut);
      case 'priorite':
        return this.prioWeight(d?.priorite);
      case 'demandeurFullName':
        return this.normalize(`${d?.prenomCreateur ?? ''} ${d?.nomCreateur ?? ''}`);
      case 'departementCreateur':
        return this.normalize(d?.departementCreateur);
      default:
        return this.normalize(d?.[column]);
    }
  }

  private sortList(list: Demande[]): Demande[] {
    const arr = [...(list || [])];

    if (this.sortColumnName) {
      arr.sort((a: any, b: any) => {
        const v1 = this.getSortableValue(a, this.sortColumnName);
        const v2 = this.getSortableValue(b, this.sortColumnName);

        if (v1 < v2) return this.sortDirection === 'asc' ? -1 : 1;
        if (v1 > v2) return this.sortDirection === 'asc' ? 1 : -1;
        return 0;
      });

      return arr;
    }

    arr.sort((a: any, b: any) => {
      const da = new Date(a.dateCreation || 0).getTime();
      const db = new Date(b.dateCreation || 0).getTime();

      switch (this.sortBy) {
        case 'ANCIEN':
          return da - db;
        case 'PRIO_HIGH':
          return this.prioWeight(b.priorite) - this.prioWeight(a.priorite);
        case 'PRIO_LOW':
          return this.prioWeight(a.priorite) - this.prioWeight(b.priorite);
        case 'RECENT':
        default:
          return db - da;
      }
    });

    return arr;
  }

  get filteredDemandes(): Demande[] {
    const q = this.normalize(this.searchTerm);

    const base = (this.demandes || []).filter(d => {
      const historiqueOnly = this.isRefusee(d) || this.isAffectee(d);
      if (!historiqueOnly) return false;

      const fullText = this.normalize(
        `${(d as any).iddemande ?? ''} ${(d as any).typeDemande ?? ''} ${(d as any).statut ?? ''} ${(d as any).priorite ?? ''} ${(d as any).description ?? ''} ${(d as any).prenomCreateur ?? ''} ${(d as any).nomCreateur ?? ''} ${(d as any).departementCreateur ?? ''}`
      );

      const matchSearch = !q || fullText.includes(q);
      const matchStatut = this.matchStatutFilter(d);
      const matchPrio = this.matchPrioriteFilter(d);
      const matchQuick = this.applyQuickFilter(d);

      return matchSearch && matchStatut && matchPrio && matchQuick;
    });

    return this.sortList(base);
  }

  get totalItems(): number {
    return this.filteredDemandes.length;
  }

  get totalPages(): number {
    return Math.max(1, Math.ceil(this.totalItems / this.pageSize));
  }

  get pagedDemandes(): Demande[] {
    const start = (this.page - 1) * this.pageSize;
    return this.filteredDemandes.slice(start, start + this.pageSize);
  }

  goToPage(p: number): void {
    if (p < 1) p = 1;
    if (p > this.totalPages) p = this.totalPages;
    this.page = p;
  }

  nextPage(): void {
    this.goToPage(this.page + 1);
  }

  prevPage(): void {
    this.goToPage(this.page - 1);
  }

  onPageSizeChange(): void {
    this.page = 1;
  }

  exportExcel(): void {
    const data = this.filteredDemandes.map(d => ({
      ID: (d as any).iddemande,
      Type: (d as any).typeDemande,
      DateCreation: (d as any).dateCreation,
      DateSouhaite: (d as any).dateSouhaite,
      Statut: (d as any).statut,
      Priorite: (d as any).priorite,
      Description: (d as any).description,
      Demandeur: `${(d as any).prenomCreateur ?? ''} ${(d as any).nomCreateur ?? ''}`.trim(),
      Departement: (d as any).departementCreateur
    }));

    const ws: XLSX.WorkSheet = XLSX.utils.json_to_sheet(data);
    const wb: XLSX.WorkBook = { Sheets: { HistoriqueDemandes: ws }, SheetNames: ['HistoriqueDemandes'] };
    XLSX.writeFile(wb, 'historique-demandes.xlsx');
  }

  exportPDF(): void {
    const rows = this.filteredDemandes.map(d => [
      (d as any).iddemande ?? '',
      (d as any).typeDemande ?? '',
      (d as any).dateCreation ?? '',
      (d as any).dateSouhaite ?? '',
      (d as any).statut ?? '',
      (d as any).priorite ?? '',
      (d as any).description ?? '',
      `${(d as any).prenomCreateur ?? ''} ${(d as any).nomCreateur ?? ''}`.trim(),
      (d as any).departementCreateur ?? ''
    ]);

    const doc = new jsPDF('landscape');

    doc.setFontSize(14);
    doc.text('Historique des demandes', 14, 15);

    autoTable(doc, {
      startY: 22,
      head: [[
        'ID',
        'Type',
        'Date Creation',
        'Date Souhaitee',
        'Statut',
        'Priorite',
        'Description',
        'Demandeur',
        'Departement'
      ]],
      body: rows,
      styles: {
        fontSize: 8
      },
      headStyles: {
        fillColor: [41, 128, 185]
      }
    });

    doc.save('historique-demandes.pdf');
  }
}