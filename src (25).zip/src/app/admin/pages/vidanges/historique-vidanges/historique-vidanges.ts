import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { VidangeDto, VidangeService } from '../../../../auth/services/vidange.service';
import * as XLSX from 'xlsx';
import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';

type StatutFilter = 'ALL' | 'TERMINEE' | 'ANNULEE';

@Component({
  selector: 'app-historique-vidanges',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './historique-vidanges.html',
  styleUrl: './historique-vidanges.scss'
})
export class HistoriqueVidangesComponent implements OnInit {

  vidanges: VidangeDto[] = [];
  loading = false;
  errorMsg = '';
  searchTerm = '';
  statutFilter: StatutFilter = 'ALL';

  currentPage = 1;
  pageSize = 5;
  pageSizeOptions = [5, 8, 10, 15, 20];

  constructor(private vidangeService: VidangeService) {}

  ngOnInit(): void {
    this.load();
  }

  private normalize(v: any): string {
    return (v ?? '').toString().trim().toLowerCase();
  }

  load(): void {
    this.loading = true;
    this.errorMsg = '';

    this.vidangeService.getAll().subscribe({
      next: (data) => {
        const all = data ?? [];
        this.vidanges = all.filter(v => v.statut === 'TERMINEE' || v.statut === 'ANNULEE');
        this.loading = false;
        this.currentPage = 1;
      },
      error: () => {
        this.loading = false;
        this.errorMsg = 'Erreur lors du chargement de l’historique des vidanges.';
      }
    });
  }

  onFilterChange(): void {
    this.currentPage = 1;
  }

  get filteredVidanges(): VidangeDto[] {
    const q = this.normalize(this.searchTerm);

    return (this.vidanges || []).filter(v => {
      const fullText = this.normalize(
        `${v.idvidange ?? ''} ${v.immatriculationVehicule ?? ''} ${v.marqueVehicule ?? ''} ${v.modeleVehicule ?? ''} ${v.typeHuile ?? ''} ${v.remarque ?? ''} ${v.statut ?? ''}`
      );

      const matchSearch = !q || fullText.includes(q);
      const matchStatut = this.statutFilter === 'ALL' || v.statut === this.statutFilter;

      return matchSearch && matchStatut;
    });
  }

  get totalPages(): number {
    return Math.max(1, Math.ceil(this.filteredVidanges.length / this.pageSize));
  }

  get paginatedVidanges(): VidangeDto[] {
    const start = (this.currentPage - 1) * this.pageSize;
    const end = start + this.pageSize;
    return this.filteredVidanges.slice(start, end);
  }

  previousPage(): void {
    if (this.currentPage > 1) {
      this.currentPage--;
    }
  }

  nextPage(): void {
    if (this.currentPage < this.totalPages) {
      this.currentPage++;
    }
  }

  onPageSizeChange(): void {
    this.currentPage = 1;
  }

  get countTerminees(): number {
    return this.vidanges.filter(v => v.statut === 'TERMINEE').length;
  }

  get countAnnulees(): number {
    return this.vidanges.filter(v => v.statut === 'ANNULEE').length;
  }

  exportExcel(): void {
    const data = this.filteredVidanges.map(v => ({
      ID: v.idvidange,
      Immatriculation: v.immatriculationVehicule,
      Vehicule: `${v.marqueVehicule ?? ''} ${v.modeleVehicule ?? ''}`.trim(),
      DateVidange: v.dateVidange,
      KilometrageVidange: v.kilometrageVidange,
      TypeHuile: v.typeHuile,
      Cout: v.cout,
      Remarque: v.remarque,
      ProchaineDate: v.prochaineDate,
      ProchainKilometrage: v.prochainKilometrage,
      Statut: v.statut
    }));

    const ws = XLSX.utils.json_to_sheet(data);
    const wb: XLSX.WorkBook = { Sheets: { HistoriqueVidanges: ws }, SheetNames: ['HistoriqueVidanges'] };
    XLSX.writeFile(wb, 'historique_vidanges.xlsx');
  }

  exportPDF(): void {
    const rows = this.filteredVidanges.map(v => [
      v.idvidange ?? '',
      v.immatriculationVehicule ?? '',
      `${v.marqueVehicule ?? ''} ${v.modeleVehicule ?? ''}`.trim(),
      v.dateVidange ?? '',
      v.kilometrageVidange ?? '',
      v.typeHuile ?? '',
      v.cout ?? '',
      v.statut ?? ''
    ]);

    const doc = new jsPDF('landscape');

    doc.setFontSize(14);
    doc.text('Historique des vidanges', 14, 15);

    autoTable(doc, {
      startY: 22,
      head: [[
        'ID',
        'Immatriculation',
        'Vehicule',
        'Date vidange',
        'Km vidange',
        'Type huile',
        'Cout',
        'Statut'
      ]],
      body: rows,
      styles: { fontSize: 8 },
      headStyles: { fillColor: [41, 128, 185] }
    });

    doc.save('historique_vidanges.pdf');
  }
}