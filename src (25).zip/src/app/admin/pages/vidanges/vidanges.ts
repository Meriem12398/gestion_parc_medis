import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { VidangeDto, VidangeService } from '../../../auth/services/vidange.service';
import { VehiculeDto, VehiculeService } from '../../../auth/services/vehicule.service';
import * as XLSX from 'xlsx';
import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';

type StatutFilter = 'ALL' | 'A_FAIRE' | 'BIENTOT_DUE' | 'EN_RETARD';
type SortBy = 'RECENT' | 'ANCIEN' | 'DATE_ASC' | 'DATE_DESC' | 'KM_ASC' | 'KM_DESC';
type QuickFilter = 'NONE' | 'A_FAIRE' | 'BIENTOT_DUE' | 'EN_RETARD';

@Component({
  selector: 'app-vidanges',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './vidanges.html',
  styleUrl: './vidanges.scss'
})
export class VidangesComponent implements OnInit {

  vidanges: VidangeDto[] = [];
  vehicules: VehiculeDto[] = [];

  loading = false;
  errorMsg = '';
  successMsg = '';
  addErrorMsg = '';
  editErrorMsg = '';
  deleteErrorMsg = '';

  searchTerm = '';
  statutFilter: StatutFilter = 'ALL';
  sortBy: SortBy = 'RECENT';
  quickFilter: QuickFilter = 'NONE';

  page = 1;
  pageSize = 8;
  pageSizes = [5, 8, 10, 15, 20];

  sortColumnName = '';
  sortDirection: 'asc' | 'desc' = 'asc';

  addOpen = false;
  editOpen = false;
  deleteOpen = false;

  addModel: Partial<VidangeDto> = this.getEmptyAddModel();
  editModel?: VidangeDto;
  deleting?: VidangeDto;

  stats = {
    total: 0,
    aFaire: 0,
    bientot: 0,
    enRetard: 0
  };

  constructor(
    private vidangeService: VidangeService,
    private vehiculeService: VehiculeService
  ) {}

  ngOnInit(): void {
    this.load();
    this.vidangeService.onRefresh().subscribe(() => this.load());
  }

  private getEmptyAddModel(): Partial<VidangeDto> {
    return {
      vehiculeId: undefined,
      dateVidange: null,
      kilometrageVidange: null,
      typeHuile: '',
      cout: null,
      remarque: '',
      prochaineDate: null,
      prochainKilometrage: null,
      statut: 'A_FAIRE'
    };
  }

  private normalize(v: any): string {
    return (v ?? '').toString().trim().toLowerCase();
  }

  private showSuccess(msg: string): void {
    this.successMsg = msg;
    this.errorMsg = '';
    setTimeout(() => this.successMsg = '', 3000);
  }

  private showError(msg: string): void {
    this.errorMsg = msg;
    this.successMsg = '';
  }

  private computeStats(list: VidangeDto[]): void {
    this.stats.total = list.length;
    this.stats.aFaire = list.filter(v => v.statut === 'A_FAIRE').length;
    this.stats.bientot = list.filter(v => v.statut === 'BIENTOT_DUE').length;
    this.stats.enRetard = list.filter(v => v.statut === 'EN_RETARD').length;
  }

  load(): void {
    this.loading = true;
    this.errorMsg = '';

    this.vehiculeService.getAll().subscribe({
      next: (vehicules) => {
        this.vehicules = vehicules ?? [];

        this.vidangeService.getAll().subscribe({
          next: (data) => {
            const all = data ?? [];
            this.vidanges = all.filter(v =>
              v.statut === 'A_FAIRE' ||
              v.statut === 'BIENTOT_DUE' ||
              v.statut === 'EN_RETARD'
            );
            this.computeStats(this.vidanges);
            this.loading = false;
            this.page = 1;
          },
          error: () => {
            this.loading = false;
            this.showError('Erreur lors du chargement des vidanges.');
          }
        });
      },
      error: () => {
        this.loading = false;
        this.showError('Erreur lors du chargement des véhicules.');
      }
    });
  }

  setQuickFilter(q: QuickFilter): void {
    this.quickFilter = this.quickFilter === q ? 'NONE' : q;
    this.page = 1;
  }

  onFiltersChange(): void {
    this.page = 1;
  }

  sortColumn(column: string): void {
    if (this.sortColumnName === column) {
      this.sortDirection = this.sortDirection === 'asc' ? 'desc' : 'asc';
    } else {
      this.sortColumnName = column;
      this.sortDirection = 'asc';
    }
    this.page = 1;
  }

  private applyQuickFilter(v: VidangeDto): boolean {
    switch (this.quickFilter) {
      case 'A_FAIRE': return v.statut === 'A_FAIRE';
      case 'BIENTOT_DUE': return v.statut === 'BIENTOT_DUE';
      case 'EN_RETARD': return v.statut === 'EN_RETARD';
      default: return true;
    }
  }

  private getSortableValue(v: VidangeDto, column: string): any {
    switch (column) {
      case 'idvidange': return Number(v.idvidange ?? 0);
      case 'immatriculationVehicule': return this.normalize(v.immatriculationVehicule);
      case 'marqueVehicule': return this.normalize(v.marqueVehicule);
      case 'modeleVehicule': return this.normalize(v.modeleVehicule);
      case 'dateVidange': return v.dateVidange ? new Date(v.dateVidange).getTime() : 0;
      case 'kilometrageVidange': return Number(v.kilometrageVidange ?? 0);
      case 'prochaineDate': return v.prochaineDate ? new Date(v.prochaineDate).getTime() : 0;
      case 'prochainKilometrage': return Number(v.prochainKilometrage ?? 0);
      case 'statut': return this.normalize(v.statut);
      default: return this.normalize((v as any)[column]);
    }
  }

  private sortList(list: VidangeDto[]): VidangeDto[] {
    const arr = [...list];

    if (this.sortColumnName) {
      arr.sort((a, b) => {
        const v1 = this.getSortableValue(a, this.sortColumnName);
        const v2 = this.getSortableValue(b, this.sortColumnName);
        if (v1 < v2) return this.sortDirection === 'asc' ? -1 : 1;
        if (v1 > v2) return this.sortDirection === 'asc' ? 1 : -1;
        return 0;
      });
      return arr;
    }

    arr.sort((a, b) => {
      const da = Number(a.idvidange ?? 0);
      const db = Number(b.idvidange ?? 0);

      switch (this.sortBy) {
        case 'ANCIEN': return da - db;
        case 'DATE_ASC':
          return (a.prochaineDate ? new Date(a.prochaineDate).getTime() : 0) -
                 (b.prochaineDate ? new Date(b.prochaineDate).getTime() : 0);
        case 'DATE_DESC':
          return (b.prochaineDate ? new Date(b.prochaineDate).getTime() : 0) -
                 (a.prochaineDate ? new Date(a.prochaineDate).getTime() : 0);
        case 'KM_ASC':
          return Number(a.prochainKilometrage ?? 0) - Number(b.prochainKilometrage ?? 0);
        case 'KM_DESC':
          return Number(b.prochainKilometrage ?? 0) - Number(a.prochainKilometrage ?? 0);
        case 'RECENT':
        default:
          return db - da;
      }
    });

    return arr;
  }

  get filteredVidanges(): VidangeDto[] {
    const q = this.normalize(this.searchTerm);

    const base = (this.vidanges || []).filter(v => {
      const fullText = this.normalize(
        `${v.idvidange ?? ''} ${v.immatriculationVehicule ?? ''} ${v.marqueVehicule ?? ''} ${v.modeleVehicule ?? ''} ${v.typeHuile ?? ''} ${v.remarque ?? ''} ${v.statut ?? ''} ${v.prochainKilometrage ?? ''}`
      );

      const matchSearch = !q || fullText.includes(q);
      const matchStatut = this.statutFilter === 'ALL' || v.statut === this.statutFilter;
      const matchQuick = this.applyQuickFilter(v);

      return matchSearch && matchStatut && matchQuick;
    });

    return this.sortList(base);
  }

  get totalItems(): number {
    return this.filteredVidanges.length;
  }

  get totalPages(): number {
    return Math.max(1, Math.ceil(this.totalItems / this.pageSize));
  }

  get pagedVidanges(): VidangeDto[] {
    const start = (this.page - 1) * this.pageSize;
    return this.filteredVidanges.slice(start, start + this.pageSize);
  }

  goToPage(p: number): void {
    if (p < 1) p = 1;
    if (p > this.totalPages) p = this.totalPages;
    this.page = p;
  }

  nextPage(): void {
    this.goToPage(this.page + 1);
  }

  prevPage(): void {
    this.goToPage(this.page - 1);
  }

  onPageSizeChange(): void {
    this.page = 1;
  }

  openAdd(): void {
    this.addErrorMsg = '';
    this.addModel = this.getEmptyAddModel();
    this.addOpen = true;
  }

  closeAdd(): void {
    this.addOpen = false;
    this.addErrorMsg = '';
  }

  canSubmitAdd(): boolean {
    return !!this.addModel.vehiculeId && !!this.addModel.statut;
  }

  confirmAdd(): void {
    this.addErrorMsg = '';

    if (!this.canSubmitAdd()) {
      this.addErrorMsg = 'Veuillez remplir les champs obligatoires.';
      return;
    }

    this.vidangeService.create(this.addModel).subscribe({
      next: () => {
        this.closeAdd();
        this.vidangeService.refresh();
        this.showSuccess('Vidange ajoutée avec succès ✅');
      },
      error: (err) => {
        this.addErrorMsg = err?.error?.message || 'Erreur ajout vidange.';
      }
    });
  }

  onEdit(v: VidangeDto): void {
    this.editErrorMsg = '';
    this.editModel = { ...v };
    this.editOpen = true;
  }

  closeEdit(): void {
    this.editOpen = false;
    this.editModel = undefined;
    this.editErrorMsg = '';
  }

  saveEdit(): void {
    if (!this.editModel?.idvidange) return;

    this.editErrorMsg = '';

    const payload: Partial<VidangeDto> = {
      vehiculeId: this.editModel.vehiculeId,
      dateVidange: this.editModel.dateVidange,
      kilometrageVidange: this.editModel.kilometrageVidange,
      typeHuile: this.editModel.typeHuile,
      cout: this.editModel.cout,
      remarque: this.editModel.remarque,
      prochaineDate: this.editModel.prochaineDate,
      prochainKilometrage: this.editModel.prochainKilometrage,
      statut: this.editModel.statut
    };

    this.vidangeService.update(this.editModel.idvidange, payload).subscribe({
      next: () => {
        this.closeEdit();
        this.vidangeService.refresh();
        this.showSuccess('Vidange modifiée avec succès ✅');
      },
      error: (err) => {
        this.editErrorMsg = err?.error?.message || 'Erreur modification vidange.';
      }
    });
  }

  onAskDelete(v: VidangeDto): void {
    this.deleteErrorMsg = '';
    this.deleting = v;
    this.deleteOpen = true;
  }

  closeDelete(): void {
    this.deleteOpen = false;
    this.deleting = undefined;
    this.deleteErrorMsg = '';
  }

  confirmDelete(): void {
    if (!this.deleting?.idvidange) return;

    this.deleteErrorMsg = '';

    this.vidangeService.delete(this.deleting.idvidange).subscribe({
      next: () => {
        this.closeDelete();
        this.vidangeService.refresh();
        this.showSuccess('Vidange supprimée avec succès ✅');
      },
      error: (err) => {
        this.deleteErrorMsg = err?.error?.message || 'Erreur suppression vidange.';
      }
    });
  }

  exportExcel(): void {
    const data = this.filteredVidanges.map(v => ({
      ID: v.idvidange,
      Immatriculation: v.immatriculationVehicule,
      Marque: v.marqueVehicule,
      Modele: v.modeleVehicule,
      DateVidange: v.dateVidange,
      KilometrageVidange: v.kilometrageVidange,
      TypeHuile: v.typeHuile,
      Cout: v.cout,
      Remarque: v.remarque,
      ProchaineDate: v.prochaineDate,
      ProchainKilometrage: v.prochainKilometrage,
      Statut: v.statut
    }));

    const ws = XLSX.utils.json_to_sheet(data);
    const wb: XLSX.WorkBook = { Sheets: { Vidanges: ws }, SheetNames: ['Vidanges'] };
    XLSX.writeFile(wb, 'vidanges.xlsx');

    this.showSuccess('Export Excel effectué avec succès.');
  }

  exportPDF(): void {
    const rows = this.filteredVidanges.map(v => [
      v.idvidange ?? '',
      v.immatriculationVehicule ?? '',
      `${v.marqueVehicule ?? ''} ${v.modeleVehicule ?? ''}`.trim(),
      v.dateVidange ?? '',
      v.kilometrageVidange ?? '',
      v.typeHuile ?? '',
      v.prochaineDate ?? '',
      v.prochainKilometrage ?? '',
      v.statut ?? ''
    ]);

    const doc = new jsPDF('landscape');

    doc.setFontSize(14);
    doc.text('Liste des vidanges', 14, 15);

    autoTable(doc, {
      startY: 22,
      head: [[
        'ID',
        'Immatriculation',
        'Vehicule',
        'Date vidange',
        'Km vidange',
        'Type huile',
        'Prochaine date',
        'Prochain km',
        'Statut'
      ]],
      body: rows,
      styles: { fontSize: 8 },
      headStyles: { fillColor: [41, 128, 185] }
    });

    doc.save('vidanges.pdf');
    this.showSuccess('Export PDF effectué avec succès.');
  }
}