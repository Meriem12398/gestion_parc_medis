import { Component, HostListener, OnInit, OnDestroy } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router, NavigationEnd, RouterOutlet } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { filter } from 'rxjs/operators';
import { Subscription, interval } from 'rxjs';

import { DemandeService } from '../../auth/services/demande.service';
import { AuthService } from '../../auth/services/auth.service';

@Component({
  selector: 'app-home',
  standalone: true,
  imports: [CommonModule,RouterOutlet,  FormsModule],
  templateUrl: './home.html',
  styleUrls: ['./home.scss']
})
export class HomeComponent implements OnInit, OnDestroy {

  menuOpen = false;
  sidebarOpen = false;
  sidebarCollapsed = false;

  chauffeursOpen = false;
  vehiculesOpen = false;
  demandesOpen = false;
  incidentsOpen = false;
  missionsOpen = false;
  interventionsOpen = false;
  vidangesOpen = false;

  displayName = 'Utilisateur';
  initials = 'U';

  breadcrumbLabel = 'Accueil';
  darkMode = false;

  pendingDemandesCount = 0;

  profileOpen = false;
  changePasswordOpen = false;

  userRole = 'RESPONSABLE';
  profileEmail = '';
  profileFullName = '';
  profileMatricule: number | string = '';

  oldPassword = '';
  newPassword = '';
  confirmPassword = '';
  passwordErrorMsg = '';
  passwordSuccessMsg = '';

  private subs = new Subscription();

  constructor(
    private router: Router,
    private demandeService: DemandeService,
    private authService: AuthService
  ) {}

  ngOnInit(): void {
    const saved = localStorage.getItem('theme');
    if (saved === 'dark') this.enableDark();
    else this.disableDark();

    const rawUser = localStorage.getItem('user');

    if (rawUser) {
      const user = JSON.parse(rawUser);

      const full = `${user.prenom ?? ''} ${user.nom ?? ''}`.trim();
      this.displayName = full || user.email || 'Utilisateur';
      this.initials = this.getInitials(this.displayName);

      this.profileFullName = full || '-';
      this.profileEmail = user.email || '-';
      this.profileMatricule = user.matricule ?? '-';
      this.userRole = user.role || 'RESPONSABLE';
    }

    this.subs.add(
      this.router.events
        .pipe(filter(e => e instanceof NavigationEnd))
        .subscribe(() => {
          const url = this.router.url;

          if (url.includes('/home/chauffeurs')) this.breadcrumbLabel = 'Utilisateurs';
          else if (url.includes('/home/demandeurs')) this.breadcrumbLabel = 'Demandeurs';
          else if (url.includes('/home/vehicules')) this.breadcrumbLabel = 'Véhicules';
          else if (url.includes('/home/demandes/historique')) this.breadcrumbLabel = 'Historique des demandes';
          else if (url.includes('/home/demandes')) this.breadcrumbLabel = 'Demandes';
          else if (url.includes('/home/incidents')) this.breadcrumbLabel = 'Incidents';
          else if (url.includes('/home/interventions')) this.breadcrumbLabel = 'Historique des interventions';
          else if (url.includes('/home/missions/historique')) this.breadcrumbLabel = 'Historique des missions';
          else if (url.includes('/home/missions')) this.breadcrumbLabel = 'Missions';
          else if (url.includes('/home/vidanges/historique')) this.breadcrumbLabel = 'Historique des vidanges';
          else if (url.includes('/home/vidanges')) this.breadcrumbLabel = 'Vidanges';
          else this.breadcrumbLabel = 'Accueil';

          this.loadPendingCount();
        })
    );

    this.loadPendingCount();

    this.subs.add(
      interval(30000).subscribe(() => this.loadPendingCount())
    );
  }

  ngOnDestroy(): void {
    this.subs.unsubscribe();
  }

  private normalizeStatut(s: any): string {
    return (s ?? '').toString().trim().toLowerCase();
  }

  private loadPendingCount(): void {
    this.demandeService.getAll(undefined, undefined).subscribe({
      next: (data: any[]) => {
        const count = (data ?? []).filter(d => {
          const st = this.normalizeStatut(d?.statut);
          return st.includes('attente')
            || st === 'en_attente'
            || st === 'en attente';
        }).length;

        this.pendingDemandesCount = count;
      },
      error: () => {
        this.pendingDemandesCount = 0;
      }
    });
  }

  private extractErrorMessage(err: any): string {
    if (!err) return 'Une erreur est survenue.';

    if (typeof err === 'string') return err;

    if (typeof err?.error === 'string') return err.error;

    if (typeof err?.error?.message === 'string') return err.error.message;

    if (typeof err?.message === 'string') return err.message;

    return 'Une erreur est survenue.';
  }

  goNotifications(e?: Event): void {
    e?.stopPropagation();
    this.router.navigate(['/home/demandes']);
    this.closeMobileSidebar();
  }

  toggleSidebar(): void {
    if (window.innerWidth <= 900) {
      this.sidebarOpen = !this.sidebarOpen;
      return;
    }

    this.sidebarCollapsed = !this.sidebarCollapsed;

    if (this.sidebarCollapsed) {
      this.chauffeursOpen = false;
      this.vehiculesOpen = false;
      this.demandesOpen = false;
      this.incidentsOpen = false;
      this.interventionsOpen = false;
      this.missionsOpen = false;
      this.vidangesOpen = false;
    }
  }

  toggleChauffeurs(e?: Event): void {
    e?.stopPropagation();

    if (this.sidebarCollapsed) {
      this.router.navigate(['/home/chauffeurs']);
      return;
    }

    this.chauffeursOpen = !this.chauffeursOpen;

    if (this.chauffeursOpen) {
      this.vehiculesOpen = false;
      this.demandesOpen = false;
      this.incidentsOpen = false;
      this.interventionsOpen = false;
      this.missionsOpen = false;
      this.vidangesOpen = false;
    }
  }

  toggleVehicules(e?: Event): void {
    e?.stopPropagation();

    if (this.sidebarCollapsed) {
      this.router.navigate(['/home/vehicules']);
      return;
    }

    this.vehiculesOpen = !this.vehiculesOpen;

    if (this.vehiculesOpen) {
      this.chauffeursOpen = false;
      this.demandesOpen = false;
      this.incidentsOpen = false;
      this.interventionsOpen = false;
      this.missionsOpen = false;
      this.vidangesOpen = false;
    }
  }

  toggleDemandes(e?: Event): void {
    e?.stopPropagation();

    if (this.sidebarCollapsed) {
      this.router.navigate(['/home/demandes']);
      return;
    }

    this.demandesOpen = !this.demandesOpen;

    if (this.demandesOpen) {
      this.chauffeursOpen = false;
      this.vehiculesOpen = false;
      this.incidentsOpen = false;
      this.interventionsOpen = false;
      this.missionsOpen = false;
      this.vidangesOpen = false;
    }
  }

  toggleIncidents(e?: Event): void {
    e?.stopPropagation();

    if (this.sidebarCollapsed) {
      this.router.navigate(['/home/incidents']);
      return;
    }

    this.incidentsOpen = !this.incidentsOpen;

    if (this.incidentsOpen) {
      this.chauffeursOpen = false;
      this.vehiculesOpen = false;
      this.demandesOpen = false;
      this.interventionsOpen = false;
      this.missionsOpen = false;
      this.vidangesOpen = false;
    }
  }

  toggleInterventions(e?: Event): void {
    e?.stopPropagation();

    if (this.sidebarCollapsed) {
      this.router.navigate(['/home/interventions']);
      return;
    }

    this.interventionsOpen = !this.interventionsOpen;

    if (this.interventionsOpen) {
      this.chauffeursOpen = false;
      this.vehiculesOpen = false;
      this.demandesOpen = false;
      this.incidentsOpen = false;
      this.missionsOpen = false;
      this.vidangesOpen = false;
    }
  }

  toggleMissions(e?: Event): void {
    e?.stopPropagation();

    if (this.sidebarCollapsed) {
      this.router.navigate(['/home/missions']);
      return;
    }

    this.missionsOpen = !this.missionsOpen;

    if (this.missionsOpen) {
      this.chauffeursOpen = false;
      this.vehiculesOpen = false;
      this.demandesOpen = false;
      this.incidentsOpen = false;
      this.interventionsOpen = false;
      this.vidangesOpen = false;
    }
  }

  toggleVidanges(e?: Event): void {
    e?.stopPropagation();

    if (this.sidebarCollapsed) {
      this.router.navigate(['/home/vidanges']);
      return;
    }

    this.vidangesOpen = !this.vidangesOpen;

    if (this.vidangesOpen) {
      this.chauffeursOpen = false;
      this.vehiculesOpen = false;
      this.demandesOpen = false;
      this.incidentsOpen = false;
      this.interventionsOpen = false;
      this.missionsOpen = false;
    }
  }

  goUsersList(e?: Event): void {
    e?.stopPropagation();
    this.router.navigate(['/home/chauffeurs']);
    this.closeMobileSidebar();
  }

  goDemandeursList(e?: Event): void {
    e?.stopPropagation();
    this.router.navigate(['/home/demandeurs']);
    this.closeMobileSidebar();
  }

  goUsersAdd(e?: Event): void {
    e?.stopPropagation();
    this.router.navigate(['/home/chauffeurs'], { queryParams: { action: 'add' } });
    this.closeMobileSidebar();
  }

  goVehiculesList(e?: Event): void {
    e?.stopPropagation();
    this.router.navigate(['/home/vehicules']);
    this.closeMobileSidebar();
  }

  goVehiculesAdd(e?: Event): void {
    e?.stopPropagation();
    this.router.navigate(['/home/vehicules'], { queryParams: { action: 'add' } });
    this.closeMobileSidebar();
  }

  goDemandesList(e?: Event): void {
    e?.stopPropagation();
    this.router.navigate(['/home/demandes']);
    this.closeMobileSidebar();
  }

  goDemandesHistorique(e?: Event): void {
    e?.stopPropagation();
    this.router.navigate(['/home/demandes/historique']);
    this.closeMobileSidebar();
  }

  goIncidentsList(e?: Event): void {
    e?.stopPropagation();
    this.router.navigate(['/home/incidents']);
    this.closeMobileSidebar();
  }

  goInterventionsList(e?: Event): void {
    e?.stopPropagation();
    this.router.navigate(['/home/interventions']);
    this.closeMobileSidebar();
  }

  goMissionsList(e?: Event): void {
    e?.stopPropagation();
    this.router.navigate(['/home/missions']);
    this.closeMobileSidebar();
  }

  goMissionsHistorique(e?: Event): void {
    e?.stopPropagation();
    this.router.navigate(['/home/missions/historique']);
    this.closeMobileSidebar();
  }

  goVidangesList(e?: Event): void {
    e?.stopPropagation();
    this.router.navigate(['/home/vidanges']);
    this.closeMobileSidebar();
  }

  goVidangesHistorique(e?: Event): void {
    e?.stopPropagation();
    this.router.navigate(['/home/vidanges/historique']);
    this.closeMobileSidebar();
  }

  private closeMobileSidebar(): void {
    if (window.innerWidth <= 900) {
      this.sidebarOpen = false;
    }
  }

  toggleMenu(): void {
    this.menuOpen = !this.menuOpen;
  }

  openProfile(): void {
    this.menuOpen = false;
    this.profileOpen = true;
  }

  closeProfile(): void {
    this.profileOpen = false;
  }

  openChangePassword(): void {
    this.menuOpen = false;
    this.profileOpen = false;
    this.passwordErrorMsg = '';
    this.passwordSuccessMsg = '';
    this.oldPassword = '';
    this.newPassword = '';
    this.confirmPassword = '';
    this.changePasswordOpen = true;
  }

  closeChangePassword(): void {
    this.changePasswordOpen = false;
    this.passwordErrorMsg = '';
    this.passwordSuccessMsg = '';
    this.oldPassword = '';
    this.newPassword = '';
    this.confirmPassword = '';
  }

  goToChangePasswordFromProfile(): void {
    this.closeProfile();
    this.openChangePassword();
  }

  submitChangePassword(): void {
    this.passwordErrorMsg = '';
    this.passwordSuccessMsg = '';

    if (!this.oldPassword.trim()) {
      this.passwordErrorMsg = 'Mot de passe actuel obligatoire.';
      return;
    }

    if (!this.newPassword.trim()) {
      this.passwordErrorMsg = 'Nouveau mot de passe obligatoire.';
      return;
    }

    if (this.newPassword.trim().length < 6) {
      this.passwordErrorMsg = 'Le nouveau mot de passe doit contenir au moins 6 caractères.';
      return;
    }

    if (!this.confirmPassword.trim()) {
      this.passwordErrorMsg = 'Confirmation obligatoire.';
      return;
    }

    if (this.newPassword !== this.confirmPassword) {
      this.passwordErrorMsg = 'La confirmation du mot de passe est incorrecte.';
      return;
    }

    if (this.profileEmail === '-' || !this.profileEmail) {
      this.passwordErrorMsg = 'Email utilisateur introuvable.';
      return;
    }

    this.authService.changePassword(
      this.profileEmail,
      this.oldPassword,
      this.newPassword
    ).subscribe({
      next: () => {
        this.passwordSuccessMsg = 'Mot de passe modifié avec succès ✅';
        this.passwordErrorMsg = '';

        this.oldPassword = '';
        this.newPassword = '';
        this.confirmPassword = '';

        setTimeout(() => {
          this.closeChangePassword();
        }, 2500);
      },
      error: (err: any) => {
        this.passwordSuccessMsg = '';
        this.passwordErrorMsg = this.extractErrorMessage(err);
      }
    });
  }

  @HostListener('document:click')
  onDocClick(): void {
    this.menuOpen = false;

    this.chauffeursOpen = false;
    this.vehiculesOpen = false;
    this.demandesOpen = false;
    this.incidentsOpen = false;
    this.interventionsOpen = false;
    this.missionsOpen = false;
    this.vidangesOpen = false;
  }

  toggleTheme(): void {
    if (this.darkMode) this.disableDark();
    else this.enableDark();
  }

  private enableDark(): void {
    document.body.classList.add('dark-theme');
    localStorage.setItem('theme', 'dark');
    this.darkMode = true;
  }

  private disableDark(): void {
    document.body.classList.remove('dark-theme');
    localStorage.setItem('theme', 'light');
    this.darkMode = false;
  }

  private getInitials(name: string): string {
    const parts = name.split(/\s+/).filter(Boolean);

    const first = parts[0]?.charAt(0) ?? 'U';
    const last = parts.length > 1
      ? (parts[parts.length - 1]?.charAt(0) ?? '')
      : '';

    return (first + last).toUpperCase();
  }

  logout(): void {
    localStorage.clear();
    this.router.navigate(['/login']);
  }

  goResponsableSpace(): void {
    this.menuOpen = false;
    this.router.navigate(['/home']);
  }

  goChauffeurSpace(): void {
    this.menuOpen = false;
    this.router.navigate(['/chauffeur']);
  }

  goDemandeurSpace(): void {
    this.menuOpen = false;
    this.router.navigate(['/demandeur']);
  }
}