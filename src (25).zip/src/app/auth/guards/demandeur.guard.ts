import { CanActivateFn, Router } from '@angular/router';
import { inject } from '@angular/core';

export const demandeurGuard: CanActivateFn = () => {
  const router = inject(Router);
  const userStr = localStorage.getItem('user');

  if (!userStr) {
    router.navigate(['/login']);
    return false;
  }

  const user = JSON.parse(userStr);

  if (user.role !== 'DEMANDEUR' && user.role !== 'RESPONSABLE') {
    router.navigate(['/login']);
    return false;
  }

  return true;
};