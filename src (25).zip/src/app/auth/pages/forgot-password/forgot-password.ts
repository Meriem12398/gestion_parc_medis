import { Component, ChangeDetectorRef } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { AuthService } from '../../services/auth.service';

@Component({
  selector: 'app-forgot-password',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './forgot-password.html',
  styleUrl: './forgot-password.scss'
})
export class ForgotPasswordComponent {
  email = '';
  message = '';
  errorMsg = '';

  constructor(
    private auth: AuthService,
    private cdr: ChangeDetectorRef
  ) {}

  onSubmit(): void {
    this.message = '';
    this.errorMsg = '';

    if (!this.email.trim()) {
      this.errorMsg = 'Adresse e-mail obligatoire.';
      this.cdr.detectChanges();
      return;
    }

    this.auth.forgotPassword(this.email).subscribe({
      next: (res) => {
        console.log('FORGOT SUCCESS', res);
        this.message = 'Si un compte existe, un email a été envoyé.';
        this.errorMsg = '';
        this.cdr.detectChanges();
      },
      error: (err) => {
        console.log('FORGOT ERROR', err);
        this.errorMsg =
          err?.error?.message ||
          err?.error ||
          err?.message ||
          'Erreur.';
        this.message = '';
        this.cdr.detectChanges();
      }
    });
  }
}