import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthService } from '../../services/auth.service';

type Role = 'DEMANDEUR' | 'CHAUFFEUR' | 'RESPONSABLE';

interface LoginResponse {
  token: string;
  role: Role;
  email: string;
  nom?: string;
  prenom?: string;
  matricule?: number;
}

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './login.html',
  styleUrls: ['./login.scss']
})
export class LoginComponent implements OnInit {
  email = '';
  motdepasse = '';
  errorMsg = '';
  showPassword = false;
  forgotOpen = false;

  constructor(private auth: AuthService, private router: Router) {}

  ngOnInit(): void {}

  onSubmit(): void {
    this.errorMsg = '';

    if (!this.email.trim()) {
      this.errorMsg = 'Adresse e-mail obligatoire.';
      return;
    }

    if (!this.motdepasse.trim()) {
      this.errorMsg = 'Mot de passe obligatoire.';
      return;
    }

    this.auth.login(this.email, this.motdepasse).subscribe({
      next: (res: LoginResponse) => {
        if (res.role === 'RESPONSABLE') {
          this.router.navigate(['/home']);
        } else if (res.role === 'CHAUFFEUR') {
          this.router.navigate(['/chauffeur']);
        } else if (res.role === 'DEMANDEUR') {
          this.router.navigate(['/demandeur']);
        } else {
          this.errorMsg = 'Rôle utilisateur inconnu.';
        }
      },
      error: (err: any) => {
        console.error(err);
        this.errorMsg = err?.error?.message || 'Email ou mot de passe incorrect.';
      }
    });
  }

  onInputChange(): void {
    this.errorMsg = '';
  }

  openForgotPassword(): void {
  this.router.navigate(['/forgot-password']);
}

  closeForgotPassword(): void {
    this.forgotOpen = false;
  }
}