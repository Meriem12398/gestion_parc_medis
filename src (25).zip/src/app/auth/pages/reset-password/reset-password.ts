import { Component, OnInit, ChangeDetectorRef } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { AuthService } from '../../services/auth.service';

@Component({
  selector: 'app-reset-password',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './reset-password.html',
  styleUrl: './reset-password.scss' 
})
export class ResetPasswordComponent implements OnInit {

  token = '';
  newPassword = '';
  confirmPassword = '';
  message = '';
  errorMsg = '';

  constructor(
    private route: ActivatedRoute,
    private auth: AuthService,
    private router: Router,
    private cdr: ChangeDetectorRef
  ) {}

  ngOnInit(): void {
    this.route.queryParams.subscribe(params => {
      this.token = params['token'] || '';
      console.log("TOKEN:", this.token);
    });
  }

 onSubmit(): void {
  this.message = '';
  this.errorMsg = '';

  if (!this.newPassword.trim()) {
    this.errorMsg = 'Mot de passe obligatoire';
    this.cdr.detectChanges();
    return;
  }

  if (this.newPassword !== this.confirmPassword) {
    this.errorMsg = 'Les mots de passe ne correspondent pas';
    this.cdr.detectChanges();
    return;
  }

  this.auth.resetPassword(this.token, this.newPassword).subscribe({
    next: () => {
      this.message = 'Mot de passe changé avec succès';
      this.errorMsg = '';
      this.cdr.detectChanges();
      setTimeout(() => this.router.navigate(['/login']), 1500);
    },
    error: (err) => {
      this.errorMsg = err?.error || 'Erreur';
      this.message = '';
      this.cdr.detectChanges();
    }
  });
}
}