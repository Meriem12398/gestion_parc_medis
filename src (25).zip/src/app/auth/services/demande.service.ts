import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Demande } from '../../models/demande.model';

@Injectable({ providedIn: 'root' })
export class DemandeService {

  private baseUrl = 'http://localhost:8080/api/demandes';
  private missionsUrl = 'http://localhost:8080/api/missions';

  constructor(private http: HttpClient) {}

  getAll(statut?: string, priorite?: string): Observable<Demande[]> {
    let params = new HttpParams();
    if (statut) params = params.set('statut', statut);
    if (priorite) params = params.set('priorite', priorite);
    return this.http.get<Demande[]>(this.baseUrl, { params });
  }

  getMesDemandes(): Observable<Demande[]> {
    return this.http.get<Demande[]>(`${this.baseUrl}/mes-demandes`);
  }

  create(payload: any) {
    return this.http.post<any>(`${this.baseUrl}`, payload);
  }

  modifierDemande(id: number, payload: {
    typeDemande: string;
    priorite: string;
    description: string;
    dateSouhaite: string;
  }) {
    return this.http.put<any>(`${this.baseUrl}/${id}/demandeur`, payload);
  }

  supprimerDemande(id: number) {
    return this.http.delete(`${this.baseUrl}/${id}/demandeur`, {
      responseType: 'text'
    });
  }

  updateStatut(id: number, statut: string, motif?: string): Observable<void> {
    return this.http.put<void>(`${this.baseUrl}/${id}/statut`, {
      statut,
      motif: motif ?? null
    });
  }

  affecter(id: number, idvehicule: number, chauffeurMatricule: number, dateDebut: string): Observable<void> {
    return this.http.post<void>(`${this.baseUrl}/${id}/affecter`, {
      idvehicule,
      chauffeurMatricule,
      dateDebut
    });
  }

  affecterGroupee(payload: {
    vehiculeId: number;
    chauffeurMatricule: number;
    dateDebut: string;
    demandeIds: number[];
  }): Observable<any> {
    return this.http.post(`${this.missionsUrl}/groupee`, payload);
  }
}