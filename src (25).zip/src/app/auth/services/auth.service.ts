import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { tap } from 'rxjs/operators';

@Injectable({ providedIn: 'root' })
export class AuthService {
  private api = 'http://localhost:8080/api/auth';

  constructor(private http: HttpClient) {}

  login(email: string, motdepasse: string) {
    return this.http.post<any>(`${this.api}/login`, { email, motdepasse }).pipe(
      tap(res => {
        localStorage.setItem('token', res.token);
        localStorage.setItem('user', JSON.stringify(res));
      })
    );
  }

  changePassword(email: string, ancienMotDePasse: string, nouveauMotDePasse: string) {
    return this.http.put(`${this.api}/change-password`, {
      email,
      ancienMotDePasse,
      nouveauMotDePasse
    });
  }

  getToken() {
    return localStorage.getItem('token');
  }

  getUser() {
    const user = localStorage.getItem('user');
    return user ? JSON.parse(user) : null;
  }

  getRole() {
    const user = this.getUser();
    return user?.role || null;
  }

  logout() {
    localStorage.clear();
  }

forgotPassword(email: string) {
  return this.http.post(`${this.api}/forgot-password`, { email }, {
    responseType: 'text'
  });
}

resetPassword(token: string, newPassword: string) {
  return this.http.post(`${this.api}/reset-password`, {
    token,
    newPassword
  }, {
    responseType: 'text'
  });
}
}