import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

export interface MissionDto {
  idmission: number;
  dateDebut: string;
  dateFin: string | null;
  statutMission: string;

  iddemande: number;

  idvehicule: number;
  immatriculationVehicule: string | null;

  chauffeurMatricule: number | null;
  chauffeurNom: string | null;
  chauffeurPrenom: string | null;

  motifAnnulation?: string | null;
}

export interface DemandeMiniDto {
  iddemande: number;
  typeDemande: string;
  statut: string;
  priorite: string;
  description: string;
}

export interface MissionDetailsDto {
  idmission: number;
  dateDebut: string;
  dateFin: string | null;
  statutMission: string;

  idvehicule: number;
  immatriculationVehicule: string | null;

  chauffeurMatricule: number | null;
  chauffeurNom: string | null;
  chauffeurPrenom: string | null;

  demandes: DemandeMiniDto[];
}

@Injectable({
  providedIn: 'root'
})
export class MissionService {
  private baseUrl = 'http://localhost:8080/api/missions';
  private incidentUrl = 'http://localhost:8080/api/incidents';

  constructor(private http: HttpClient) {}

  getAll(): Observable<MissionDto[]> {
    return this.http.get<MissionDto[]>(this.baseUrl);
  }

  getMesMissions(): Observable<MissionDto[]> {
    return this.http.get<MissionDto[]>(`${this.baseUrl}/chauffeur`);
  }

  getDetails(id: number): Observable<MissionDetailsDto> {
    return this.http.get<MissionDetailsDto>(`${this.baseUrl}/${id}/details`);
  }

  terminer(id: number): Observable<MissionDto> {
    return this.http.put<MissionDto>(`${this.baseUrl}/${id}/terminer`, {});
  }

  annuler(id: number, motif: string): Observable<MissionDto> {
    return this.http.put<MissionDto>(`${this.baseUrl}/${id}/annuler`, { motif });
  }

  creerIncident(payload: {
    idmission: number;
    typeIncident: string;
    description: string;
    latitude: number | null;
    longitude: number | null;
    adresse: string;
  }): Observable<any> {
    return this.http.post(this.incidentUrl, payload);
  }
}