import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, Subject } from 'rxjs';

export interface UtilisateurDto {
  matricule: any;
  nom: string;
  prenom: string;
  email: string;
  telephone: string;
  departement: string;
  typePermis: string;
  disponibilite: any;
  role: string;
}

@Injectable({ providedIn: 'root' })
export class UtilisateurService {
  private apiUrl = 'http://localhost:8080/api/utilisateurs';

  private refresh$ = new Subject<void>();

  constructor(private http: HttpClient) {}

  refresh(): void {
    this.refresh$.next();
  }

  // ✅ GET chauffeurs
  getChauffeurs(): Observable<UtilisateurDto[]> {
    return this.http.get<UtilisateurDto[]>(`${this.apiUrl}/chauffeurs`);
  }

  // ✅ GET demandeurs (NEW)
  getDemandeurs(): Observable<UtilisateurDto[]> {
    return this.http.get<UtilisateurDto[]>(`${this.apiUrl}/demandeurs`);
  }

  // ✅ POST utilisateur (chauffeur/demandeur)
  createUtilisateur(payload: any): Observable<any> {
    return this.http.post(`${this.apiUrl}`, payload);
  }

  // ✅ optional: keep old name if you want
  createChauffeur(payload: any): Observable<any> {
    return this.createUtilisateur(payload);
  }

  // ✅ PUT
  update(matricule: any, body: any): Observable<any> {
    return this.http.put(`${this.apiUrl}/${matricule}`, body);
  }

  // ✅ DELETE
  delete(matricule: any): Observable<any> {
    return this.http.delete(`${this.apiUrl}/${matricule}`);
  }



  //rest mot de passe utilisateur
 resetPassword(matricule: number, newPassword: string) {
  return this.http.put(
    `http://localhost:8080/api/utilisateurs/${matricule}/reset-password`,
    { newPassword },
    { responseType: 'text' }
  );
} 
}