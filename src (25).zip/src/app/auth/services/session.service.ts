import { Injectable } from '@angular/core';

type Role = 'DEMANDEUR' | 'CHAUFFEUR' | 'RESPONSABLE';

export interface SessionUser {
  email: string;
  role: Role;
  nom?: string;
  prenom?: string;
  matricule?: number;
}

@Injectable({ providedIn: 'root' })
export class SessionService {
  getUser(): SessionUser | null {
    const userStr = localStorage.getItem('user');
    if (!userStr) return null;

    try {
      return JSON.parse(userStr) as SessionUser;
    } catch {
      return null;
    }
  }

  getDisplayName(): string {
    const u = this.getUser();
    if (!u) return 'Self-Service';

    const prenom = (u.prenom ?? '').trim();
    const nom = (u.nom ?? '').trim();

    if (prenom || nom) return `${prenom} ${nom}`.trim();
    return u.email; 
  }

  getInitials(): string {
    const u = this.getUser();
    if (!u) return 'SS';

    const prenom = (u.prenom ?? '').trim();
    const nom = (u.nom ?? '').trim();

    const a = prenom ? prenom[0].toUpperCase() : '';
    const b = nom ? nom[0].toUpperCase() : '';

    const initials = (a + b).trim();
    if (initials) return initials;


    return (u.email ?? 'SS').slice(0, 2).toUpperCase();
  }
}