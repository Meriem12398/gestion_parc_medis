import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

export interface IncidentDto {
  idincident: number;
  dateIncident: string;
  typeIncident: string;
  description: string;
  idmission: number;
  latitude: number | null;
  longitude: number | null;
  adresse: string | null;
}

@Injectable({
  providedIn: 'root'
})
export class IncidentService {
  private baseUrl = 'http://localhost:8080/api/incidents';

  constructor(private http: HttpClient) {}

  getAll(): Observable<IncidentDto[]> {
    return this.http.get<IncidentDto[]>(this.baseUrl);
  }

  create(payload: {
    idmission: number;
    typeIncident: string;
    description: string;
    latitude: number | null;
    longitude: number | null;
    adresse: string;
  }): Observable<IncidentDto> {
    return this.http.post<IncidentDto>(this.baseUrl, payload);
  }
}