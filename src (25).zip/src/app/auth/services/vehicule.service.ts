import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, Subject } from 'rxjs';

export interface VehiculeDto {
  idvehicule?: number;
  immatriculation: string;
  marque: string;
  modele: string;
  kilometrage: number;
  etat: string;
  typeCarburant?: string;
  dateAchat?: string;
}

@Injectable({ providedIn: 'root' })
export class VehiculeService {
  private apiUrl = 'http://localhost:8080/api/vehicules';
  private refresh$ = new Subject<void>();

  constructor(private http: HttpClient) {}

  refresh(): void { this.refresh$.next(); }
  onRefresh(): Observable<void> { return this.refresh$.asObservable(); }

  getAll(): Observable<VehiculeDto[]> {
    return this.http.get<VehiculeDto[]>(this.apiUrl);
  }

  create(payload: Partial<VehiculeDto>): Observable<any> {
    return this.http.post(this.apiUrl, payload);
  }

  update(idvehicule: number, payload: Partial<VehiculeDto>): Observable<any> {
    return this.http.put(`${this.apiUrl}/${idvehicule}`, payload);
  }

  delete(idvehicule: number): Observable<any> {
    return this.http.delete(`${this.apiUrl}/${idvehicule}`);
  }
}