import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

export interface InterventionDto {
  idintervention: number;
  dateIntervention: string;
  typeIntervention: string;
  description: string;
  cout: number | null;
  idincident: number;
}

export interface InterventionHistoriqueDto {
  idintervention: number;
  dateIntervention: string;
  typeIntervention: string;
  description: string;
  cout: number | null;
  idincident: number;

  idmission: number | null;
  idvehicule: number | null;
  immatriculationVehicule: string | null;
  marqueVehicule: string | null;
  modeleVehicule: string | null;
}

@Injectable({
  providedIn: 'root'
})
export class InterventionService {
  private baseUrl = 'http://localhost:8080/api/interventions';

  constructor(private http: HttpClient) {}

  getAll(): Observable<InterventionDto[]> {
    return this.http.get<InterventionDto[]>(this.baseUrl);
  }

  getHistorique(): Observable<InterventionHistoriqueDto[]> {
    return this.http.get<InterventionHistoriqueDto[]>(`${this.baseUrl}/historique`);
  }

  getByIncident(idincident: number): Observable<InterventionDto[]> {
    return this.http.get<InterventionDto[]>(`${this.baseUrl}/incident/${idincident}`);
  }

  hasIntervention(idincident: number): Observable<{ exists: boolean }> {
    return this.http.get<{ exists: boolean }>(`${this.baseUrl}/incident/${idincident}/exists`);
  }

  create(payload: {
    typeIntervention: string;
    description: string;
    cout: number | null;
    idincident: number;
  }): Observable<InterventionDto> {
    return this.http.post<InterventionDto>(this.baseUrl, payload);
  }
}