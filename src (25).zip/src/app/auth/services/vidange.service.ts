import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, Subject } from 'rxjs';

export interface VidangeDto {
  idvidange?: number;
  vehiculeId: number;
  immatriculationVehicule?: string;
  marqueVehicule?: string;
  modeleVehicule?: string;

  dateVidange?: string | null;
  kilometrageVidange?: number | null;
  typeHuile?: string | null;
  cout?: number | null;
  remarque?: string | null;

  prochaineDate?: string | null;
  prochainKilometrage?: number | null;

  statut: string;
}

@Injectable({ providedIn: 'root' })
export class VidangeService {
  private apiUrl = 'http://localhost:8080/api/vidanges';
  private refresh$ = new Subject<void>();

  constructor(private http: HttpClient) {}

  refresh(): void {
    this.refresh$.next();
  }

  onRefresh(): Observable<void> {
    return this.refresh$.asObservable();
  }

  getAll(): Observable<VidangeDto[]> {
    return this.http.get<VidangeDto[]>(this.apiUrl);
  }

  getByVehicule(vehiculeId: number): Observable<VidangeDto[]> {
    return this.http.get<VidangeDto[]>(`${this.apiUrl}/vehicule/${vehiculeId}`);
  }

  create(payload: Partial<VidangeDto>): Observable<any> {
    return this.http.post(this.apiUrl, payload);
  }

  update(idvidange: number, payload: Partial<VidangeDto>): Observable<any> {
    return this.http.put(`${this.apiUrl}/${idvidange}`, payload);
  }

  delete(idvidange: number): Observable<any> {
    return this.http.delete(`${this.apiUrl}/${idvidange}`);
  }
}