import { Routes } from '@angular/router';
import { LoginComponent } from './auth/pages/login/login';

import { authGuard } from './auth/guards/auth.guard';
import { responsableGuard } from './auth/guards/responsable.guard';
import { chauffeurGuard } from './auth/guards/chauffeur.guard';
import { demandeurGuard } from './auth/guards/demandeur.guard';

import { ForgotPasswordComponent } from './auth/pages/forgot-password/forgot-password';
import { ResetPasswordComponent } from './auth/pages/reset-password/reset-password';

export const routes: Routes = [

  /* ================= LOGIN ================= */
  { path: 'login', component: LoginComponent },
  { path: 'forgot-password', component: ForgotPasswordComponent },
  { path: 'reset-password', component: ResetPasswordComponent },
  /* ================= RESPONSABLE ================= */
  {
    path: 'home',
    canActivate: [authGuard, responsableGuard],
    loadComponent: () =>
      import('./admin/home/home').then(m => m.HomeComponent),

    children: [
      {
        path: 'chauffeurs',
        loadComponent: () =>
          import('./admin/utilisateurs/utilisateurs')
            .then(m => m.UtilisateursComponent),
      },
      {
        path: 'demandeurs',
        loadComponent: () =>
          import('./admin/demandeurs-list/demandeurs-list')
            .then(m => m.DemandeursComponent),
      },
      {
        path: 'vehicules',
        loadComponent: () =>
          import('./admin/vehicules/vehicules')
            .then(m => m.VehiculesComponent),
      },
      {
        path: 'interventions',
        loadComponent: () =>
          import('./admin/pages/interventions/interventions')
            .then(m => m.InterventionsComponent),
      },
      {
        path: 'demandes',
        loadComponent: () =>
          import('./admin/pages/demandes/demandes')
            .then(m => m.DemandesComponent),
      },
      {
        path: 'demandes/historique',
        loadComponent: () =>
          import('./admin/pages/demandes/historique-demandes/historique-demandes')
            .then(m => m.HistoriqueDemandesComponent),
      },
      {
        path: 'missions',
        loadComponent: () =>
          import('./admin/pages/missions/missions')
            .then(m => m.MissionsComponent),
      },
      {
        path: 'missions/historique',
        loadComponent: () =>
          import('./admin/pages/missions/historique-missions/historique-missions')
            .then(m => m.HistoriqueMissionsComponent),
      },
      {
        path: 'vidanges',
        loadComponent: () =>
          import('./admin/pages/vidanges/vidanges')
            .then(m => m.VidangesComponent),
      },
      {
        path: 'vidanges/historique',
        loadComponent: () =>
          import('./admin/pages/vidanges/historique-vidanges/historique-vidanges')
            .then(m => m.HistoriqueVidangesComponent),
      },
      {
        path: 'incidents',
        loadComponent: () =>
          import('./admin/pages/incidents/incidents')
            .then(m => m.IncidentsComponent),
      },
      { path: '', pathMatch: 'full', redirectTo: 'chauffeurs' }
    ]
  },

  /* ================= CHAUFFEUR ================= */
  {
    path: 'chauffeur',
    canActivate: [authGuard, chauffeurGuard],
    loadComponent: () =>
      import('./chauffeur/home/chauffeur-home')
        .then(m => m.ChauffeurHomeComponent),

    children: [
      {
        path: 'missions',
        loadComponent: () =>
          import('./chauffeur/home/pages/chauffeur-missions/chauffeur-missions')
            .then(m => m.ChauffeurMissionsComponent),
      },
      {
        path: 'missions/historique',
        loadComponent: () =>
          import('./chauffeur/home/pages/chauffeur-historique/chauffeur-historique')
            .then(m => m.ChauffeurHistoriqueComponent),
      },
      {
        path: 'incidents',
        loadComponent: () =>
          import('./chauffeur/home/pages/chauffeur-incidents/chauffeur-incidents')
            .then(m => m.ChauffeurIncidentsComponent),
      },
      { path: '', pathMatch: 'full', redirectTo: 'missions' }
    ]
  },

  /* ================= DEMANDEUR ================= */
  {
    path: 'demandeur',
    canActivate: [authGuard, demandeurGuard],
    loadComponent: () =>
      import('./demandeur/demandeur-home/demandeur-home')
        .then(m => m.DemandeurHomeComponent),
    children: [
      {
        path: 'mes-demandes',
        loadComponent: () =>
          import('./demandeur/pages/mes-demandes/mes-demandes')
            .then(m => m.MesDemandesComponent),
      },
      {
        path: 'nouvelle-demande',
        loadComponent: () =>
          import('./demandeur/pages/mes-demandes/nouvelle-demande/nouvelle-demande')
            .then(m => m.NouvelleDemandeComponent),
      },
      {
        path: 'historique',
        loadComponent: () =>
          import('./demandeur/pages/historique-demandes/historique-demandes')
            .then(m => m.HistoriqueDemandesComponent),
      },
      { path: '', pathMatch: 'full', redirectTo: 'mes-demandes' }
    ]
  },

  /* ================= DEFAULT ================= */
  { path: '', redirectTo: 'login', pathMatch: 'full' },
  { path: '**', redirectTo: 'login' }

];