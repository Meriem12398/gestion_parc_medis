import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import {
  MissionDto,
  MissionDetailsDto,
  MissionService
} from '../../../../auth/services/mission.service';

type StatutMissionFilter = 'ALL' | 'EN_COURS' | 'TERMINEE' | 'ANNULEE';
type SortBy = 'RECENT' | 'ANCIEN';
type QuickFilter = 'NONE' | 'EN_COURS' | 'TERMINEE' | 'TODAY';

@Component({
  selector: 'app-chauffeur-missions',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './chauffeur-missions.html',
  styleUrls: ['./chauffeur-missions.scss']
})
export class ChauffeurMissionsComponent implements OnInit {
  missions: MissionDto[] = [];
  loading = false;
  pageErrorMsg = '';
  successMsg = '';

  searchTerm = '';
  statutFilter: StatutMissionFilter = 'ALL';
  sortBy: SortBy = 'RECENT';
  quickFilter: QuickFilter = 'NONE';

  page = 1;
  pageSize = 8;
  pageSizes = [5, 8, 10, 15, 20];

  sortColumnName: string = '';
  sortDirection: 'asc' | 'desc' = 'asc';

  detailsOpen = false;
  detailsLoading = false;
  detailsErrorMsg = '';
  selectedMission: MissionDetailsDto | null = null;

  showFinishModal = false;
  missionToFinish: MissionDto | null = null;

  showCancelModal = false;
  missionToCancel: MissionDto | null = null;
  motifAnnulation = '';
  cancelErrorMsg = '';

  stats = {
    total: 0,
    enCours: 0,
    terminees: 0,
    today: 0
  };

  constructor(
    private missionService: MissionService,
    private router: Router
  ) {}

  ngOnInit(): void {
    this.load();
  }

  sortColumn(column: string): void {
    if (this.sortColumnName === column) {
      this.sortDirection = this.sortDirection === 'asc' ? 'desc' : 'asc';
    } else {
      this.sortColumnName = column;
      this.sortDirection = 'asc';
    }

    this.page = 1;
  }

  private normalize(v: unknown): string {
    return (v ?? '').toString().trim().toLowerCase();
  }

  private isToday(value: string | null): boolean {
    if (!value) return false;
    const d = new Date(value);
    const now = new Date();

    return d.getFullYear() === now.getFullYear()
      && d.getMonth() === now.getMonth()
      && d.getDate() === now.getDate();
  }

  private isHistoriqueStatus(statut: string | null | undefined): boolean {
    const value = (statut || '').trim().toUpperCase();
    return ['TERMINEE', 'TERMINE', 'ANNULEE', 'ANNULE'].includes(value);
  }

  private isActiveStatus(statut: string | null | undefined): boolean {
    return !this.isHistoriqueStatus(statut);
  }

  private computeStats(list: MissionDto[]): void {
    this.stats.total = list.length;
    this.stats.enCours = list.filter(m => this.normalize(m.statutMission) === 'en_cours').length;
    this.stats.terminees = list.filter(m => this.normalize(m.statutMission) === 'terminee').length;
    this.stats.today = list.filter(m => this.isToday(m.dateDebut)).length;
  }

  private showSuccess(msg: string): void {
    this.successMsg = msg;
    this.pageErrorMsg = '';

    setTimeout(() => {
      this.successMsg = '';
    }, 3000);
  }

  private showError(msg: string): void {
    this.pageErrorMsg = msg;
    this.successMsg = '';
  }

  load(): void {
    this.loading = true;
    this.pageErrorMsg = '';

    this.missionService.getMesMissions().subscribe({
      next: (data: MissionDto[]) => {
        this.missions = (data || []).filter((mission: MissionDto) =>
          this.isActiveStatus(mission.statutMission)
        );

        this.computeStats(this.missions);
        this.loading = false;
        this.goToPage(this.page);
      },
      error: (err: unknown) => {
        console.error(err);
        this.showError('Erreur lors du chargement des missions');
        this.loading = false;
      }
    });
  }

  setQuickFilter(q: QuickFilter): void {
    this.quickFilter = this.quickFilter === q ? 'NONE' : q;
    this.page = 1;
  }

  onFiltersChange(): void {
    this.page = 1;
  }

  private matchStatut(m: MissionDto): boolean {
    if (this.statutFilter === 'ALL') return true;
    return this.normalize(m.statutMission) === this.normalize(this.statutFilter);
  }

  private applyQuickFilter(m: MissionDto): boolean {
    switch (this.quickFilter) {
      case 'EN_COURS':
        return this.normalize(m.statutMission) === 'en_cours';
      case 'TERMINEE':
        return this.normalize(m.statutMission) === 'terminee';
      case 'TODAY':
        return this.isToday(m.dateDebut);
      default:
        return true;
    }
  }

  private getSortableValue(m: MissionDto, column: string): any {
    switch (column) {
      case 'idmission':
        return Number(m.idmission ?? 0);
      case 'dateDebut':
        return new Date(m.dateDebut || 0).getTime();
      case 'dateFin':
        return new Date(m.dateFin || 0).getTime();
      case 'statutMission':
        return this.normalize(m.statutMission);
      case 'immatriculationVehicule':
        return this.normalize(m.immatriculationVehicule);
      case 'iddemande':
        return Number(m.iddemande ?? 0);
      default:
        return this.normalize((m as any)[column]);
    }
  }

  private sortList(list: MissionDto[]): MissionDto[] {
    const arr = [...list];

    if (this.sortColumnName) {
      arr.sort((a, b) => {
        const v1 = this.getSortableValue(a, this.sortColumnName);
        const v2 = this.getSortableValue(b, this.sortColumnName);

        if (v1 < v2) return this.sortDirection === 'asc' ? -1 : 1;
        if (v1 > v2) return this.sortDirection === 'asc' ? 1 : -1;
        return 0;
      });

      return arr;
    }

    arr.sort((a, b) => {
      const da = new Date(a.dateDebut || 0).getTime();
      const db = new Date(b.dateDebut || 0).getTime();

      switch (this.sortBy) {
        case 'ANCIEN':
          return da - db;
        case 'RECENT':
        default:
          return db - da;
      }
    });

    return arr;
  }

  get filteredMissions(): MissionDto[] {
    const q = this.normalize(this.searchTerm);

    const base = (this.missions || []).filter(m => {
      const fullText = this.normalize(
        `${m.idmission} ${m.statutMission} ${m.idvehicule} ${m.iddemande} ${m.immatriculationVehicule ?? ''}`
      );

      const matchSearch = !q || fullText.includes(q);
      const matchStatut = this.matchStatut(m);
      const matchQuick = this.applyQuickFilter(m);

      return matchSearch && matchStatut && matchQuick;
    });

    return this.sortList(base);
  }

  get totalItems(): number {
    return this.filteredMissions.length;
  }

  get totalPages(): number {
    return Math.max(1, Math.ceil(this.totalItems / this.pageSize));
  }

  get pagedMissions(): MissionDto[] {
    const start = (this.page - 1) * this.pageSize;
    return this.filteredMissions.slice(start, start + this.pageSize);
  }

  goToPage(p: number): void {
    if (p < 1) p = 1;
    if (p > this.totalPages) p = this.totalPages;
    this.page = p;
  }

  nextPage(): void {
    this.goToPage(this.page + 1);
  }

  prevPage(): void {
    this.goToPage(this.page - 1);
  }

  onPageSizeChange(): void {
    this.page = 1;
  }

  openDetails(m: MissionDto): void {
    this.detailsOpen = true;
    this.detailsLoading = true;
    this.detailsErrorMsg = '';
    this.selectedMission = null;

    this.missionService.getDetails(m.idmission).subscribe({
      next: (data: MissionDetailsDto) => {
        this.selectedMission = data;
        this.detailsLoading = false;
      },
      error: (err: unknown) => {
        console.error(err);
        this.detailsErrorMsg = 'Erreur lors du chargement des détails';
        this.detailsLoading = false;
      }
    });
  }

  closeDetails(): void {
    this.detailsOpen = false;
    this.detailsLoading = false;
    this.detailsErrorMsg = '';
    this.selectedMission = null;
  }

  canUpdate(m: MissionDto): boolean {
    const st = this.normalize(m.statutMission);
    return st !== 'terminee' && st !== 'annulee';
  }

  openFinishModal(m: MissionDto): void {
    this.missionToFinish = m;
    this.showFinishModal = true;
  }

  closeFinishModal(): void {
    this.showFinishModal = false;
    this.missionToFinish = null;
  }

  confirmFinishMission(): void {
    if (!this.missionToFinish) return;

    this.missionService.terminer(this.missionToFinish.idmission).subscribe({
      next: () => {
        this.closeFinishModal();
        this.showSuccess('Mission terminée avec succès');
        this.load();
      },
      error: (err: unknown) => {
        console.error(err);
        this.closeFinishModal();
        this.showError('Erreur lors de la terminaison de la mission');
      }
    });
  }

  openCancelModal(m: MissionDto): void {
    this.missionToCancel = m;
    this.motifAnnulation = '';
    this.cancelErrorMsg = '';
    this.showCancelModal = true;
  }

  closeCancelModal(): void {
    this.showCancelModal = false;
    this.missionToCancel = null;
    this.motifAnnulation = '';
    this.cancelErrorMsg = '';
  }

  confirmCancelMission(): void {
    if (!this.missionToCancel) return;

    const motif = 'Annulation depuis interface chauffeur';

    this.cancelErrorMsg = '';

    this.missionService.annuler(this.missionToCancel.idmission, motif).subscribe({
      next: () => {
        this.closeCancelModal();
        this.showSuccess('Mission annulée avec succès');
        this.load();
      },
      error: (err: unknown) => {
        console.error(err);
        this.showError('Erreur lors de l’annulation de la mission');
      }
    });
  }

  goToIncident(m: MissionDto): void {
    this.router.navigate(['/chauffeur/incidents'], {
      queryParams: { missionId: m.idmission }
    });
  }
}