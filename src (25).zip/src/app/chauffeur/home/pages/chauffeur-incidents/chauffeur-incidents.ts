import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { MissionService } from '../../../../auth/services/mission.service';

@Component({
  selector: 'app-chauffeur-incidents',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './chauffeur-incidents.html',
  styleUrls: ['./chauffeur-incidents.scss']
})
export class ChauffeurIncidentsComponent implements OnInit {
  incident = {
    idmission: null as number | null,
    typeIncident: '',
    description: '',
    latitude: null as number | null,
    longitude: null as number | null,
    adresse: ''
  };

  successMsg = '';
  errorMsg = '';
  localisationLoading = false;

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private missionService: MissionService
  ) {}

  ngOnInit(): void {
    const missionId = this.route.snapshot.queryParamMap.get('missionId');

    if (missionId) {
      this.incident.idmission = Number(missionId);
    }
  }

  private showSuccess(msg: string): void {
    this.successMsg = msg;
    this.errorMsg = '';

    setTimeout(() => {
      this.successMsg = '';
    }, 4000);
  }

  private showError(msg: string): void {
    this.errorMsg = msg;
    this.successMsg = '';

    setTimeout(() => {
      this.errorMsg = '';
    }, 5000);
  }

  getCurrentLocation(): void {
    this.successMsg = '';
    this.errorMsg = '';

    if (!navigator.geolocation) {
      this.showError("La géolocalisation n’est pas supportée par ce navigateur.");
      return;
    }

    this.localisationLoading = true;

    navigator.geolocation.getCurrentPosition(
      (position) => {
        this.incident.latitude = position.coords.latitude;
        this.incident.longitude = position.coords.longitude;

        fetch(
          `https://nominatim.openstreetmap.org/reverse?format=json&lat=${this.incident.latitude}&lon=${this.incident.longitude}`
        )
          .then((res) => res.json())
          .then((data) => {
            this.incident.adresse = data.display_name || '';
            this.localisationLoading = false;
            this.showSuccess('Position récupérée avec succès.');
          })
          .catch((err) => {
            console.error('Erreur reverse geocoding : ', err);
            this.localisationLoading = false;
            this.showSuccess('Position récupérée, mais adresse non trouvée.');
          });
      },
      (error) => {
        console.error('Erreur géolocalisation : ', error);
        this.localisationLoading = false;
        this.showError('Impossible de récupérer votre position.');
      },
      {
        enableHighAccuracy: true,
        timeout: 10000,
        maximumAge: 0
      }
    );
  }

  submit(): void {
    this.successMsg = '';
    this.errorMsg = '';

    if (!this.incident.idmission) {
      this.showError('Mission obligatoire.');
      return;
    }

    if (!this.incident.typeIncident.trim()) {
      this.showError('Type incident obligatoire.');
      return;
    }

    if (!this.incident.description.trim()) {
      this.showError('Description obligatoire.');
      return;
    }

    const data = {
      idmission: this.incident.idmission,
      typeIncident: this.incident.typeIncident,
      description: this.incident.description,
      latitude: this.incident.latitude,
      longitude: this.incident.longitude,
      adresse: this.incident.adresse
    };

    console.log('DATA ENVOYEE = ', data);

    this.missionService.creerIncident(data).subscribe({
      next: () => {
        const missionId = this.incident.idmission;

        this.showSuccess(`Incident enregistré avec succès pour la mission #${missionId}.`);

        this.incident = {
          idmission: missionId,
          typeIncident: '',
          description: '',
          latitude: null,
          longitude: null,
          adresse: ''
        };
      },
      error: (err: any) => {
        console.error(err);

        this.showError(
          err?.error?.message ||
          err?.error ||
          `Erreur ${err?.status || ''} lors de l’enregistrement de l’incident.`
        );
      }
    });
  }

  retourMissions(): void {
    this.router.navigate(['/chauffeur/missions']);
  }
}