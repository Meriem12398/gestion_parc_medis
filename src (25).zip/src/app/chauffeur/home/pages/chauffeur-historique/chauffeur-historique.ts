import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { MissionDto, MissionService } from '../../../../auth/services/mission.service';

import * as XLSX from 'xlsx';

import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';

@Component({
  selector: 'app-chauffeur-historique',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './chauffeur-historique.html',
  styleUrls: ['./chauffeur-historique.scss']
})
export class ChauffeurHistoriqueComponent implements OnInit {

  historiques: MissionDto[] = [];
  filteredHistoriques: MissionDto[] = [];
  paginatedHistoriques: MissionDto[] = [];

  loading = false;
  errorMessage = '';

  searchTerm = '';
  sortDirection: 'desc' | 'asc' = 'desc';

  currentPage = 1;
  pageSize = 8;
  totalPages = 1;

  total = 0;
  terminees = 0;
  annulees = 0;

  constructor(private missionService: MissionService) {}

  ngOnInit(): void {
    this.loadHistorique();
  }

  loadHistorique(): void {
    this.loading = true;
    this.errorMessage = '';

    this.missionService.getMesMissions().subscribe({
      next: (data: MissionDto[]) => {

        this.historiques = (data || []).filter(m =>
          this.isHistoriqueStatus(m.statutMission)
        );

        this.computeStats();
        this.applyFilters();
        this.loading = false;
      },
      error: (err) => {
        console.error(err);
        this.errorMessage = 'Erreur lors du chargement de l’historique.';
        this.loading = false;
      }
    });
  }

  refresh(): void {
    this.loadHistorique();
  }

  private isHistoriqueStatus(statut: string | null | undefined): boolean {
    const value = (statut || '').trim().toUpperCase();
    return ['TERMINEE', 'TERMINE', 'ANNULEE', 'ANNULE'].includes(value);
  }

  computeStats(): void {
    this.total = this.historiques.length;
    this.terminees = this.historiques.filter(m =>
      (m.statutMission || '').toUpperCase().includes('TERMINE')
    ).length;

    this.annulees = this.historiques.filter(m =>
      (m.statutMission || '').toUpperCase().includes('ANNULE')
    ).length;
  }

  applyFilters(): void {
    const term = this.searchTerm.trim().toLowerCase();

    let data = [...this.historiques];

    if (term) {
      data = data.filter(m =>
        String(m.idmission).includes(term) ||
        String(m.iddemande).includes(term) ||
        (m.immatriculationVehicule || '').toLowerCase().includes(term) ||
        (m.statutMission || '').toLowerCase().includes(term) ||
        (m.motifAnnulation || '').toLowerCase().includes(term)
      );
    }

    data.sort((a, b) => {
      const dateA = new Date(a.dateDebut).getTime();
      const dateB = new Date(b.dateDebut).getTime();
      return this.sortDirection === 'desc' ? dateB - dateA : dateA - dateB;
    });

    this.filteredHistoriques = data;
    this.currentPage = 1;
    this.updatePagination();
  }

  toggleSort(): void {
    this.sortDirection = this.sortDirection === 'desc' ? 'asc' : 'desc';
    this.applyFilters();
  }

  updatePagination(): void {
    this.totalPages = Math.max(1, Math.ceil(this.filteredHistoriques.length / this.pageSize));

    if (this.currentPage > this.totalPages) {
      this.currentPage = this.totalPages;
    }

    const start = (this.currentPage - 1) * this.pageSize;
    const end = start + this.pageSize;

    this.paginatedHistoriques = this.filteredHistoriques.slice(start, end);
  }

  prevPage(): void {
    if (this.currentPage > 1) {
      this.currentPage--;
      this.updatePagination();
    }
  }

  nextPage(): void {
    if (this.currentPage < this.totalPages) {
      this.currentPage++;
      this.updatePagination();
    }
  }

  onPageSizeChange(): void {
    this.currentPage = 1;
    this.updatePagination();
  }

  getStatusClass(statut: string | null | undefined): string {
    const value = (statut || '').trim().toUpperCase();

    if (value.includes('TERMINE')) {
      return 'status-terminee';
    }

    if (value.includes('ANNULE')) {
      return 'status-annulee';
    }

    return 'status-default';
  }

  // ================= EXPORT =================

  exportExcel(): void {
    const data = this.filteredHistoriques.map(m => ({
      'ID Mission': m.idmission,
      'Date début': m.dateDebut,
      'Date fin': m.dateFin || '-',
      'Statut': m.statutMission,
      'Véhicule': m.immatriculationVehicule,
      'ID Demande': m.iddemande,
      'Motif': m.motifAnnulation || '-'
    }));

    const ws = XLSX.utils.json_to_sheet(data);
    const wb = { Sheets: { data: ws }, SheetNames: ['data'] };

    const buffer = XLSX.write(wb, { bookType: 'xlsx', type: 'array' });
    saveAs(new Blob([buffer]), 'historique-missions.xlsx');
  }

  exportPDF(): void {
    const doc = new jsPDF();

    autoTable(doc, {
      head: [['ID', 'Date début', 'Date fin', 'Statut', 'Véhicule', 'Demande', 'Motif']],
      body: this.filteredHistoriques.map(m => [
        m.idmission,
        m.dateDebut,
        m.dateFin || '-',
        m.statutMission,
        m.immatriculationVehicule,
        m.iddemande,
        m.motifAnnulation || '-'
      ])
    });

    doc.save('historique-missions.pdf');
  }
}

function saveAs(arg0: Blob, arg1: string) {
    throw new Error('Function not implemented.');
}
