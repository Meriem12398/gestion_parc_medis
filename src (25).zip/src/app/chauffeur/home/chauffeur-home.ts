import { Component, HostListener, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { NavigationEnd, Router, RouterOutlet } from '@angular/router';
import { filter } from 'rxjs/operators';
import { AuthService } from '../../auth/services/auth.service';

@Component({
  selector: 'app-chauffeur-home',
  standalone: true,
  imports: [CommonModule, RouterOutlet, FormsModule],
  templateUrl: './chauffeur-home.html',
  styleUrls: ['./chauffeur-home.scss']
})
export class ChauffeurHomeComponent implements OnInit {
  menuOpen = false;
  sidebarOpen = false;
  sidebarCollapsed = false;

  missionsOpen = false;
  incidentsOpen = false;

  displayName = 'Chauffeur';
  initials = 'C';
  breadcrumbLabel = 'Accueil';
  darkMode = false;
  userRole: string | null = null;

  showProfileModal = false;
  showPasswordModal = false;

  userData: any = null;

  passwordForm = {
    ancienMotDePasse: '',
    nouveauMotDePasse: '',
    confirmerMotDePasse: ''
  };

  passwordSuccessMsg = '';
  passwordErrorMsg = '';

  constructor(
    private router: Router,
    private authService: AuthService
  ) {}

  ngOnInit(): void {
    const saved = localStorage.getItem('theme');

    if (saved === 'dark') {
      document.body.classList.add('dark-theme');
      this.darkMode = true;
    } else {
      document.body.classList.remove('dark-theme');
      this.darkMode = false;
    }

    this.userRole = this.authService.getRole();
    this.userData = this.authService.getUser();

    const rawUser = localStorage.getItem('user');
    if (rawUser) {
      const user = JSON.parse(rawUser);
      const full = `${user.prenom ?? ''} ${user.nom ?? ''}`.trim();
      this.displayName = full || user.email || 'Chauffeur';
      this.initials = this.getInitials(this.displayName);
    }

    this.router.events
      .pipe(filter(e => e instanceof NavigationEnd))
      .subscribe(() => {
        const url = this.router.url;

        if (url.includes('/chauffeur/missions/historique')) {
          this.breadcrumbLabel = 'Historique des missions';
          this.missionsOpen = true;
          this.incidentsOpen = false;
        } else if (url.includes('/chauffeur/missions')) {
          this.breadcrumbLabel = 'Mes missions';
          this.missionsOpen = true;
          this.incidentsOpen = false;
        } else if (url.includes('/chauffeur/incidents')) {
          this.breadcrumbLabel = 'Incidents';
          this.incidentsOpen = true;
          this.missionsOpen = false;
        } else {
          this.breadcrumbLabel = 'Accueil';
          this.missionsOpen = false;
          this.incidentsOpen = false;
        }
      });
  }

  isResponsable(): boolean {
    return this.userRole === 'RESPONSABLE';
  }

  toggleMissions(e?: Event): void {
    e?.stopPropagation();

    if (this.sidebarCollapsed) {
      this.router.navigate(['/chauffeur/missions']);
      return;
    }

    this.missionsOpen = !this.missionsOpen;

    if (this.missionsOpen) {
      this.incidentsOpen = false;
    }
  }

  toggleIncidents(e?: Event): void {
    e?.stopPropagation();

    if (this.sidebarCollapsed) {
      this.router.navigate(['/chauffeur/incidents']);
      return;
    }

    this.incidentsOpen = !this.incidentsOpen;

    if (this.incidentsOpen) {
      this.missionsOpen = false;
    }
  }

  goMissions(e?: Event): void {
    e?.stopPropagation();
    this.router.navigate(['/chauffeur/missions']);
  }

  goHistorique(e?: Event): void {
    e?.stopPropagation();
    this.router.navigate(['/chauffeur/missions/historique']);
  }

  goIncidents(e?: Event): void {
    e?.stopPropagation();
    this.router.navigate(['/chauffeur/incidents']);
  }

  toggleSidebar(): void {
    this.sidebarCollapsed = !this.sidebarCollapsed;

    if (this.sidebarCollapsed) {
      this.missionsOpen = false;
      this.incidentsOpen = false;
    }
  }

  toggleMenu(): void {
    this.menuOpen = !this.menuOpen;
  }

  @HostListener('document:click')
  onDocClick(): void {
    this.menuOpen = false;
    this.missionsOpen = false;
    this.incidentsOpen = false;
  }

  toggleTheme(): void {
    this.darkMode = !this.darkMode;

    if (this.darkMode) {
      document.body.classList.add('dark-theme');
      localStorage.setItem('theme', 'dark');
    } else {
      document.body.classList.remove('dark-theme');
      localStorage.setItem('theme', 'light');
    }
  }

  private getInitials(name: string): string {
    const parts = name.split(/\s+/).filter(Boolean);
    const first = parts[0]?.charAt(0) ?? 'C';
    const last = parts.length > 1 ? (parts[parts.length - 1]?.charAt(0) ?? '') : '';
    return (first + last).toUpperCase();
  }

  openProfileModal(): void {
    this.menuOpen = false;
    this.userData = this.authService.getUser();
    this.showProfileModal = true;
  }

  closeProfileModal(): void {
    this.showProfileModal = false;
  }

  openPasswordModal(): void {
    this.menuOpen = false;
    this.passwordErrorMsg = '';
    this.passwordSuccessMsg = '';
    this.passwordForm = {
      ancienMotDePasse: '',
      nouveauMotDePasse: '',
      confirmerMotDePasse: ''
    };
    this.showPasswordModal = true;
  }

  closePasswordModal(): void {
    this.showPasswordModal = false;
  }

  submitChangePassword(): void {
    this.passwordErrorMsg = '';
    this.passwordSuccessMsg = '';

    const user = this.authService.getUser();

    if (!user?.email) {
      this.passwordErrorMsg = 'Utilisateur introuvable.';
      return;
    }

    if (!this.passwordForm.ancienMotDePasse.trim()) {
      this.passwordErrorMsg = 'Ancien mot de passe obligatoire.';
      return;
    }

    if (!this.passwordForm.nouveauMotDePasse.trim()) {
      this.passwordErrorMsg = 'Nouveau mot de passe obligatoire.';
      return;
    }

    if (this.passwordForm.nouveauMotDePasse.length < 4) {
      this.passwordErrorMsg = 'Le nouveau mot de passe doit contenir au moins 4 caractères.';
      return;
    }

    if (this.passwordForm.nouveauMotDePasse !== this.passwordForm.confirmerMotDePasse) {
      this.passwordErrorMsg = 'Confirmation incorrecte.';
      return;
    }

    this.authService.changePassword(
      user.email,
      this.passwordForm.ancienMotDePasse,
      this.passwordForm.nouveauMotDePasse
    ).subscribe({
      next: (res: any) => {
        this.passwordSuccessMsg =
          typeof res === 'string' ? res : 'Mot de passe modifié avec succès.';

        this.passwordForm = {
          ancienMotDePasse: '',
          nouveauMotDePasse: '',
          confirmerMotDePasse: ''
        };
      },
      error: (err: any) => {
        console.error(err);
        this.passwordErrorMsg =
          err?.error?.message ||
          err?.error ||
          'Erreur lors du changement du mot de passe.';
      }
    });
  }

  logout(): void {
    localStorage.clear();
    this.router.navigate(['/login']);
  }

  goResponsableSpace(): void {
    this.menuOpen = false;
    this.router.navigate(['/home']);
  }

  goChauffeurSpace(): void {
    this.menuOpen = false;
    this.router.navigate(['/chauffeur']);
  }

  goDemandeurSpace(): void {
    this.menuOpen = false;
    this.router.navigate(['/demandeur']);
  }
}