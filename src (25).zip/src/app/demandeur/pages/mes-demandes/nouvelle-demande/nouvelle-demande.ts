import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { DemandeService } from '../../../../auth/services/demande.service';

@Component({
  selector: 'app-nouvelle-demande',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './nouvelle-demande.html',
  styleUrls: ['./nouvelle-demande.scss']
})
export class NouvelleDemandeComponent {
  form = {
    typeDemande: '',
    priorite: '',
    description: '',
    dateSouhaite: ''
  };

  successMsg = '';
  errorMsg = '';
  saving = false;

  constructor(
    private demandeService: DemandeService,
    private router: Router
  ) {}

  submit(): void {
    console.log('submit clicked');

    if (this.saving) return;

    this.successMsg = '';
    this.errorMsg = '';

    if (!this.form.typeDemande.trim()) {
      this.errorMsg = 'Type de demande obligatoire.';
      return;
    }

    if (!this.form.priorite.trim()) {
      this.errorMsg = 'Priorité obligatoire.';
      return;
    }

    if (!this.form.description.trim()) {
      this.errorMsg = 'Description obligatoire.';
      return;
    }

    if (!this.form.dateSouhaite) {
      this.errorMsg = 'Date souhaitée obligatoire.';
      return;
    }

    const payload = {
      typeDemande: this.form.typeDemande.trim().toUpperCase(),
      priorite: this.form.priorite.trim().toUpperCase(),
      description: this.form.description.trim(),
      dateSouhaite: this.form.dateSouhaite + ':00'
    };

    console.log('PAYLOAD DEMANDE = ', payload);

    this.saving = true;

    this.demandeService.create(payload).subscribe({
      next: (res: any) => {
        console.log('SUCCESS CREATE DEMANDE = ', res);

        this.saving = false;
        this.successMsg = 'Demande créée avec succès.';
        this.errorMsg = '';

        this.form = {
          typeDemande: '',
          priorite: '',
          description: '',
          dateSouhaite: ''
        };

        setTimeout(() => {
          this.router.navigate(['/demandeur/mes-demandes']);
        }, 1200);
      },
      error: (err: any) => {
        console.error('ERROR CREATE DEMANDE = ', err);

        this.saving = false;
        this.errorMsg =
          err?.error?.message ||
          err?.error ||
          `Erreur ${err?.status || ''} lors de la création de la demande.`;
      }
    });
  }

  retour(): void {
    if (this.saving) return;
    this.router.navigate(['/demandeur/mes-demandes']);
  }
}