import { Component, OnInit, ChangeDetectorRef } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { DemandeService } from '../../../auth/services/demande.service';
import * as XLSX from 'xlsx';
import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';

type StatutFilter = 'ALL' | 'EN_ATTENTE' | 'EN_COURS';
type SortBy = 'RECENT' | 'ANCIEN';
type QuickFilter =
  | 'NONE'
  | 'ALL'
  | 'EN_ATTENTE'
  | 'EN_COURS';

@Component({
  selector: 'app-mes-demandes',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './mes-demandes.html',
  styleUrls: ['./mes-demandes.scss']
})
export class MesDemandesComponent implements OnInit {
  demandes: any[] = [];
  loading = false;
  errorMsg = '';
  successMsg = '';

  searchTerm = '';
  statutFilter: StatutFilter = 'ALL';
  sortBy: SortBy = 'RECENT';
  quickFilter: QuickFilter = 'NONE';

  page = 1;
  pageSize = 8;
  pageSizes = [5, 8, 10, 15, 20];

  sortColumnName = '';
  sortDirection: 'asc' | 'desc' = 'asc';

  showEditModal = false;
  showDeleteModal = false;

  selectedDemande: any = null;

  editForm = {
    typeDemande: '',
    priorite: '',
    description: '',
    dateSouhaite: ''
  };

  stats = {
    total: 0,
    enAttente: 0,
    enCours: 0
  };

  constructor(
    private demandeService: DemandeService,
    private cdr: ChangeDetectorRef
  ) {}

  ngOnInit(): void {
    this.loadDemandes();
  }

  private normalize(v: any): string {
    return (v ?? '').toString().trim().toLowerCase();
  }

  private isEnAttenteStatut(statut: any): boolean {
    const s = this.normalize(statut);
    return s.includes('attente') || s === 'en_attente' || s === 'en attente';
  }

  private isEnCoursStatut(statut: any): boolean {
    const s = this.normalize(statut);
    return s.includes('cours') || s === 'en_cours' || s === 'en cours';
  }

  private isActiveDemande(statut: any): boolean {
    return this.isEnAttenteStatut(statut) || this.isEnCoursStatut(statut);
  }

  private showSuccess(msg: string): void {
    this.successMsg = msg;
    this.errorMsg = '';
    this.cdr.detectChanges();

    setTimeout(() => {
      this.successMsg = '';
      this.cdr.detectChanges();
    }, 3000);
  }

  private showError(msg: string): void {
    this.errorMsg = msg;
    this.successMsg = '';
    this.cdr.detectChanges();
  }

  private computeStats(list: any[]): void {
    this.stats.total = list.length;

    this.stats.enAttente = list.filter(d =>
      this.isEnAttenteStatut(d?.statut)
    ).length;

    this.stats.enCours = list.filter(d =>
      this.isEnCoursStatut(d?.statut)
    ).length;
  }

  isEditable(d: any): boolean {
    return this.isEnAttenteStatut(d?.statut);
  }

  loadDemandes(): void {
    this.loading = true;
    this.errorMsg = '';
    this.cdr.detectChanges();

    this.demandeService.getMesDemandes().subscribe({
      next: (data: any[]) => {
        const allDemandes = data ?? [];

        this.demandes = allDemandes.filter(d => this.isActiveDemande(d?.statut));
        this.computeStats(this.demandes);

        this.loading = false;
        this.page = 1;
        this.cdr.detectChanges();
      },
      error: (err: any) => {
        console.error(err);
        this.showError('Erreur lors du chargement des demandes.');
        this.loading = false;
        this.cdr.detectChanges();
      }
    });
  }

  sortColumn(column: string): void {
    if (this.sortColumnName === column) {
      this.sortDirection = this.sortDirection === 'asc' ? 'desc' : 'asc';
    } else {
      this.sortColumnName = column;
      this.sortDirection = 'asc';
    }
    this.page = 1;
  }

  setQuickFilter(q: QuickFilter): void {
    this.quickFilter = this.quickFilter === q ? 'NONE' : q;
    this.page = 1;
  }

  onFiltersChange(): void {
    this.page = 1;
  }

  private matchStatut(d: any): boolean {
    const statut = this.normalize(d?.statut);

    if (this.statutFilter === 'ALL') return true;
    if (this.statutFilter === 'EN_ATTENTE') return statut.includes('attente');
    if (this.statutFilter === 'EN_COURS') return statut.includes('cours');

    return true;
  }

  private applyQuickFilter(d: any): boolean {
    const statut = this.normalize(d?.statut);

    switch (this.quickFilter) {
      case 'ALL':
        return true;
      case 'EN_ATTENTE':
        return statut.includes('attente');
      case 'EN_COURS':
        return statut.includes('cours');
      default:
        return true;
    }
  }

  private prioWeight(p: any): number {
    const v = this.normalize(p);
    if (v === 'urgente') return 4;
    if (v === 'haute') return 3;
    if (v === 'moyenne') return 2;
    if (v === 'faible') return 1;
    return 0;
  }

  private getSortableValue(d: any, column: string): any {
    switch (column) {
      case 'iddemande':
        return Number(d?.iddemande ?? 0);
      case 'typeDemande':
        return this.normalize(d?.typeDemande);
      case 'priorite':
        return this.prioWeight(d?.priorite);
      case 'statut':
        return this.normalize(d?.statut);
      case 'description':
        return this.normalize(d?.description);
      default:
        return this.normalize(d?.[column]);
    }
  }

  private sortList(list: any[]): any[] {
    const arr = [...list];

    if (this.sortColumnName) {
      arr.sort((a, b) => {
        const v1 = this.getSortableValue(a, this.sortColumnName);
        const v2 = this.getSortableValue(b, this.sortColumnName);

        if (v1 < v2) return this.sortDirection === 'asc' ? -1 : 1;
        if (v1 > v2) return this.sortDirection === 'asc' ? 1 : -1;
        return 0;
      });

      return arr;
    }

    arr.sort((a, b) => {
      const da = new Date(a?.dateCreation || a?.date_creation || a?.date || 0).getTime();
      const db = new Date(b?.dateCreation || b?.date_creation || b?.date || 0).getTime();
      return this.sortBy === 'ANCIEN' ? da - db : db - da;
    });

    return arr;
  }

  get filteredDemandes(): any[] {
    const q = this.normalize(this.searchTerm);

    const base = this.demandes.filter(d => {
      const fullText = this.normalize(`
        ${d?.iddemande ?? ''}
        ${d?.typeDemande ?? ''}
        ${d?.priorite ?? ''}
        ${d?.statut ?? ''}
        ${d?.description ?? ''}
      `);

      const matchSearch = !q || fullText.includes(q);
      const matchStatut = this.matchStatut(d);
      const matchQuick = this.applyQuickFilter(d);

      return matchSearch && matchStatut && matchQuick;
    });

    return this.sortList(base);
  }

  get totalItems(): number {
    return this.filteredDemandes.length;
  }

  get totalPages(): number {
    return Math.max(1, Math.ceil(this.totalItems / this.pageSize));
  }

  get pagedDemandes(): any[] {
    const start = (this.page - 1) * this.pageSize;
    return this.filteredDemandes.slice(start, start + this.pageSize);
  }

  goToPage(p: number): void {
    if (p < 1) p = 1;
    if (p > this.totalPages) p = this.totalPages;
    this.page = p;
  }

  nextPage(): void {
    this.goToPage(this.page + 1);
  }

  prevPage(): void {
    this.goToPage(this.page - 1);
  }

  onPageSizeChange(): void {
    this.page = 1;
  }

  refresh(): void {
    this.loadDemandes();
  }

  openEditModal(d: any): void {
    if (!this.isEditable(d)) return;

    this.selectedDemande = d;
    this.editForm = {
      typeDemande: d.typeDemande ?? '',
      priorite: d.priorite ?? '',
      description: d.description ?? '',
      dateSouhaite: d.dateSouhaite ? this.toInputDateTime(d.dateSouhaite) : ''
    };
    this.showEditModal = true;
    this.errorMsg = '';
    this.cdr.detectChanges();
  }

  closeEditModal(): void {
    this.showEditModal = false;
    this.selectedDemande = null;
    this.editForm = {
      typeDemande: '',
      priorite: '',
      description: '',
      dateSouhaite: ''
    };
    this.cdr.detectChanges();
  }

  submitEdit(): void {
    if (!this.selectedDemande) return;

    if (!this.editForm.typeDemande.trim()) {
      this.showError('Type demande obligatoire.');
      return;
    }

    if (!this.editForm.priorite.trim()) {
      this.showError('Priorité obligatoire.');
      return;
    }

    if (!this.editForm.description.trim()) {
      this.showError('Description obligatoire.');
      return;
    }

    if (!this.editForm.dateSouhaite) {
      this.showError('Date souhaitée obligatoire.');
      return;
    }

    const id = this.selectedDemande.iddemande;

    const payload = {
      typeDemande: this.editForm.typeDemande.trim().toUpperCase(),
      priorite: this.editForm.priorite.trim().toUpperCase(),
      description: this.editForm.description.trim(),
      dateSouhaite: this.editForm.dateSouhaite + ':00'
    };

    this.closeEditModal();

    this.demandeService.modifierDemande(id, payload).subscribe({
      next: () => {
        this.showSuccess('Demande modifiée avec succès.');
        this.loadDemandes();
      },
      error: (err: any) => {
        console.error(err);
        this.showError(
          err?.error?.message ||
          err?.error ||
          'Erreur lors de la modification de la demande.'
        );
      }
    });
  }

  openDeleteModal(d: any): void {
    if (!this.isEditable(d)) return;
    this.selectedDemande = d;
    this.showDeleteModal = true;
    this.errorMsg = '';
    this.cdr.detectChanges();
  }

  closeDeleteModal(): void {
    this.showDeleteModal = false;
    this.selectedDemande = null;
    this.cdr.detectChanges();
  }

  confirmDeleteDemande(): void {
    if (!this.selectedDemande) return;

    const id = this.selectedDemande.iddemande;

    this.closeDeleteModal();

    this.demandeService.supprimerDemande(id).subscribe({
      next: () => {
        this.showSuccess('Demande supprimée avec succès.');
        this.loadDemandes();
      },
      error: (err: any) => {
        console.error(err);
        this.showError(
          err?.error?.message ||
          err?.error ||
          'Erreur lors de la suppression de la demande.'
        );
      }
    });
  }

  private toInputDateTime(value: string): string {
    const d = new Date(value);
    if (isNaN(d.getTime())) return '';
    const yyyy = d.getFullYear();
    const mm = String(d.getMonth() + 1).padStart(2, '0');
    const dd = String(d.getDate()).padStart(2, '0');
    const hh = String(d.getHours()).padStart(2, '0');
    const mi = String(d.getMinutes()).padStart(2, '0');
    return `${yyyy}-${mm}-${dd}T${hh}:${mi}`;
  }

  exportExcel(): void {
    const data = this.filteredDemandes.map(d => ({
      ID_Demande: d.iddemande,
      Type: d.typeDemande ?? '-',
      Priorite: d.priorite ?? '-',
      Statut: d.statut ?? '-',
      Description: d.description ?? '-',
      DateCreation: d.dateCreation ?? '-',
      DateSouhaite: d.dateSouhaite ?? '-'
    }));

    const ws: XLSX.WorkSheet = XLSX.utils.json_to_sheet(data);
    const wb: XLSX.WorkBook = {
      Sheets: { Demandes: ws },
      SheetNames: ['Demandes']
    };

    XLSX.writeFile(wb, 'mes-demandes.xlsx');
    this.showSuccess('Export Excel effectué avec succès.');
  }

  exportPDF(): void {
    const rows = this.filteredDemandes.map(d => [
      d.iddemande ?? '',
      d.typeDemande ?? '-',
      d.priorite ?? '-',
      d.statut ?? '-',
      d.description ?? '-',
      d.dateCreation ?? '-',
      d.dateSouhaite ?? '-'
    ]);

    const doc = new jsPDF('landscape');

    doc.setFontSize(14);
    doc.text('Mes demandes', 14, 15);

    autoTable(doc, {
      startY: 22,
      head: [[
        'ID Demande',
        'Type',
        'Priorite',
        'Statut',
        'Description',
        'Date Creation',
        'Date Souhaitee'
      ]],
      body: rows,
      styles: {
        fontSize: 8
      },
      headStyles: {
        fillColor: [41, 128, 185]
      }
    });

    doc.save('mes-demandes.pdf');
    this.showSuccess('Export PDF effectué avec succès.');
  }
}