import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { DemandeService } from '../../../auth/services/demande.service';
import * as XLSX from 'xlsx';
import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';

type SortBy = 'RECENT' | 'ANCIEN';

@Component({
  selector: 'app-historique-demandes',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './historique-demandes.html',
  styleUrls: ['./historique-demandes.scss']
})
export class HistoriqueDemandesComponent implements OnInit {
  demandes: any[] = [];
  loading = false;
  errorMsg = '';
  successMsg = '';

  searchTerm = '';
  sortBy: SortBy = 'RECENT';

  page = 1;
  pageSize = 8;
  pageSizes = [5, 8, 10, 15, 20];

  sortColumnName: string = '';
  sortDirection: 'asc' | 'desc' = 'asc';

  constructor(private demandeService: DemandeService) {}

  ngOnInit(): void {
    this.loadDemandes();
  }

  sortColumn(column: string): void {
    if (this.sortColumnName === column) {
      this.sortDirection = this.sortDirection === 'asc' ? 'desc' : 'asc';
    } else {
      this.sortColumnName = column;
      this.sortDirection = 'asc';
    }

    this.page = 1;
  }

  private normalize(v: any): string {
    return (v ?? '').toString().trim().toLowerCase();
  }

  private isHistoriqueStatut(statut: any): boolean {
    const s = this.normalize(statut);

    return (
      s.includes('affect') ||
      s.includes('valid') ||
      s.includes('refus')
    );
  }

  private showSuccess(msg: string): void {
    this.successMsg = msg;
    this.errorMsg = '';

    setTimeout(() => {
      this.successMsg = '';
    }, 3000);
  }

  private showError(msg: string): void {
    this.errorMsg = msg;
    this.successMsg = '';
  }

  loadDemandes(): void {
    this.loading = true;
    this.errorMsg = '';

    this.demandeService.getMesDemandes().subscribe({
      next: (data: any[]) => {
        const allDemandes = data ?? [];
        this.demandes = allDemandes.filter(d => this.isHistoriqueStatut(d?.statut));
        this.loading = false;
        this.page = 1;
      },
      error: (err: any) => {
        console.error(err);
        this.showError('Erreur lors du chargement de l’historique.');
        this.loading = false;
      }
    });
  }

  onFiltersChange(): void {
    this.page = 1;
  }

  private prioWeight(p: any): number {
    const v = this.normalize(p);
    if (v === 'urgente') return 4;
    if (v === 'haute') return 3;
    if (v === 'moyenne') return 2;
    if (v === 'faible') return 1;
    return 0;
  }

  private getSortableValue(d: any, column: string): any {
    switch (column) {
      case 'iddemande':
        return Number(d?.iddemande ?? 0);
      case 'typeDemande':
        return this.normalize(d?.typeDemande);
      case 'priorite':
        return this.prioWeight(d?.priorite);
      case 'statut':
        return this.normalize(d?.statut);
      case 'description':
        return this.normalize(d?.description);
      case 'motifRefus':
        return this.normalize(d?.motifRefus);
      default:
        return this.normalize(d?.[column]);
    }
  }

  private sortList(list: any[]): any[] {
    const arr = [...list];

    if (this.sortColumnName) {
      arr.sort((a, b) => {
        const v1 = this.getSortableValue(a, this.sortColumnName);
        const v2 = this.getSortableValue(b, this.sortColumnName);

        if (v1 < v2) return this.sortDirection === 'asc' ? -1 : 1;
        if (v1 > v2) return this.sortDirection === 'asc' ? 1 : -1;
        return 0;
      });

      return arr;
    }

    arr.sort((a, b) => {
      const da = new Date(a?.dateCreation || a?.date_creation || a?.date || 0).getTime();
      const db = new Date(b?.dateCreation || b?.date_creation || b?.date || 0).getTime();

      return this.sortBy === 'ANCIEN' ? da - db : db - da;
    });

    return arr;
  }

  get filteredDemandes(): any[] {
    const q = this.normalize(this.searchTerm);

    const base = this.demandes.filter(d => {
      const fullText = this.normalize(`
        ${d?.iddemande ?? ''}
        ${d?.typeDemande ?? ''}
        ${d?.priorite ?? ''}
        ${d?.statut ?? ''}
        ${d?.description ?? ''}
        ${d?.motifRefus ?? ''}
      `);

      return !q || fullText.includes(q);
    });

    return this.sortList(base);
  }

  get totalItems(): number {
    return this.filteredDemandes.length;
  }

  get totalPages(): number {
    return Math.max(1, Math.ceil(this.totalItems / this.pageSize));
  }

  get pagedDemandes(): any[] {
    const start = (this.page - 1) * this.pageSize;
    return this.filteredDemandes.slice(start, start + this.pageSize);
  }

  goToPage(p: number): void {
    if (p < 1) p = 1;
    if (p > this.totalPages) p = this.totalPages;
    this.page = p;
  }

  nextPage(): void {
    this.goToPage(this.page + 1);
  }

  prevPage(): void {
    this.goToPage(this.page - 1);
  }

  onPageSizeChange(): void {
    this.page = 1;
  }

  refresh(): void {
    this.loadDemandes();
  }

  exportExcel(): void {
    const data = this.filteredDemandes.map(d => ({
      ID_Demande: d.iddemande,
      Type: d.typeDemande ?? '-',
      Priorite: d.priorite ?? '-',
      Statut: d.statut ?? '-',
      Description: d.description ?? '-',
      MotifRefus: d.motifRefus ?? '-',
      DateCreation: d.dateCreation ?? '-',
      DateSouhaite: d.dateSouhaite ?? '-'
    }));

    const ws: XLSX.WorkSheet = XLSX.utils.json_to_sheet(data);
    const wb: XLSX.WorkBook = {
      Sheets: { Historique: ws },
      SheetNames: ['Historique']
    };

    XLSX.writeFile(wb, 'historique-demandes.xlsx');
    this.showSuccess('Export Excel effectué avec succès.');
  }

  exportPDF(): void {
    const rows = this.filteredDemandes.map(d => [
      d.iddemande ?? '',
      d.typeDemande ?? '-',
      d.priorite ?? '-',
      d.statut ?? '-',
      d.description ?? '-',
      d.motifRefus ?? '-',
      d.dateCreation ?? '-',
      d.dateSouhaite ?? '-'
    ]);

    const doc = new jsPDF('landscape');

    doc.setFontSize(14);
    doc.text('Historique des demandes', 14, 15);

    autoTable(doc, {
      startY: 22,
      head: [[
        'ID Demande',
        'Type',
        'Priorite',
        'Statut',
        'Description',
        'Motif Refus',
        'Date Creation',
        'Date Souhaitee'
      ]],
      body: rows,
      styles: {
        fontSize: 8
      },
      headStyles: {
        fillColor: [41, 128, 185]
      }
    });

    doc.save('historique-demandes.pdf');
    this.showSuccess('Export PDF effectué avec succès.');
  }
}