import { Component, HostListener, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { NavigationEnd, Router, RouterOutlet } from '@angular/router';
import { filter } from 'rxjs/operators';
import { AuthService } from '../../auth/services/auth.service';

@Component({
  selector: 'app-demandeur-home',
  standalone: true,
  imports: [CommonModule, RouterOutlet, FormsModule],
  templateUrl: './demandeur-home.html',
  styleUrls: ['./demandeur-home.scss']
})
export class DemandeurHomeComponent implements OnInit {
  menuOpen = false;
  sidebarOpen = false;
  sidebarCollapsed = false;

  demandesOpen = false;
  nouvelleDemandeOpen = false;
  historiqueOpen = false;

  displayName = 'Demandeur';
  initials = 'D';
  breadcrumbLabel = 'Accueil';
  darkMode = false;
  userRole: string | null = null;

  showProfileModal = false;
  showPasswordModal = false;

  userData: any = null;

  passwordForm = {
    ancienMotDePasse: '',
    nouveauMotDePasse: '',
    confirmerMotDePasse: ''
  };

  passwordSuccessMsg = '';
  passwordErrorMsg = '';

  constructor(
    private router: Router,
    private authService: AuthService
  ) {}

  ngOnInit(): void {
    const saved = localStorage.getItem('theme');
    if (saved === 'dark') {
      document.body.classList.add('dark-theme');
      this.darkMode = true;
    } else {
      document.body.classList.remove('dark-theme');
      this.darkMode = false;
    }

    this.userRole = this.authService.getRole();
    this.userData = this.authService.getUser();

    const rawUser = localStorage.getItem('user');
    if (rawUser) {
      const user = JSON.parse(rawUser);
      const full = `${user.prenom ?? ''} ${user.nom ?? ''}`.trim();
      this.displayName = full || user.email || 'Demandeur';
      this.initials = this.getInitials(this.displayName);
    }

    this.router.events
      .pipe(filter(e => e instanceof NavigationEnd))
      .subscribe(() => {
        const url = this.router.url;

        if (url.includes('/demandeur/mes-demandes')) {
          this.breadcrumbLabel = 'Mes demandes';
        } else if (url.includes('/demandeur/nouvelle-demande')) {
          this.breadcrumbLabel = 'Nouvelle demande';
        } else if (url.includes('/demandeur/historique')) {
          this.breadcrumbLabel = 'Historique';
        } else {
          this.breadcrumbLabel = 'Accueil';
        }
      });
  }

  isResponsable(): boolean {
    return this.userRole === 'RESPONSABLE';
  }

  toggleDemandes(e?: Event): void {
    e?.stopPropagation();

    if (this.sidebarCollapsed) {
      this.router.navigate(['/demandeur/mes-demandes']);
      return;
    }

    this.demandesOpen = !this.demandesOpen;

    if (this.demandesOpen) {
      this.nouvelleDemandeOpen = false;
      this.historiqueOpen = false;
    }
  }

  toggleNouvelleDemande(e?: Event): void {
    e?.stopPropagation();

    if (this.sidebarCollapsed) {
      this.router.navigate(['/demandeur/nouvelle-demande']);
      return;
    }

    this.nouvelleDemandeOpen = !this.nouvelleDemandeOpen;

    if (this.nouvelleDemandeOpen) {
      this.demandesOpen = false;
      this.historiqueOpen = false;
    }
  }

  toggleHistorique(e?: Event): void {
    e?.stopPropagation();

    if (this.sidebarCollapsed) {
      this.router.navigate(['/demandeur/historique']);
      return;
    }

    this.historiqueOpen = !this.historiqueOpen;

    if (this.historiqueOpen) {
      this.demandesOpen = false;
      this.nouvelleDemandeOpen = false;
    }
  }

  goMesDemandes(e?: Event): void {
    e?.stopPropagation();
    this.router.navigate(['/demandeur/mes-demandes']);
  }

  goNouvelleDemande(e?: Event): void {
    e?.stopPropagation();
    this.router.navigate(['/demandeur/nouvelle-demande']);
  }

  goHistorique(e?: Event): void {
    e?.stopPropagation();
    this.router.navigate(['/demandeur/historique']);
  }

  toggleSidebar(): void {
    this.sidebarCollapsed = !this.sidebarCollapsed;

    if (this.sidebarCollapsed) {
      this.demandesOpen = false;
      this.nouvelleDemandeOpen = false;
      this.historiqueOpen = false;
    }
  }

  toggleMenu(): void {
    this.menuOpen = !this.menuOpen;
  }

  @HostListener('document:click')
  onDocClick(): void {
    this.menuOpen = false;
    this.demandesOpen = false;
    this.nouvelleDemandeOpen = false;
    this.historiqueOpen = false;
  }

  toggleTheme(): void {
    this.darkMode = !this.darkMode;

    if (this.darkMode) {
      document.body.classList.add('dark-theme');
      localStorage.setItem('theme', 'dark');
    } else {
      document.body.classList.remove('dark-theme');
      localStorage.setItem('theme', 'light');
    }
  }

  private getInitials(name: string): string {
    const parts = name.split(/\s+/).filter(Boolean);
    const first = parts[0]?.charAt(0) ?? 'D';
    const last = parts.length > 1 ? (parts[parts.length - 1]?.charAt(0) ?? '') : '';
    return (first + last).toUpperCase();
  }

  openProfileModal(): void {
    this.menuOpen = false;
    this.userData = this.authService.getUser();
    this.showProfileModal = true;
  }

  closeProfileModal(): void {
    this.showProfileModal = false;
  }

  openPasswordModal(): void {
    this.menuOpen = false;
    this.passwordErrorMsg = '';
    this.passwordSuccessMsg = '';
    this.passwordForm = {
      ancienMotDePasse: '',
      nouveauMotDePasse: '',
      confirmerMotDePasse: ''
    };
    this.showPasswordModal = true;
  }

  closePasswordModal(): void {
    this.showPasswordModal = false;
  }

  submitChangePassword(): void {
    this.passwordErrorMsg = '';
    this.passwordSuccessMsg = '';

    const user = this.authService.getUser();

    if (!user?.email) {
      this.passwordErrorMsg = 'Utilisateur introuvable.';
      return;
    }

    if (!this.passwordForm.ancienMotDePasse.trim()) {
      this.passwordErrorMsg = 'Ancien mot de passe obligatoire.';
      return;
    }

    if (!this.passwordForm.nouveauMotDePasse.trim()) {
      this.passwordErrorMsg = 'Nouveau mot de passe obligatoire.';
      return;
    }

    if (this.passwordForm.nouveauMotDePasse.length < 4) {
      this.passwordErrorMsg = 'Le nouveau mot de passe doit contenir au moins 4 caractères.';
      return;
    }

    if (this.passwordForm.nouveauMotDePasse !== this.passwordForm.confirmerMotDePasse) {
      this.passwordErrorMsg = 'Confirmation incorrecte.';
      return;
    }

    this.authService.changePassword(
      user.email,
      this.passwordForm.ancienMotDePasse,
      this.passwordForm.nouveauMotDePasse
    ).subscribe({
      next: (res: any) => {
        this.passwordSuccessMsg =
          typeof res === 'string' ? res : 'Mot de passe modifié avec succès.';

        this.passwordForm = {
          ancienMotDePasse: '',
          nouveauMotDePasse: '',
          confirmerMotDePasse: ''
        };
      },
      error: (err: any) => {
        console.error(err);
        this.passwordErrorMsg =
          err?.error?.message ||
          err?.error ||
          'Erreur lors du changement du mot de passe.';
      }
    });
  }

  logout(): void {
    localStorage.clear();
    this.router.navigate(['/login']);
  }

  goResponsableSpace(): void {
    this.menuOpen = false;
    this.router.navigate(['/home']);
  }

  goChauffeurSpace(): void {
    this.menuOpen = false;
    this.router.navigate(['/chauffeur']);
  }

  goDemandeurSpace(): void {
    this.menuOpen = false;
    this.router.navigate(['/demandeur']);
  }
}