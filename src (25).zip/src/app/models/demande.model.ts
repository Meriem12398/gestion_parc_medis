export interface Demande {
  iddemande: number;
  typeDemande: string;
  dateCreation: string;
  dateSouhaite?: string;
  statut: string;
  priorite?: string;
  description?: string;

  matricule: number;
  nomCreateur?: string;
  prenomCreateur?: string;
  departementCreateur?: string;

  scorePriorite?: number;
prioriteIa?: string;
}